﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence;

namespace SystemService.Presentation.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IRoleService _roleService;

        public RoleController(SystemDbContext context, IRoleService roleService)
        {
            _roleService = roleService;
        }


        [HttpGet("getRoleData")]
        public async Task<IActionResult> GetAllRole()
        {
            var roles = await _roleService.GetRoleDataAsync();
            return Ok(roles);
        }

        [HttpPost("addOrUpdate")]
        public async Task<IActionResult> AddOrUpdate([FromBody] List<AddorUpdateDto> dtoList)
        {
            await _roleService.AddorUpdateAsync(dtoList);
            return Ok("add or update sucessful!.");
        }

        [HttpPost("delete")]
        public async Task<IActionResult> Delete([FromBody] List<int> ids)
        {
            await _roleService.DeleteAsync(ids);
            return Ok("Delete successful.");
        }
    }
}
