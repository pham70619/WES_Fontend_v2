﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence.Repositories;

namespace SystemService.Presentation.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyRepository _companyRepository;

        public CompanyController(ICompanyRepository companyRepository) 
        {
            _companyRepository = companyRepository;
        }

        [HttpGet("getCompany")]
        public async Task<IActionResult> GetCompany()
        {
            try
            {
                var companies = await _companyRepository.GetCompanyDataAsync();
                return Ok(companies);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] GetCompany failed: {ex.Message}");
                return StatusCode(500, new { message = "Internal error", detail = ex.Message });
            }
        }

        [HttpPost("updateCompany")]
        public async Task<IActionResult> updateCompany([FromBody] List<updateCompanyDto> companies)
        {
            if(companies == null || !companies.Any())
            {
                return BadRequest("Company data list is empty.");
            }

            await _companyRepository.UpdateDataAsync(companies);
            return Ok(new { message = "Updated successful!" });
        }

        [HttpPost("deleteCompany")]
        public async Task<IActionResult> deleteCompany([FromBody] List<int> companyIds)
        {
            if (companyIds == null || !companyIds.Any())
                return BadRequest("No company IDs provided.");
            try
            {
                await _companyRepository.DelCompanyDataAsync(companyIds);
                return Ok(new { message = "Menus deleted successfully." });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting menus.", detail = ex.Message });
            }
        }
    }
}
