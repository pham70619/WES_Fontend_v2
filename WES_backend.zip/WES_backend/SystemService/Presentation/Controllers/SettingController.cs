﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SharedKernel.Interface;
using SystemService.Application.DTOs.Setting;
using static SystemService.Application.Commands.Setting.SettingCommand;

namespace SystemService.Presentation.Controllers
{
    public class SettingController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ISharedLogger<SettingController> _logger;


        public SettingController(IMediator mediator, ISharedLogger<SettingController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        #region Customer Endpoints

        // 新增客戶
        // POST: api/setting/customer
        [HttpPost("customer")]
        public async Task<IActionResult> CreateCustomer([FromBody] CreateCustomerDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";

                dto.CreateBy = username;

                var result = await _mediator.Send(new CreateCustomerCommand(dto));
                return CreatedAtAction(nameof(GetCustomerById), new { customerId = result.CustomerID }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 更新客戶
        // PUT: api/setting/customer/{customerId}
        [HttpPut("customer/{customerId}")]
        public async Task<IActionResult> UpdateCustomer(string customerId, [FromBody] UpdateCustomerDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";
                dto.UpdateBy = username;

                if (customerId != dto.CustomerID)
                    return BadRequest(new { message = "傳入的 CustomerId 與資料內容不符" });


                await _mediator.Send(new UpdateCustomerCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 刪除客戶
        // DELETE: api/setting/customer/{customerId}
        [HttpDelete("customer/{customerId}")]
        public async Task<IActionResult> DeleteCustomer(string customerId, [FromBody] DeleteCustomerDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";
                dto.DeleteBy = username;

                if (customerId != dto.CustomerID)
                    return BadRequest(new { message = "傳入的 CustomerId 與資料內容不符" });

                await _mediator.Send(new DeleteCustomerCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依條件查詢客戶，回傳 List
        // GET: api/setting/customer/search?customerId=xxx&customerName=yyy
        [HttpGet("customer/search")]
        public async Task<IActionResult> SearchCustomers([FromQuery] string customerId, [FromQuery] string customerName)
        {
            try
            {
                var results = await _mediator.Send(new SearchCustomerQuery { CustomerID = customerId, CustomerName = customerName });
                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依 CustomerId 查詢單一客戶
        // GET: api/setting/customer/{customerId}
        [HttpGet("customer/{customerId}")]
        public async Task<IActionResult> GetCustomerById(string customerId)
        {
            try
            {
                var result = await _mediator.Send(new GetCustomerByIDQuery(customerId));
                if (result == null)
                    return NotFound();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        #endregion

        #region Warehouse Endpoints

        // 新增倉庫
        // POST: api/setting/warehouse
        [HttpPost("warehouse")]
        public async Task<IActionResult> CreateWarehouse([FromBody] CreateWarehouseDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";

                dto.CreateBy = username;
                var result = await _mediator.Send(new CreateWarehouseCommand(dto));
                return CreatedAtAction(nameof(GetWarehouseById), new { warehouseId = result.warehouseID }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 更新倉庫
        // PUT: api/setting/warehouse/{warehouseId}
        [HttpPut("warehouse/{warehouseId}")]
        public async Task<IActionResult> UpdateWarehouse(string warehouseId, [FromBody] UpdateWarehouseDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";
                dto.UpdateBy = username;

                if (warehouseId != dto.WarehouseID)
                    return BadRequest(new { message = "傳入的 WarehouseId 與資料內容不符" });

                await _mediator.Send(new UpdateWarehouseCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 刪除倉庫
        // DELETE: api/setting/warehouse/{warehouseId}
        [HttpDelete("warehouse/{warehouseId}")]
        public async Task<IActionResult> DeleteWarehouse(string warehouseId, [FromBody] DeleteWarehouseDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";
                dto.DeleteBy = username;

                if (warehouseId != dto.WarehouseID)
                    return BadRequest(new { message = "傳入的 WarehouseId 與資料內容不符" });

                await _mediator.Send(new DeleteWarehouseCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依條件查詢倉庫，回傳 List
        // GET: api/setting/warehouse/search?warehouseId=xxx&warehouseName=yyy
        [HttpGet("warehouse/search")]
        public async Task<IActionResult> SearchWarehouses([FromQuery] string warehouseId, [FromQuery] string warehouseName)
        {
            try
            {
                var results = await _mediator.Send(new SearchWarehouseQuery { WarehouseID = warehouseId, WarehouseName = warehouseName });
                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依 WarehouseId 查詢單一倉庫
        // GET: api/setting/warehouse/{warehouseId}
        [HttpGet("warehouse/{warehouseId}")]
        public async Task<IActionResult> GetWarehouseById(string warehouseId)
        {
            try
            {
                var result = await _mediator.Send(new GetWarehouseByIDQuery(warehouseId));
                if (result == null)
                    return NotFound();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        #endregion

        #region Zone Endpoints

        // 新增區域
        // POST: api/setting/zone
        [HttpPost("zone")]
        public async Task<IActionResult> CreateZone([FromBody] CreateZoneDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";

                dto.CreateBy = username;
                var result = await _mediator.Send(new CreateZoneCommand(dto));
                return CreatedAtAction(nameof(GetZoneById), new { warehouseId = result.warehouseID, zoneId = result.zoneID }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 更新區域
        // PUT: api/setting/zone/{warehouseId}/{zoneId}
        [HttpPut("zone/{warehouseId}/{zoneId}")]
        public async Task<IActionResult> UpdateZone(string warehouseId, string zoneId, [FromBody] UpdateZoneDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";

                dto.UpdateBy = username;
                if (warehouseId != dto.WarehouseID || zoneId != dto.ZoneID)
                    return BadRequest(new { message = "傳入的 WarehouseId 或 ZoneId 與資料內容不符" });


                await _mediator.Send(new UpdateZoneCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 刪除區域
        // DELETE: api/setting/zone/{warehouseId}/{zoneId}
        [HttpDelete("zone/{warehouseId}/{zoneId}")]
        public async Task<IActionResult> DeleteZone(string warehouseId, string zoneId, [FromBody] DeleteZoneDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";

                if (warehouseId != dto.WarehouseID || zoneId != dto.ZoneID)
                    return BadRequest(new { message = "傳入的 WarehouseId 或 ZoneId 與資料內容不符" });

                dto.DeleteBy = username;
                await _mediator.Send(new DeleteZoneCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依條件查詢區域，回傳 List
        // GET: api/setting/zone/search?warehouseId=xxx&warehouseName=yyy&zoneId=zzz
        [HttpGet("zone/search")]
        public async Task<IActionResult> SearchZones([FromQuery] string warehouseId, [FromQuery] string warehouseName, [FromQuery] string zoneId)
        {
            try
            {
                var results = await _mediator.Send(new SearchZoneQuery
                {
                    WarehouseID = warehouseId,
                    WarehouseName = warehouseName,
                    ZoneID = zoneId
                });
                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依 WarehouseId 與 ZoneId 查詢單一區域
        // GET: api/setting/zone/{warehouseId}/{zoneId}
        [HttpGet("zone/{warehouseId}/{zoneId}")]
        public async Task<IActionResult> GetZoneById(string warehouseId, string zoneId)
        {
            try
            {
                var result = await _mediator.Send(new GetZoneByIDQuery(warehouseId, zoneId));
                if (result == null)
                    return NotFound();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        #endregion

        #region Parameter Endpoints

        // 新增客戶
        // POST: api/setting/parameter
        [HttpPost("parameter")]
        public async Task<IActionResult> CreateParameter([FromBody] CreateParameterDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";
                dto.CreateBy = username;

                var result = await _mediator.Send(new CreateParameterCommand(dto));
                return CreatedAtAction(nameof(GetParameterById), new { funcgroup = result.FuncGroup, funckey = result.FuncKey }, result);
            }
            catch (Exception ex) 
            {
                return StatusCode(500,new { message =  "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 更新客戶
        // PUT: api/setting/parameter/{funcgroup}/{funckey}
        [HttpPut("parameter/{funcgroup}/{funckey}")]
        public async Task<IActionResult> UpdateParameter(string funcgroup, string funckey, [FromBody] UpdateParameterDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";
                dto.UpdateBy = username;

                if (funcgroup != dto.FuncGroup || funckey != dto.FuncKey)
                    return BadRequest(new { message = "傳入的 FuncGroup或 FuncKey與資料內容不符" });

                await _mediator.Send(new UpdateParameterCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
        }

        // 刪除客戶
        // DELETE: api/setting/parameter/{funcgroup}/{funckey}
        [HttpDelete("parameter/{funcgroup}/{funckey}")]
        public async Task<IActionResult> DeleteParameter(string funcgroup, string funckey, [FromBody] DeleteParameterDto dto)
        {
            try
            {
                var username = Request.Headers["X-User-Name"].FirstOrDefault()
                                ?? "N/A";
                dto.DeleteBy = username;

                if (funcgroup != dto.FuncGroup || funckey != dto.FuncKey)
                    return BadRequest(new { message = "傳入的 FuncGroup或 FuncKey與資料內容不符" });

                await _mediator.Send(new DeleteParameterCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依條件查詢客戶，回傳 List
        // GET: api/setting/parameter/getall
        [HttpGet("parameter/getall")]
        public async Task<IActionResult> GetAllParameters()
        {
            try
            {
                var results = await _mediator.Send(new GetAllParametersQuery());
                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        // 依 ParameterId 查詢單一客戶
        // GET: api/setting/parameter/{funcGroup}/{funckey}
        [HttpGet("parameter/{funcGroup}/{funckey}")]
        public async Task<IActionResult> GetParameterById(string funcGroup, string funckey)
        {
            try
            {
                var result = await _mediator.Send(new GetParameterByIDQuery(funcGroup, funckey));
                if (result == null)
                    return NotFound();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
            
        }

        #endregion

        #region Endpoint Endpoints

        // 新增客戶
        // POST: api/setting/endpoint
        [HttpPost("endpoint")]
        public async Task<IActionResult> CreateEndpoint([FromBody] CreateEndpointDto dto)
        {
            try
            {
                //var username = Request.Headers["X-User-Name"].FirstOrDefault()
                //                ?? "N/A";
                //dto.CreateBy = username;

                var result = await _mediator.Send(new CreateEndpointCommand(dto));
                return CreatedAtAction(nameof(GetEndpointById), new { customerID = result.CustomerID, warehouseID = result.WarehouseID, zoneID = result.ZoneID, requestType = result.RequestType, branch = result.Branch }, result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }

        }

        // 更新客戶
        // PUT: api/setting/endpoint/{customerID}/{warehouseID}/{zoneID}/{requestType}/{branch}
        [HttpPut("endpoint/{customerID}/{warehouseID}/{zoneID}/{requestType}/{branch}")]
        public async Task<IActionResult> UpdateEndpoint(string customerID, string warehouseID, string zoneID, string requestType, string branch, [FromBody] UpdateEndpointDto dto)
        {
            try
            {
                //var username = Request.Headers["X-User-Name"].FirstOrDefault()
                //                ?? "N/A";
                //dto.UpdateBy = username;

                if (customerID != dto.CustomerID || warehouseID != dto.WarehouseID || zoneID != dto.ZoneID || requestType != dto.RequestType || branch != dto.Branch)
                    return BadRequest(new { message = "傳入的 FuncGroup或 FuncKey與資料內容不符" });

                await _mediator.Send(new UpdateEndpointCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }
        }

        // 刪除客戶
        // DELETE: api/setting/endpoint/{customerID}/{warehouseID}/{zoneID}/{requestType}/{branch}
        [HttpDelete("endpoint/{customerID}/{warehouseID}/{zoneID}/{requestType}/{branch}")]
        public async Task<IActionResult> DeleteEndpoint(string customerID, string warehouseID, string zoneID, string requestType, string branch, [FromBody] DeleteEndpointDto dto)
        {
            try
            {
                //var username = Request.Headers["X-User-Name"].FirstOrDefault()
                //                ?? "N/A";
                //dto.DeleteBy = username;

                if (customerID != dto.CustomerID || warehouseID != dto.WarehouseID || zoneID != dto.ZoneID || requestType != dto.RequestType || branch != dto.Branch)
                    return BadRequest(new { message = "傳入的 FuncGroup或 FuncKey與資料內容不符" });

                await _mediator.Send(new DeleteEndpointCommand(dto));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }

        }

        // 依條件查詢客戶，回傳 List
        // GET: api/setting/endpoint/getall
        [HttpGet("endpoint/getall")]
        public async Task<IActionResult> GetAllEndpoints()
        {
            try
            {
                var results = await _mediator.Send(new GetAllEndpointsQuery());
                return Ok(results);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }

        }

        // 依 EndpointId 查詢單一客戶
        // GET: api/setting/endpoint//{customerID}/{warehouseID}/{zoneID}/{requestType}/{branch}
        [HttpGet("endpoint/{customerID}/{warehouseID}/{zoneID}/{requestType}/{branch}")]
        public async Task<IActionResult> GetEndpointById(string customerID, string warehouseID, string zoneID, string requestType, string branch)
        {
            try
            {
                var result = await _mediator.Send(new GetEndpointByIDQuery(customerID, warehouseID, zoneID, requestType, branch));
                if (result == null)
                    return NotFound();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "處理時發生異常，異常原因：" + ex.Message });
            }

        }

        #endregion
    }
}
