﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.Services.Users;
using Serilog.Context;
using SharedKernel.Interface;
using SystemService.Application.Commands.User;
using SystemService.Application.Commands.UserFuntion;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;

namespace SystemService.Presentation.Controllers
{

    [ApiController]
    [Route("UI/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ISharedLogger<AuthController> _logger;
        private readonly IMenuRepository _menuRepository;

        public AuthController(IMediator mediator, ISharedLogger<AuthController> logger, IMenuRepository menuRepository)
        {
            _mediator = mediator;
            _logger = logger;
            _menuRepository = menuRepository;
        }

        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] RegisterUserRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                _logger.LogInformation($"Username: {request.Username} request to register.");
                var command = new RegisterUserCommand(request.Username, request.Password, request.Email ?? "", request.Level);
                var userId = await _mediator.Send(command);
                _logger.LogInformation($"Username: {request.Username} register sucess.");
                return Ok(new { UserId = userId });
            }
            catch (UserAlreadyExistsException ex)
            {
                _logger.LogWarning($"Username: {request.Username} register failed because of Username is already exist.");
                return Conflict(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Username: {request.Username} register failed because of an error occur while registering the user.");
                return StatusCode(500, new { Message = "An error occurred while registering the user." });
            }
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginUserRequest request)
        {
            // 0. 取得 / 產生 correlationId
            //var correlationId = Request.Headers["X-CorrelationId"].FirstOrDefault()
            //                    ?? Guid.NewGuid().ToString();
            var correlationId = HttpContext.Items["CorrelationId"] as string
                        ?? Guid.NewGuid().ToString();

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (LogContext.PushProperty("CorrelationId", correlationId))
            {
                try
                {
                    // === 1. 記錄 API_CALL、技術層面資訊 ===
                    _logger.LogInformation($"Username: {request.Username} request to login.", correlationId);

                    // 執行登入Command
                    var command = new LoginUserCommand(request.Username, request.Password, correlationId);
                    var token = await _mediator.Send(command);
                    var menu = await _menuRepository.GetMenuAsync();

                    //List<MenuDto>? menu = null;

                    //if (token != null)
                    //{
                    //    menu = await _menuRepository.GetMenuAsync();
                    //}

                    // === 2. API層技術日誌：成功 ===
                    _logger.LogInformation($"Username: {request.Username} login success. Token content is {token}.", correlationId);


                    // === 3. 業務事件：UserLoginSucceeded ===
                    //  (示例) _logger.LogEvent( eventName, isSuccess, payload, userId )
                    _logger.LogEvent(
                        eventName: "User.Login.Sucessed",
                        isSuccess: true,
                        payload: new { Username = request.Username, Token = token },
                        userId: request.Username,
                        correlationId: correlationId
                    );

                    //return Ok(new { Token = token });
                    return Ok(new loginResult
                    {
                        token = token,
                        menu = menu,
                    });
                }
                catch (UnauthorizedAccessException ex)
                {
                    // === 2. API層技術日誌：失敗(Unauthorized) ===
                    _logger.LogWarning($"Username: {request.Username} login failed (Unauthorized).", correlationId);

                    // === 3. 業務事件：UserLoginFailed ===
                    _logger.LogEvent(
                        eventName: "User.Login.Failed",
                        isSuccess: false,
                        payload: new { Username = request.Username, Reason = "Unauthorized" },
                        userId: request.Username,
                        correlationId: correlationId
                    );

                    return Unauthorized(new { Message = ex.Message });
                }
                catch (Exception ex)
                {
                    // === 2. API層技術日誌：系統錯誤 ===
                    _logger.LogError(ex, $"Username: {request.Username} login failed due to system error.", correlationId);

                    // === 3. 業務事件：UserLoginFailed ===
                    _logger.LogEvent(
                        eventName: "User.Login.Failed",
                        isSuccess: false,
                        payload: new { Username = request.Username, Reason = "System Error", Exception = ex.Message },
                        userId: request.Username,
                        correlationId: correlationId
                    );

                    return StatusCode(500, new { Message = "An error occurred while logging in." });
                }
            }


            
        }

        [HttpPost("refresh-token")]
        [AllowAnonymous]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenRequest request)
        {
            try
            {
                var command = new RefreshTokenCommand(request.RefreshToken);
                var newToken = await _mediator.Send(command);
                return Ok(new { Token = newToken });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, new { Message = "An error occurred while refreshing the token." });
            }
        }

        [HttpPost("logout")]
        [Authorize]
        public async Task<IActionResult> Logout([FromBody] LogoutRequest request)
        {
            try
            {
                var command = new LogoutCommand(request.RefreshToken);
                await _mediator.Send(command);
                return Ok(new { Message = "Logged out successfully." });
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, new { Message = "An error occurred while logging out." });
            }
        }
    }

    public class RegisterUserRequest
    {
        public required string Username { get; set; }

        public required string Password { get; set; }

        public string? Email { get; set; }

        public required int Level { get; set; }
    }

    public class LoginUserRequest
    {
        public required string Username { get; set; }

        public required string Password { get; set; }
    }

    public class RefreshTokenRequest
    {
        public required string RefreshToken { get; set; }
    }

    public class LogoutRequest
    {
        public required string RefreshToken { get; set; }
    }

    public class loginResult
    {
        public string token { get; set; } = string.Empty;
        public List<MenuDto>? menu { get; set; } = new();
    }

}
