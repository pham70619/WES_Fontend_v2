﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence;

namespace SystemService.Presentation.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly SystemDbContext _context;
        private readonly IMapper _mapper;
        private readonly IMenuRepository _menuRepository;

        public MenuController(SystemDbContext context, IMapper mapper, IMenuRepository menuRepository)
        {
            _context = context;
            _mapper = mapper;
            _menuRepository = menuRepository;
        }

        [HttpGet("getMenu")]
        public async Task<IActionResult> GetAllMenu()
        {
            var menu = await _menuRepository.GetMenuAsync();
            //try
            //{
            //    var menus = await _context.Wes_Menu
            //    .OrderBy(m => m.SORT_ORDER)
            //    .ToListAsync();

            //    var dtos = _mapper.Map<List<MenuDto>>(menus);
            //    return Ok(dtos);
            //}
            //catch(Exception ex)
            //{
            //    Console.WriteLine("loi khi truy van:");
            //    Console.WriteLine(ex.Message);
            //    Console.WriteLine(ex.StackTrace);

            //    return StatusCode(500, new
            //    {
            //        Message = "da xay ra loi",
            //        error = ex.Message
            //    });
            //}
            return Ok(menu);
        }


        [HttpPost("updateMenu")]
        public async Task<IActionResult> SaveMenuTree([FromBody] List<MenuDto> menuList)
        {
            if (menuList == null || !menuList.Any())
                return BadRequest("Menu list is empty.");

            await _menuRepository.SaveMenuTreeAsync(menuList);
            return Ok(new { message = "Menu tree saved successfully." });
        }

        [HttpPost("deleteMenu")]
        public async Task<IActionResult> DeleteMenu([FromBody] List<int> menuIds)
        {
            if (menuIds == null || !menuIds.Any())
                return BadRequest("No menu IDs provided.");
            try
            {
                await _menuRepository.DeleteMenuDataAsync(menuIds);
                return Ok(new { message = "Menus deleted successfully." });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting menus.", detail = ex.Message });
            }
        }
    }
}
