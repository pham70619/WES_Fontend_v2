﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SharedKernel.Interface;
using System.Security.Claims;
using System.Text;

namespace SystemService.Presentation.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HealthController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ISharedLogger<HealthController> _logger;

        public HealthController(IMediator mediator, ISharedLogger<HealthController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        [HttpGet("health")]
        [AllowAnonymous]
        public IActionResult Health()
        {
            try
            {
                // 可以進一步擴展，例如檢查資料庫連線、依賴服務的健康狀態等。
                return Ok(new { Status = "Healthy", Timestamp = DateTime.UtcNow });
            }
            catch (Exception ex)
            {
                // 如果需要，可記錄錯誤日誌
                return StatusCode(500, new { Status = "Unhealthy", Message = ex.Message });
            }
        }

        /// <summary>
        /// 只允許 Admin 角色或符合 "AdminOnly" Policy 的使用者可呼叫。
        /// 此端點一次性呼叫所有日誌方法，測試日誌系統。
        /// </summary>
        [HttpPost("Logtest")]
        //[Authorize(Policy = "AdminOnly")]
        [AllowAnonymous]
        public IActionResult LogTest()
        {
            bool test = true;
            try
            {
                if (test)
                {
                    throw new Exception("Test");
                }
            }
            catch (Exception ex) 
            {
                _logger.LogError(ex, "Test",Guid.NewGuid().ToString());
            }

            


            _logger.LogInformation("測試LOG功能");


            return Ok($"All log methods invoked.");
        }


    }
}
