﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence.Repositories;

namespace SystemService.Presentation.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class CompanyMenuController : ControllerBase
    {
        private readonly ICompanyMenuRepository _companyMenuRepository;

        public CompanyMenuController(ICompanyMenuRepository companuMenuRepository)
        {
            _companyMenuRepository = companuMenuRepository;
        }

        // get all data
        [HttpGet("getCompanyMenu")]
        public async Task<IActionResult> getCompanyMenu()
        {
            try
            {
                var companyMenus = await _companyMenuRepository.GetCompanyMenuDataAsync();
                return Ok(companyMenus);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] GetCompany failed: {ex.Message}");
                return StatusCode(500, new { message = "Internal error", detail = ex.Message });
            }
        }

        // add new company Menu
        [HttpPost("addCompanyMenu")]
        public async Task<IActionResult> AddCompanyMenu([FromBody] List<updateCompanyMenuDto> companyMenus)
        {
            if (companyMenus == null || !companyMenus.Any())
            {
                return BadRequest(new { message = "No data received." });
            }

            try
            {
                await _companyMenuRepository.UpdateCompanyMenuDataAsync(companyMenus);
                return Ok(new { message = "Company menu added susseccfully" });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] AddCompanyMenu failed: {ex.Message}");
                return StatusCode(500, new { message = "Internal error", detail = ex.Message });
            }
        }

        [HttpPost("deleteCompanyMenu")]
        public async Task<IActionResult> DeleteCompanyMenu([FromBody] List<deleteCompanyMenuDto> companyMenus)
        {
            try
            {
                await _companyMenuRepository.DeleteCompanyMenuDataAsync(companyMenus);
                return Ok(new { message = "Xóa dữ liệu thành công." });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi hệ thống", detail = ex.Message });
            }
        }
    }
}
