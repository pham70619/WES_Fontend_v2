using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Quartz.Impl;
using Quartz.Spi;
using Quartz;
using Serilog;
using SharedKernel.Extensions;
using SharedKernel.Messaging;
using System.Text;
using SystemService.Application.Commands.User;
using SystemService.Application.Handlers.User;
using SystemService.Application.Handlers.UserFuntion;
using SystemService.Domain.Interface;
using SystemService.Domain.Interface.User;
using SystemService.Domain.Interface.UserFuntion;
using SystemService.Infrastructure.Configurations;
using SystemService.Infrastructure.Mappers;
using SystemService.Infrastructure.Persistence;
using SystemService.Infrastructure.Persistence.Repositories;
using SystemService.Infrastructure.Services;
using SystemService.Domain.Interface.Health;
using SystemService.Application.Services.Order;
using SystemService.Infrastructure.Quartz;
using OutboundService.Infrastructure.Quartz.Jobs.Order;
using SharedKernel.Logging;
using SharedKernel.Configurations;
using SystemService.Infrastructure.Messaging;
using SystemService.Domain.Interface.Messaging;
using SystemService.Infrastructure.RabbieMQ;
using SystemService.Application.Handlers.Setting;
using SystemService.Domain.Interface.Setting;
using SystemService.Domain.Interface.EventDespath;
using SystemService.Application.Services.EventDespath;
using SystemService.Infrastructure.Quartz.Jobs.EventDespath;
using SystemService.Application.Services;

var builder = WebApplication.CreateBuilder(args);


# region MediatR

// ���U MediatR
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(LoginUserHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(RegisterUserHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(RefreshTokenHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(LogoutHandler).Assembly));

builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(CreateCustomerHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(UpdateCustomerHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(DeleteCustomerHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(SearchCustomerHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetCustomerByIDHandler).Assembly));

builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(CreateWarehouseHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(UpdateWarehouseHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(DeleteWarehouseHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(SearchWarehouseHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetWarehouseByIDHandler).Assembly));

builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(CreateZoneHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(UpdateZoneHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(DeleteZoneHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(SearchZoneHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetZoneByIDHandler).Assembly));

builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(CreateParameterHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(UpdateParameterHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(DeleteParameterHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetAllParametersHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetParameterByIDHandler).Assembly));

builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(CreateEndpointHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(UpdateEndpointHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(DeleteEndpointHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetAllEndpointsHandler).Assembly));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(GetEndpointByIDHandler).Assembly));

#endregion

# region AutoMapper

// ���U AutoMapper

builder.Services.AddAutoMapper(typeof(MappingProfile));

#endregion

# region DB�s�u���U

//��Ʈw���U
//builder.Services.AddDbContext<SystemDbContext>(options =>
//    options.UseNpgsql(builder.Configuration.GetConnectionString("SystemLogDB")));

string databaseType = builder.Configuration.GetValue<string>("DatabaseType") ?? "PostgreSQL";
string connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? "Host=172.20.95.62,172.20.95.63;Port=5432;Database=InventoryManagementDB;Username=postgres;Password=Aa@111318526";

builder.Services.AddDbContext<SystemDbContext>(options =>
{
    switch (databaseType)
    {
        case "PostgreSQL":
            options.UseNpgsql(connectionString);
            break;

        case "Oracle":
            options.UseOracle(connectionString);
            break;

        //case "MSSQL":
        //    options.use(connectionString);
        //    break;

        default:
            throw new InvalidOperationException("Unsupported database type");
    }
});

#endregion

#region RabbitMQ

builder.Services.AddSingleton<IRabbitMQConnection, RabbitMQConnection>();

builder.Services.AddSingleton<IEventPublisher, SystemProducer>();

builder.Services.AddHostedService<EventConsumer>();

#endregion

# region �@�ΪA�ȵ��U

builder.Services.Configure<LoggingConfiguration>(builder.Configuration.GetSection("LoggingConfiguration"));


//�@�ήw�A�ȵ��U
builder.Services.ConfigureRabbitMQ(builder.Configuration); // �j�wRabbitMQ �t�m

builder.Services.AddSharedLogging(builder.Configuration, "SystemService"); // log

builder.Services.AddSharedDbContext(builder.Configuration); // ��������db

builder.Services.AddSharedServices(); // �����T�{�P���H�o�e

builder.Services.AddRabbitMQ()
        .AddRabbitMQInitializer();

#endregion

#region ���U��Ʈw�A��

builder.Services.AddScoped<ISystemRepository, SystemRepository>();
builder.Services.AddScoped<ISettingRepository, SettingRepository>();
builder.Services.AddScoped<IEventRepository, EventRepository>();
builder.Services.AddScoped<IMenuRepository, MenuRepository>();
builder.Services.AddScoped<ICompanyRepository, CompanyRepository>();
builder.Services.AddScoped<ICompanyMenuRepository, CompanyMenuRepository>();
builder.Services.AddScoped<IRoleRepository, RoleRepository>();
builder.Services.AddScoped<IRoleService, RoleService>();

#endregion

# region Quartz

// �t�m Quartz

builder.Services.AddScoped<IHealthCheckAppService, HealthCheckAppService>();
builder.Services.AddScoped<IEventDespatchAppService, EventDespatchAppService>();
builder.Services.AddScoped<IEventUpdateAppService, EventUpdateAppService>();


// �t�m Quartz
builder.Services.AddSingleton<IJobFactory, SingletonJobFactory>();
builder.Services.AddSingleton<ISchedulerFactory, StdSchedulerFactory>();

// �`�J Job

builder.Services.AddTransient<HealthCheckJob>();
builder.Services.AddTransient<EventDespathJob>();



builder.Services.AddSingleton(new JobSchedule(
    jobType: typeof(HealthCheckJob),
    cronExpression: "0 0/5 * * * ?")); //�C������0���}�l �C10������@��

builder.Services.AddSingleton(new JobSchedule(
    jobType: typeof(EventDespathJob),
    cronExpression: "0/10 * * * * ?")); //�C������0���}�l �C10������@��

builder.Services.AddHostedService<QuartzHostedService>();

#endregion

#region API�v��

// API�v��
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

builder.Services.AddControllers();

#endregion

builder.Services.AddTransient<IPasswordHasher, PasswordHasher>();


// �t�m JwtSettings
builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection("JwtSettings"));
var jwtSettings = builder.Configuration.GetSection("JwtSettings").Get<JwtSettings>();

// �t�m JWT �{��
var key = Encoding.ASCII.GetBytes(jwtSettings.Secret);
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings.Issuer,
        ValidAudience = jwtSettings.Audience,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ClockSkew = TimeSpan.Zero,
        //RoleClaimType = "role",
        //NameClaimType = "unique_name"
    };
});

// ���U JwtTokenGenerator
builder.Services.AddScoped<IJwtTokenGenerator, JwtTokenGenerator>();


// ���U���v�F���]�i��^
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy => policy.RequireRole("AD"));
    options.AddPolicy("Manager", policy => policy.RequireRole("SS", "MM", "SM"));
    options.AddPolicy("OpAndMaintenance", policy => policy.RequireRole("OP", "ME"));
    // �ھڻݭn�K�[��h�F��
});

#region �t�γ]�w

builder.Host.UseSerilog();

builder.Services.AddControllers()
                .AddXmlSerializerFormatters(); // �K�[ XML �ϧǦC�Ƥ��

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();



// �t�m CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(
        policy =>
        {
            policy
                //.WithOrigins("https://your-frontend-domain.com") // ���w���\���ӷ�
                .AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod();
        });
});

var app = builder.Build();

#endregion

#region �إ�APP���l��

//��l�ƶ��C
using (var scope = app.Services.CreateScope())
{
    var rabbitMQInitializer = scope.ServiceProvider.GetRequiredService<RabbitMQInitializer>();
    rabbitMQInitializer.Initialize();
}

//����AutoMapper
try
{
    var configuration = new MapperConfiguration(cfg =>
    {
        cfg.AddProfile<MappingProfile>();
    });

    configuration.AssertConfigurationIsValid();
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
    throw;
}



#endregion

#region app�Ұ�

app.UseSwagger();

app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseRouting();

//app.UseCors("DynamicCorsPolicy");

app.UseCors("AllowAll");

app.UseAuthentication();

app.UseAuthorization();

app.UseMiddleware<RequestResponseLoggingMiddleware>();

app.MapControllers();

app.Run();

#endregion
