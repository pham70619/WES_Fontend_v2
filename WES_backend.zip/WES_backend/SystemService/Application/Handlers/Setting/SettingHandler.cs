﻿using MediatR;
using static SystemService.Application.Commands.Setting.SettingCommand;
using System;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface.Setting;
using SystemService.Infrastructure.Persistence.Model;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.Extensions.Logging;

namespace SystemService.Application.Handlers.Setting
{

    #region Customer Handlers

    public class CreateCustomerHandler : IRequestHandler<CreateCustomerCommand, CustomerDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<CreateCustomerHandler> _logger;

        public CreateCustomerHandler(ISettingRepository settingRepository, ILogger<CreateCustomerHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<CustomerDto> Handle(CreateCustomerCommand request, CancellationToken cancellationToken)
        {
            try
            {
                // 單一卡控：檢查是否已存在相同的 CustomerID
                var existing = await _settingRepository.GetCustomerByIdAsync(request.Dto.CustomerID);
                if (existing != null)
                {
                    _logger.LogWarning("Create customer failed. Customer with ID {CustomerID} already exists.", request.Dto.CustomerID);
                    throw new InvalidOperationException($"Customer with ID '{request.Dto.CustomerID}' already exists.");
                }

                var customer = new CustomerEntity
                {
                    CustomerID = request.Dto.CustomerID,
                    CustomerName = request.Dto.CustomerName,
                    Description = request.Dto.Description ?? null,
                    CreateAt = DateTime.Now,
                    CreateBy = request.Dto.CreateBy,
                    // 其他屬性依需求設定
                };

                await _settingRepository.AddCustomerAsync(customer);

                await _settingRepository.SaveChangesAsync();
                _logger.LogInformation("Customer {CustomerID} created successfully.", customer.CustomerID);

                return new CustomerDto(customer.CustomerID, customer.CustomerName, customer.Description);
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class UpdateCustomerHandler : IRequestHandler<UpdateCustomerCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<UpdateCustomerHandler> _logger;

        public UpdateCustomerHandler(ISettingRepository settingRepository, ILogger<UpdateCustomerHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(UpdateCustomerCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var customer = await _settingRepository.GetCustomerByIdAsync(request.Dto.CustomerID);
                if (customer == null)
                {
                    _logger.LogWarning("Update customer failed. Customer with ID {CustomerID} not found.", request.Dto.CustomerID);
                    throw new InvalidOperationException($"Customer with ID '{request.Dto.CustomerID}' not found.");
                }

                // 更新欄位
                customer.CustomerName = request.Dto.CustomerName;
                customer.UpdateAt = DateTime.Now;

                await _settingRepository.UpdateCustomerAsync(customer);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Customer {CustomerID} updated successfully.", customer.CustomerID);

                return Unit.Value;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class DeleteCustomerHandler : IRequestHandler<DeleteCustomerCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<DeleteCustomerHandler> _logger;

        public DeleteCustomerHandler(ISettingRepository settingRepository, ILogger<DeleteCustomerHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(DeleteCustomerCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var customer = await _settingRepository.GetCustomerByIdAsync(request.Dto.CustomerID);
                if (customer == null)
                {
                    _logger.LogWarning("Delete customer failed. Customer with ID {CustomerID} not found.", request.Dto.CustomerID);
                    throw new InvalidOperationException($"Customer with ID '{request.Dto.CustomerID}' not found.");
                }

                await _settingRepository.DeleteCustomerAsync(customer);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Customer {CustomerID} deleted successfully.", request.Dto.CustomerID);

                return Unit.Value;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class SearchCustomerHandler : IRequestHandler<SearchCustomerQuery, List<CustomerDto>>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<SearchCustomerHandler> _logger;

        public SearchCustomerHandler(ISettingRepository settingRepository, ILogger<SearchCustomerHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<List<CustomerDto>> Handle(SearchCustomerQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var customers = await _settingRepository.SearchCustomersAsync(request.CustomerID, request.CustomerName);
                // 假設 SearchAsync 方法根據條件回傳符合的 Customer 實體集合

                var result = new List<CustomerDto>();
                foreach (var c in customers)
                {
                    result.Add(new CustomerDto(c.CustomerID, c.CustomerName));
                }

                _logger.LogInformation("{Count} customers found for search criteria.", result.Count);
                return result;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class GetCustomerByIDHandler : IRequestHandler<GetCustomerByIDQuery, CustomerDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<GetCustomerByIDHandler> _logger;

        public GetCustomerByIDHandler(ISettingRepository settingRepository, ILogger<GetCustomerByIDHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<CustomerDto> Handle(GetCustomerByIDQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var customer = await _settingRepository.GetCustomerByIdAsync(request.CustomerID);
                if (customer == null)
                {
                    _logger.LogWarning("Get customer failed. Customer with ID {CustomerID} not found.", request.CustomerID);
                    throw new InvalidOperationException($"Customer with ID '{request.CustomerID}' not found.");
                }

                return new CustomerDto(customer.CustomerID, customer.CustomerName);
            }
            catch
            {
                throw;
            }
            
        }
    }

    #endregion

    #region Warehouse Handlers

    public class CreateWarehouseHandler : IRequestHandler<CreateWarehouseCommand, WarehouseDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<CreateWarehouseHandler> _logger;

        public CreateWarehouseHandler(ISettingRepository settingRepository, ILogger<CreateWarehouseHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<WarehouseDto> Handle(CreateWarehouseCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var existing = await _settingRepository.GetWarehouseByIdAsync(request.Dto.WarehouseID);
                if (existing != null)
                {
                    _logger.LogWarning("Create warehouse failed. Warehouse with ID {WarehouseID} already exists.", request.Dto.WarehouseID);
                    throw new InvalidOperationException($"Warehouse with ID '{request.Dto.WarehouseID}' already exists.");
                }

                var warehouse = new WarehouseEntity
                {
                    CustomerID = request.Dto.CustomerID,
                    WarehouseID = request.Dto.WarehouseID,
                    WarehouseName = request.Dto.WarehouseName,
                    Address = request.Dto.Address,
                    CreateAt = DateTime.Now,
                    CreateBy = request.Dto.CreateBy,
                };

                await _settingRepository.AddWarehouseAsync(warehouse);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Warehouse {WarehouseID} created successfully.", warehouse.WarehouseID);

                return new WarehouseDto(warehouse.WarehouseID, warehouse.WarehouseName, warehouse.Description, warehouse.Address);
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class UpdateWarehouseHandler : IRequestHandler<UpdateWarehouseCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<UpdateWarehouseHandler> _logger;

        public UpdateWarehouseHandler(ISettingRepository settingRepository, ILogger<UpdateWarehouseHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(UpdateWarehouseCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var warehouse = await _settingRepository.GetWarehouseByIdAsync(request.Dto.WarehouseID);
                if (warehouse == null)
                {
                    _logger.LogWarning("Update warehouse failed. Warehouse with ID {WarehouseID} not found.", request.Dto.WarehouseID);
                    throw new InvalidOperationException($"Warehouse with ID '{request.Dto.WarehouseID}' not found.");
                }

                warehouse.WarehouseName = request.Dto.WarehouseName;
                warehouse.UpdateAt = DateTime.Now;

                await _settingRepository.UpdateWarehouseAsync(warehouse);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Warehouse {WarehouseID} updated successfully.", warehouse.WarehouseID);

                return Unit.Value;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class DeleteWarehouseHandler : IRequestHandler<DeleteWarehouseCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<DeleteWarehouseHandler> _logger;

        public DeleteWarehouseHandler(ISettingRepository settingRepository, ILogger<DeleteWarehouseHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(DeleteWarehouseCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var warehouse = await _settingRepository.GetWarehouseByIdAsync(request.Dto.WarehouseID);
                if (warehouse == null)
                {
                    _logger.LogWarning("Delete warehouse failed. Warehouse with ID {WarehouseID} not found.", request.Dto.WarehouseID);
                    throw new InvalidOperationException($"Warehouse with ID '{request.Dto.WarehouseID}' not found.");
                }

                await _settingRepository.DeleteWarehouseAsync(warehouse);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Warehouse {WarehouseID} deleted successfully.", request.Dto.WarehouseID);

                return Unit.Value;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class SearchWarehouseHandler : IRequestHandler<SearchWarehouseQuery, List<WarehouseDto>>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<SearchWarehouseHandler> _logger;

        public SearchWarehouseHandler(ISettingRepository settingRepository, ILogger<SearchWarehouseHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<List<WarehouseDto>> Handle(SearchWarehouseQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var warehouses = await _settingRepository.SearchWarehousesAsync(request.WarehouseID, request.WarehouseName);
                var result = new List<WarehouseDto>();
                foreach (var w in warehouses)
                {
                    result.Add(new WarehouseDto(w.WarehouseID, w.WarehouseName));
                }
                _logger.LogInformation("{Count} warehouses found for search criteria.", result.Count);
                return result;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class GetWarehouseByIDHandler : IRequestHandler<GetWarehouseByIDQuery, WarehouseDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<GetWarehouseByIDHandler> _logger;

        public GetWarehouseByIDHandler(ISettingRepository settingRepository, ILogger<GetWarehouseByIDHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<WarehouseDto> Handle(GetWarehouseByIDQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var warehouse = await _settingRepository.GetWarehouseByIdAsync(request.WarehouseID);
                if (warehouse == null)
                {
                    _logger.LogWarning("Get warehouse failed. Warehouse with ID {WarehouseID} not found.", request.WarehouseID);
                    throw new InvalidOperationException($"Warehouse with ID '{request.WarehouseID}' not found.");
                }

                return new WarehouseDto(warehouse.WarehouseID, warehouse.WarehouseName);
            }
            catch
            {
                throw;
            }
            
        }
    }

    #endregion

    #region Zone Handlers

    public class CreateZoneHandler : IRequestHandler<CreateZoneCommand, ZoneDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<CreateZoneHandler> _logger;

        public CreateZoneHandler(ISettingRepository settingRepository, ILogger<CreateZoneHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<ZoneDto> Handle(CreateZoneCommand request, CancellationToken cancellationToken)
        {
            try
            {
                // 檢查複合主鍵是否已存在
                var existing = await _settingRepository.GetZoneByIdAsync(request.Dto.WarehouseID, request.Dto.ZoneID);
                if (existing != null)
                {
                    _logger.LogWarning("Create zone failed. Zone with WarehouseID {WarehouseID} and ZoneID {ZoneID} already exists.", request.Dto.WarehouseID, request.Dto.ZoneID);
                    throw new InvalidOperationException($"Zone with WarehouseID '{request.Dto.WarehouseID}' and ZoneID '{request.Dto.ZoneID}' already exists.");
                }

                var zone = new ZoneEntity
                {
                    WarehouseID = request.Dto.WarehouseID,
                    ZoneID = request.Dto.ZoneID,
                    CreateAt = DateTime.Now,
                    CreateBy = request.Dto.CreateBy,
                    Description = request.Dto.Description,
                };

                await _settingRepository.AddZoneAsync(zone);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Zone {ZoneID} in Warehouse {WarehouseID} created successfully.", zone.ZoneID, zone.WarehouseID);

                return new ZoneDto(zone.WarehouseID, zone.ZoneID, zone.Description);
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class UpdateZoneHandler : IRequestHandler<UpdateZoneCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<UpdateZoneHandler> _logger;

        public UpdateZoneHandler(ISettingRepository settingRepository, ILogger<UpdateZoneHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(UpdateZoneCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var zone = await _settingRepository.GetZoneByIdAsync(request.Dto.WarehouseID, request.Dto.ZoneID);
                if (zone == null)
                {
                    _logger.LogWarning("Update zone failed. Zone with WarehouseID {WarehouseID} and ZoneID {ZoneID} not found.", request.Dto.WarehouseID, request.Dto.ZoneID);
                    throw new InvalidOperationException($"Zone with WarehouseID '{request.Dto.WarehouseID}' and ZoneID '{request.Dto.ZoneID}' not found.");
                }

                // 如有其他欄位需更新，請在此更新
                zone.UpdateAt = DateTime.Now;

                await _settingRepository.UpdateZoneAsync(zone);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Zone {ZoneID} in Warehouse {WarehouseID} updated successfully.", zone.ZoneID, zone.WarehouseID);
                return Unit.Value;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class DeleteZoneHandler : IRequestHandler<DeleteZoneCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<DeleteZoneHandler> _logger;

        public DeleteZoneHandler(ISettingRepository settingRepository, ILogger<DeleteZoneHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(DeleteZoneCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var zone = await _settingRepository.GetZoneByIdAsync(request.Dto.WarehouseID, request.Dto.ZoneID);
                if (zone == null)
                {
                    _logger.LogWarning("Delete zone failed. Zone with WarehouseID {WarehouseID} and ZoneID {ZoneID} not found.", request.Dto.WarehouseID, request.Dto.ZoneID);
                    throw new InvalidOperationException($"Zone with WarehouseID '{request.Dto.WarehouseID}' and ZoneID '{request.Dto.ZoneID}' not found.");
                }

                await _settingRepository.DeleteZoneAsync(zone);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Zone {ZoneID} in Warehouse {WarehouseID} deleted successfully.", request.Dto.ZoneID, request.Dto.WarehouseID);
                return Unit.Value;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class SearchZoneHandler : IRequestHandler<SearchZoneQuery, List<ZoneDto>>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<SearchZoneHandler> _logger;

        public SearchZoneHandler(ISettingRepository settingRepository, ILogger<SearchZoneHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<List<ZoneDto>> Handle(SearchZoneQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var zones = await _settingRepository.SearchZonesAsync(request.WarehouseID, request.ZoneID, request.WarehouseName);
                var result = new List<ZoneDto>();

                foreach (var z in zones)
                {
                    result.Add(new ZoneDto(z.WarehouseID, z.ZoneID, z.Description));
                }

                _logger.LogInformation("{Count} zones found for search criteria.", result.Count);
                return result;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class GetZoneByIDHandler : IRequestHandler<GetZoneByIDQuery, ZoneDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<GetZoneByIDHandler> _logger;

        public GetZoneByIDHandler(ISettingRepository settingRepository, ILogger<GetZoneByIDHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<ZoneDto> Handle(GetZoneByIDQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var zone = await _settingRepository.GetZoneByIdAsync(request.WarehouseID, request.ZoneID);
                if (zone == null)
                {
                    _logger.LogWarning("Get zone failed. Zone with WarehouseID {WarehouseID} and ZoneID {ZoneID} not found.", request.WarehouseID, request.ZoneID);
                    throw new InvalidOperationException($"Zone with WarehouseID '{request.WarehouseID}' and ZoneID '{request.ZoneID}' not found.");
                }

                //var warehouse = await _settingRepository.GetWarehouseByIdAsync(zone.WarehouseID);
                return new ZoneDto(zone.WarehouseID, zone.ZoneID, zone.Description);
            }
            catch
            {
                throw;
            }
            
        }
    }

    #endregion

    #region Parameter Handlers

    public class CreateParameterHandler : IRequestHandler<CreateParameterCommand, ParameterDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<CreateParameterHandler> _logger;

        public CreateParameterHandler(ISettingRepository settingRepository, ILogger<CreateParameterHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<ParameterDto> Handle(CreateParameterCommand request, CancellationToken cancellationToken)
        {
            try
            {
                // 單一卡控：檢查是否已存在相同的 ParameterID
                var existing = await _settingRepository.GetParameterByIdAsync(request.Dto.FuncGroup, request.Dto.FuncKey);
                if (existing != null)
                {
                    _logger.LogWarning("Create parameter failed. Parameter with FuncGroup {FuncGroup} and FuncKey {FuncKey} already exists.", request.Dto.FuncGroup, request.Dto.FuncKey);
                    throw new InvalidOperationException($"Parameter with FuncGroup '{request.Dto.FuncGroup}' and FuncKey '{request.Dto.FuncKey}' already exists.");
                }

                var parameter = new ParameterEntity
                {
                    FuncGroup = request.Dto.FuncGroup,
                    FuncKey = request.Dto.FuncKey,
                    FuncSort = request.Dto.FuncSort,
                    FuncType = request.Dto.FuncType,
                    FuncValue = request.Dto.FuncValue,
                    Descript = request.Dto.Description,
                    CreateBy = request.Dto.CreateBy,
                    CreateAt = DateTime.Now,
                    // 初次建立時，更新人員與更新時間可設定與建立相同
                    UpdateBy = request.Dto.CreateBy,
                    UpdateAt = DateTime.Now
                };

                await _settingRepository.AddParameterAsync(parameter);

                await _settingRepository.SaveChangesAsync();
                _logger.LogInformation("Parameter with FuncGroup {FuncGroup} and FuncKey {FuncKey} created successfully.", parameter.FuncGroup, parameter.FuncKey);

                return new ParameterDto(
                    parameter.FuncGroup,
                    parameter.FuncKey,
                    parameter.FuncSort,
                    parameter.FuncType,
                    parameter.FuncValue,
                    parameter.Descript);
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class UpdateParameterHandler : IRequestHandler<UpdateParameterCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<UpdateParameterHandler> _logger;

        public UpdateParameterHandler(ISettingRepository settingRepository, ILogger<UpdateParameterHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(UpdateParameterCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var parameter = await _settingRepository.GetParameterByIdAsync(request.Dto.FuncGroup, request.Dto.FuncKey);
                if (parameter == null)
                {
                    _logger.LogWarning("Update parameter failed. Parameter with FuncGroup {FuncGroup} and FuncKey {FuncKey} not found.", request.Dto.FuncGroup, request.Dto.FuncKey);
                    throw new InvalidOperationException($"Parameter with FuncGroup '{request.Dto.FuncGroup}' and FuncKey '{request.Dto.FuncKey}' not found.");
                }

                // 更新欄位
                // 更新欄位
                parameter.FuncSort = request.Dto.FuncSort;
                parameter.FuncValue = request.Dto.FuncValue;
                parameter.Descript = request.Dto.Description;
                parameter.UpdateBy = request.Dto.UpdateBy;
                parameter.UpdateAt = DateTime.Now;

                await _settingRepository.UpdateParameterAsync(parameter);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Parameter with FuncGroup {FuncGroup} and FuncKey {FuncKey} updated successfully.", parameter.FuncGroup, parameter.FuncKey);

                return Unit.Value;
            }
            catch
            {
                throw;
            }
            
        }
    }

    public class DeleteParameterHandler : IRequestHandler<DeleteParameterCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<DeleteParameterHandler> _logger;

        public DeleteParameterHandler(ISettingRepository settingRepository, ILogger<DeleteParameterHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(DeleteParameterCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var parameter = await _settingRepository.GetParameterByIdAsync(request.Dto.FuncGroup, request.Dto.FuncKey);
                if (parameter == null)
                {
                    _logger.LogWarning("Delete parameter failed. Parameter with FuncGroup {FuncGroup} and FuncKey {FuncKey} not found.", request.Dto.FuncGroup, request.Dto.FuncKey);
                    throw new InvalidOperationException($"Parameter with FuncGroup '{request.Dto.FuncGroup}' and FuncKey '{request.Dto.FuncKey}' not found.");
                }

                await _settingRepository.DeleteParameterAsync(parameter);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Parameter with FuncGroup {FuncGroup} and FuncKey {FuncKey} deleted successfully.", request.Dto.FuncGroup, request.Dto.FuncKey);

                return Unit.Value;
            }
            catch
            {
                throw;
            }
        }
    }

    public class GetAllParametersHandler : IRequestHandler<GetAllParametersQuery, List<ParameterDto>>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<GetAllParametersHandler> _logger;

        public GetAllParametersHandler(ISettingRepository settingRepository, ILogger<GetAllParametersHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<List<ParameterDto>> Handle(GetAllParametersQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var parameters = await _settingRepository.GetAllParametersAsync();

                var result = parameters.Select(p => new ParameterDto(
                    p.FuncGroup,
                    p.FuncKey,
                    p.FuncSort,
                    p.FuncType,
                    p.FuncValue,
                    p.Descript
                )).ToList();

                _logger.LogInformation("Retrieved {Count} parameters.", result.Count);
                return result;
            }
            catch 
            {
                throw;
            }
            
        }
    }

    public class GetParameterByIDHandler : IRequestHandler<GetParameterByIDQuery, ParameterDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<GetParameterByIDHandler> _logger;

        public GetParameterByIDHandler(ISettingRepository settingRepository, ILogger<GetParameterByIDHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<ParameterDto> Handle(GetParameterByIDQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var parameter = await _settingRepository.GetParameterByIdAsync(request.FuncGroup, request.FuncKey);
                if (parameter == null)
                {
                    _logger.LogWarning("Get parameter failed. Parameter with FuncGroup {FuncGroup} and FuncKey {FuncKey} not found.", request.FuncGroup, request.FuncKey);
                    throw new InvalidOperationException($"Zone with FuncGroup '{request.FuncGroup}' and FuncKey '{request.FuncKey}' not found.");
                }

                //var warehouse = await _settingRepository.GetWarehouseByIdAsync(zone.WarehouseID);
                return new ParameterDto(parameter.FuncGroup, parameter.FuncKey, parameter.FuncSort, parameter.FuncType, parameter.FuncValue);
            }
            catch
            {
                throw;
            }

        }
    }

    #endregion

    #region Endpoint Handlers

    public class CreateEndpointHandler : IRequestHandler<CreateEndpointCommand, EndpointDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<CreateEndpointHandler> _logger;

        public CreateEndpointHandler(ISettingRepository settingRepository, ILogger<CreateEndpointHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<EndpointDto> Handle(CreateEndpointCommand request, CancellationToken cancellationToken)
        {
            try
            {
                // 單一卡控：檢查是否已存在相同的 EndpointID
                var existing = await _settingRepository.GetEndpointByIdAsync(request.Dto.CustomerID, request.Dto.WarehouseID, request.Dto.ZoneID, request.Dto.RequestType, request.Dto.Branch );
                if (existing != null)
                {
                    _logger.LogWarning("Create endpoint failed. Endpoint with CustomerID {CustomerID} and WarehouseID {WarehouseID}  and ZoneID {ZoneID}  and RequestType {RequestType}  and Branch {Branch} already exists.", request.Dto.CustomerID, request.Dto.WarehouseID, request.Dto.ZoneID, request.Dto.RequestType, request.Dto.Branch);
                    throw new InvalidOperationException($"Endpoint with CustomerID '{request.Dto.CustomerID}' and WarehouseID '{request.Dto.WarehouseID}' and ZoneID '{request.Dto.ZoneID}' and RequestType '{request.Dto.RequestType}' and Branch '{request.Dto.Branch}' already exists.");
                }

                var endpoint = new EndpointEntity
                {
                    CustomerID = request.Dto.CustomerID,
                    WarehouseID = request.Dto.WarehouseID,
                    ZoneID = request.Dto.ZoneID,
                    RequestType = request.Dto.RequestType,
                    Branch = request.Dto.Branch,
                    Url = request.Dto.Url,
                    CommType = request.Dto.CommType,
                    AuthType = request.Dto.AuthType,
                    SerializationStrategy = request.Dto.SerializationStrategy
                };

                await _settingRepository.AddEndpointAsync(endpoint);

                await _settingRepository.SaveChangesAsync();
                _logger.LogInformation("Endpoint with CustomerID {CustomerID} and WarehouseID {WarehouseID}  and ZoneID {ZoneID}  and RequestType {RequestType}  and Branch {Branch} created successfully.", endpoint.CustomerID, endpoint.WarehouseID, endpoint.ZoneID, endpoint.RequestType, endpoint.Branch);

                return new EndpointDto
                (
                    endpoint.CustomerID,
                    endpoint.WarehouseID,
                    endpoint.ZoneID,
                    endpoint.RequestType,
                    endpoint.Branch,
                    endpoint.Url,
                    endpoint.CommType,
                    endpoint.AuthType,
                    endpoint.SerializationStrategy
                );
            }
            catch
            {
                throw;
            }

        }
    }

    public class UpdateEndpointHandler : IRequestHandler<UpdateEndpointCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<UpdateEndpointHandler> _logger;

        public UpdateEndpointHandler(ISettingRepository settingRepository, ILogger<UpdateEndpointHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(UpdateEndpointCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var endpoint = await _settingRepository.GetEndpointByIdAsync(request.Dto.CustomerID, request.Dto.WarehouseID, request.Dto.ZoneID, request.Dto.RequestType, request.Dto.Branch);
                if (endpoint == null)
                {
                    _logger.LogWarning("Update endpoint failed. Endpoint with CustomerID {CustomerID} and WarehouseID {WarehouseID}  and ZoneID {ZoneID}  and RequestType {RequestType}  and Branch {Branch}  not found.", request.Dto.CustomerID, request.Dto.WarehouseID, request.Dto.ZoneID, request.Dto.RequestType, request.Dto.Branch);
                    throw new InvalidOperationException($"Endpoint with CustomerID '{request.Dto.CustomerID}' and WarehouseID '{request.Dto.WarehouseID}' and ZoneID '{request.Dto.ZoneID}' and RequestType '{request.Dto.RequestType}' and Branch '{request.Dto.Branch}' not found.");

                }

                // 更新欄位
                // 更新欄位
                endpoint.Url = request.Dto.Url;
                endpoint.CommType = request.Dto.CommType;
                endpoint.AuthType = request.Dto.AuthType;
                endpoint.SerializationStrategy = request.Dto.SerializationStrategy;

                await _settingRepository.UpdateEndpointAsync(endpoint);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Endpoint with CustomerID {CustomerID} and WarehouseID {WarehouseID}  and ZoneID {ZoneID}  and RequestType {RequestType}  and Branch {Branch} updated successfully.", endpoint.CustomerID, endpoint.WarehouseID, endpoint.ZoneID, endpoint.RequestType, endpoint.Branch);

                return Unit.Value;
            }
            catch
            {
                throw;
            }

        }
    }

    public class DeleteEndpointHandler : IRequestHandler<DeleteEndpointCommand, Unit>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<DeleteEndpointHandler> _logger;

        public DeleteEndpointHandler(ISettingRepository settingRepository, ILogger<DeleteEndpointHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(DeleteEndpointCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var endpoint = await _settingRepository.GetEndpointByIdAsync(request.Dto.CustomerID, request.Dto.WarehouseID, request.Dto.ZoneID, request.Dto.RequestType, request.Dto.Branch);
                if (endpoint == null)
                {
                    _logger.LogWarning("Delete endpoint failed. Endpoint with CustomerID {CustomerID} and WarehouseID {WarehouseID}  and ZoneID {ZoneID}  and RequestType {RequestType}  and Branch {Branch}  not found.", request.Dto.CustomerID, request.Dto.WarehouseID, request.Dto.ZoneID, request.Dto.RequestType, request.Dto.Branch);
                    throw new InvalidOperationException($"Endpoint with CustomerID '{request.Dto.CustomerID}' and WarehouseID '{request.Dto.WarehouseID}' and ZoneID '{request.Dto.ZoneID}' and RequestType '{request.Dto.RequestType}' and Branch '{request.Dto.Branch}' not found.");
                }

                await _settingRepository.DeleteEndpointAsync(endpoint);

                await _settingRepository.SaveChangesAsync();

                _logger.LogInformation("Endpoint with CustomerID {CustomerID} and WarehouseID {WarehouseID}  and ZoneID {ZoneID}  and RequestType {RequestType}  and Branch {Branch} deleted successfully.", endpoint.CustomerID, endpoint.WarehouseID, endpoint.ZoneID, endpoint.RequestType, endpoint.Branch);

                return Unit.Value;
            }
            catch
            {
                throw;
            }
        }
    }

    public class GetAllEndpointsHandler : IRequestHandler<GetAllEndpointsQuery, List<EndpointDto>>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<GetAllEndpointsHandler> _logger;

        public GetAllEndpointsHandler(ISettingRepository settingRepository, ILogger<GetAllEndpointsHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<List<EndpointDto>> Handle(GetAllEndpointsQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var endpoints = await _settingRepository.GetAllEndpointsAsync();

                var result = endpoints.Select(p => new EndpointDto(
                    p.CustomerID,
                    p.WarehouseID,
                    p.ZoneID,
                    p.RequestType,
                    p.Branch,
                    p.Url,
                    p.CommType,
                    p.AuthType,
                    p.SerializationStrategy
                )).ToList();

                _logger.LogInformation("Retrieved {Count} endpoints.", result.Count);
                return result;
            }
            catch
            {
                throw;
            }

        }
    }

    public class GetEndpointByIDHandler : IRequestHandler<GetEndpointByIDQuery, EndpointDto>
    {
        private readonly ISettingRepository _settingRepository;
        private readonly ILogger<GetEndpointByIDHandler> _logger;

        public GetEndpointByIDHandler(ISettingRepository settingRepository, ILogger<GetEndpointByIDHandler> logger)
        {
            _settingRepository = settingRepository;
            _logger = logger;
        }

        public async Task<EndpointDto> Handle(GetEndpointByIDQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var endpoint = await _settingRepository.GetEndpointByIdAsync(request.CustomerID, request.WarehouseID, request.ZoneID, request.RequestType, request.Branch);
                if (endpoint == null)
                {
                    _logger.LogWarning("Get endpoint failed. Endpoint with CustomerID {CustomerID} and WarehouseID {WarehouseID}  and ZoneID {ZoneID}  and RequestType {RequestType}  and Branch {Branch}  not found.", request.CustomerID, request.WarehouseID, request.ZoneID, request.RequestType, request.Branch);
                    throw new InvalidOperationException($"Endpoint with CustomerID '{request.CustomerID}' and WarehouseID '{request.WarehouseID}' and ZoneID '{request.ZoneID}' and RequestType '{request.RequestType}' and Branch '{request.Branch}' not found.");
                }

                return new EndpointDto
                 (
                     endpoint.CustomerID,
                     endpoint.WarehouseID,
                     endpoint.ZoneID,
                     endpoint.RequestType,
                     endpoint.Branch,
                     endpoint.Url,
                     endpoint.CommType,
                     endpoint.AuthType,
                     endpoint.SerializationStrategy
                 );
            }
            catch
            {
                throw;
            }

        }
    }



    #endregion
}
