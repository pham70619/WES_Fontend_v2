﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.VisualStudio.Services.Users;
using SystemService.Application.Commands.User;
using SystemService.Domain.Interface;
using SystemService.Domain.Interface.User;
using SystemService.Domain.Interface.UserFuntion;
using SystemService.Domain.ValueObject;

namespace SystemService.Application.Handlers.User
{
    public class RegisterUserHandler : IRequestHandler<RegisterUserCommand, Guid>
    {
        private readonly ISystemRepository _userRepository;
        private readonly IPasswordHasher _passwordHasher;
        private readonly IJwtTokenGenerator _tokenGenerator;
        private readonly ILogger<RegisterUserHandler> _logger;


        public RegisterUserHandler(ISystemRepository userRepository, IPasswordHasher passwordHasher, IJwtTokenGenerator tokenGenerator, ILogger<RegisterUserHandler> logger)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
            _tokenGenerator = tokenGenerator;
            _logger = logger;
        }

        public async Task<Guid> Handle(RegisterUserCommand request, CancellationToken cancellationToken)
        {
            var existingUser = await _userRepository.GetByUsernameAsync(request.Username);
            if (existingUser != null)
            {
                throw new UserAlreadyExistsException($"User with username {request.Username} already exists.");
            }

            var password = new Password(request.Password);
            var user = new SystemService.Domain.Entity.User(request.Username, password.Hash, request.Email, request.Level);
            await _userRepository.AddAsync(user);

            _logger.LogInformation($"User {request.Username} registered successfully.");

            return user.Id;
        }
    }
}
