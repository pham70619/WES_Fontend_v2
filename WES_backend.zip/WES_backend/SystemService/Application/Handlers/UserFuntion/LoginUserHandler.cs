﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using SystemService.Application.Commands.User;
using SystemService.Domain.Interface;
using SystemService.Domain.Interface.User;
using SystemService.Domain.Interface.UserFuntion;

namespace SystemService.Application.Handlers.User
{
    public class LoginUserHandler : IRequestHandler<LoginUserCommand, string>
    {
        private readonly ISystemRepository _userRepository;
        private readonly IPasswordHasher _passwordHasher;
        private readonly IJwtTokenGenerator _tokenGenerator;
        private readonly ILogger<LoginUserHandler> _logger;

        public LoginUserHandler(ISystemRepository userRepository, IPasswordHasher passwordHasher, IJwtTokenGenerator tokenGenerator, ILogger<LoginUserHandler> logger)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
            _tokenGenerator = tokenGenerator;
            _logger = logger;
        }

        public async Task<string> Handle(LoginUserCommand request, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetByUsernameAsync(request.Username);
            if (user == null || !user.IsActive)
            {
                _logger.LogWarning("Login failed for user: {Username}. User not found or inactive.", request.Username);
                throw new UnauthorizedAccessException($"User {request.Username} not found or inactive.");
            }

            var isPasswordValid = _passwordHasher.VerifyPassword(request.Password, user.PasswordHash);
            if (!isPasswordValid)
            {
                _logger.LogWarning("Login failed for user: {Username}. Invalid password.", request.Username);
                throw new UnauthorizedAccessException("Invalid password.");
            }

            user.UpdateRefreshToken();

            await _userRepository.UpdateAsync(user);

            var token = _tokenGenerator.GenerateToken(user);

            _logger.LogInformation("User {Username} logged in successfully.", request.Username);

            return token;
        }
    }
}
