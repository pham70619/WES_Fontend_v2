﻿using MediatR;
using System.Security.Cryptography;
using SystemService.Application.Commands.UserFuntion;
using SystemService.Domain.Interface.UserFuntion;
using SystemService.Domain.Interface;

namespace SystemService.Application.Handlers.UserFuntion
{
    public class RefreshTokenHandler : IRequestHandler<RefreshTokenCommand, string>
    {
        private readonly ISystemRepository _userRepository;
        private readonly IJwtTokenGenerator _tokenGenerator;
        private readonly ILogger<RefreshTokenHandler> _logger;

        public RefreshTokenHandler(ISystemRepository userRepository, IJwtTokenGenerator tokenGenerator, ILogger<RefreshTokenHandler> logger)
        {
            _userRepository = userRepository;
            _tokenGenerator = tokenGenerator;
            _logger = logger;
        }

        public async Task<string> Handle(RefreshTokenCommand request, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetByRefreshTokenAsync(request.RefreshToken);
            if (user == null || user.RefreshTokenExpiryTime <= DateTime.UtcNow)
            {
                _logger.LogWarning("Invalid or expired refresh token.");
                throw new UnauthorizedAccessException("Invalid or expired refresh token.");
            }

            user.UpdateRefreshToken();

            await _userRepository.UpdateAsync(user);

            var newAccessToken = _tokenGenerator.GenerateToken(user);

            _logger.LogInformation("Refresh token for user {Username} refreshed successfully.", user.Username);

            return newAccessToken;
        }

        private string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
    }
}
