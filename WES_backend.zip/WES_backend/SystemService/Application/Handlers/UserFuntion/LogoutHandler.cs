﻿using MediatR;
using SystemService.Application.Commands.UserFuntion;
using SystemService.Domain.Interface;

namespace SystemService.Application.Handlers.UserFuntion
{
    public class LogoutHandler : IRequestHandler<LogoutCommand, Unit>
    {
        private readonly ISystemRepository _userRepository;
        private readonly ILogger<LogoutHandler> _logger;

        public LogoutHandler(ISystemRepository userRepository, ILogger<LogoutHandler> logger)
        {
            _userRepository = userRepository;
            _logger = logger;
        }

        public async Task<Unit> Handle(LogoutCommand request, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetByRefreshTokenAsync(request.RefreshToken);
            if (user == null)
            {
                _logger.LogWarning("Logout failed. Invalid refresh token.");
                throw new UnauthorizedAccessException("Invalid refresh token.");
            }

            user.ClearRefreshToken();

            await _userRepository.UpdateAsync(user);

            _logger.LogInformation("User {Username} logged out successfully.", user.Username);

            return Unit.Value;
        }
    }
}
