﻿namespace SystemService.Application.DTOs.Setting
{
    public record ParameterDto(
    string FuncGroup,
    string FuncKey,
    string FuncSort,
    string FuncType,
    string FuncValue,
    string? Descript = null
);

    public class CreateParameterDto
    {
        public required string FuncGroup { get; set; }
        public required string FuncKey { get; set; }
        public required string FuncSort { get; set; }
        public required string FuncType { get; set; }
        public required string FuncValue { get; set; }
        public string? Description { get; set; } = null;
        public string? CreateBy { get; set; }
    }


    public class UpdateParameterDto 
    {
        public required string FuncGroup { get; set; }
        public required string FuncKey { get; set; }
        public required string FuncSort { get; set; }
        public required string FuncType { get; set; }
        public required string FuncValue { get; set; }
        public string? Description { get; set; } = null;
        public string? UpdateBy { get; set; }
    }

    public class DeleteParameterDto
    {
        public required string FuncGroup { get; set; }
        public required string FuncKey { get; set; }
        public string? DeleteBy { get; set; }
    }

}
