﻿namespace SystemService.Application.DTOs.Setting
{
    public class CompanyDto
    {
        public int company_id { get; set; }
        public string company_name { get; set; }
        public string company_short_name { get; set; }
        public string? gui { get; set; }
        public string? address { get; set; }
        public int status { get; set; }
        public DateTime? created_at { get; set; }
        public string? created_by { get; set; }
        public DateTime? updated_at { get; set; }
        public string? updated_by { get; set; }
    }

    public class updateCompanyDto
    {
        public int? company_id { get; set; }
        public string company_name { get; set; }
        public string company_short_name { get; set; }
        public string gui { get; set; }
        public string? address { get; set; }
        public int? status { get; set; }
        public string? created_by { get; set; }
    }

    //basic data
    public class ComBasicDto
    {
        public int company_id { get; set; }
        public string company_name { get; set; }
    }
}
