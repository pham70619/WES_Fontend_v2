﻿namespace SystemService.Application.DTOs.Setting
{
    //public class EndpointDto
    //{
    //    public required string Url { get; set; }
    //    public required string CommType { get; set; }
    //    public required string AuthType { get; set; }
    //    public required string SerializationStrategy { get; set; }
    //    public required string RequestType { get; set; }
    //    public required string Branch { get; set; }
    //    public required string CustomerID { get; set; }
    //    public required string WarehouseID { get; set; }
    //    public required string ZoneID { get; set; }
    //}

    public record EndpointDto
    (
        string Url,
        string CommType,
        string AuthType,
        string SerializationStrategy,
        string RequestType,
        string Branch,
        string CustomerID,
        string WarehouseID,
        string ZoneID
    );

    public class CreateEndpointDto
    {
        public required string Url { get; set; }
        public required string CommType { get; set; }
        public required string AuthType { get; set; }
        public required string SerializationStrategy { get; set; }
        public required string RequestType { get; set; }
        public required string Branch { get; set; }
        public required string CustomerID { get; set; }
        public required string WarehouseID { get; set; }
        public required string ZoneID { get; set; }
    }


    public class UpdateEndpointDto
    {
        public required string Url { get; set; }
        public required string CommType { get; set; }
        public required string AuthType { get; set; }
        public required string SerializationStrategy { get; set; }
        public required string RequestType { get; set; }
        public required string Branch { get; set; }
        public required string CustomerID { get; set; }
        public required string WarehouseID { get; set; }
        public required string ZoneID { get; set; }
    }

    public class DeleteEndpointDto
    {
        public required string RequestType { get; set; }
        public required string Branch { get; set; }
        public required string CustomerID { get; set; }
        public required string WarehouseID { get; set; }
        public required string ZoneID { get; set; }
    }
}
