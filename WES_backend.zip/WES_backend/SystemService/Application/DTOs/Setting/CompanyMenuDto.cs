﻿namespace SystemService.Application.DTOs.Setting
{
    public class CompanyMenuDto
    {
        public int? company_id { get; set; }
        public string company_name { get; set; }
        public int? menu_id { get; set; }
        public string i18n_key {get; set;}
        public DateTime created_at { get; set; }
        public string created_by { get; set; }
    }

    public class updateCompanyMenuDto
    {
        public int company_id { get; set; }
        public string company_name { get; set; }
        public int menu_id { get; set; }
        public string i18n_key { get; set; }
    }

    public class deleteCompanyMenuDto
    {
        public int company_id { get; set; }
        public int menu_id { get; set; }
    }
}
