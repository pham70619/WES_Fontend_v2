﻿namespace SystemService.Application.DTOs.Setting
{
    //public class ZoneDto
    //{
    //    public required string WarehouseID { get; set; }
    //    public required string WarehouseName { get; set; }
    //    public required string ZoneID { get; set; }
    //    public required string CreateBy { get; set; }
    //    public DateTime? CreateAt { get; set; }
    //    public required string UpdateBy { get; set; }
    //    public DateTime? UpdateAt { get; set; }
    //    public string? Description { get; set; }
    //}

    public record ZoneDto(string warehouseID, string zoneID, string? description = null);


    public class CreateZoneDto
    {
        public required string WarehouseID { get; set; }
        public required string ZoneID { get; set; }
        public string? Description { get; set; } = null;
        public string? CreateBy { get; set; }
        // 可根據需求加入其他屬性
    }

    public class UpdateZoneDto
    {
        public required string WarehouseID { get; set; }
        public required string ZoneID { get; set; }
        public string? Description { get; set; } = null;
        public string? UpdateBy { get; set; }
        // 可根據需求加入其他屬性
    }

    public class DeleteZoneDto
    {
        public required string WarehouseID { get; set; }
        public required string ZoneID { get; set; }
        public string? DeleteBy { get; set; }
        // 可根據需求加入其他屬性
    }
}
