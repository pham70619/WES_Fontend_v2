﻿namespace SystemService.Application.DTOs.Setting
{
    //public class WarehouseDto
    //{
    //    public required string CustomerID { get; set; }
    //    public required string WarehouseID { get; set; }
    //    public required string WarehouseName { get; set; }
    //    public required string Address { get; set; }
    //    public required string CreateBy { get; set; }
    //    public DateTime? CreateAt { get; set; }
    //    public required string UpdateBy { get; set; }
    //    public DateTime? UpdateAt { get; set; }
    //    public string? Description { get; set; }
    //}

    public record WarehouseDto(string warehouseID, string warehouseName, string? description = null, string? address = null);

    public class CreateWarehouseDto
    {
        public required string CustomerID { get; set; }
        public required string WarehouseID { get; set; }
        public required string WarehouseName { get; set; }
        public string? Address { get; set; } = null;
        public string? Description { get; set; } = null;
        public string? CreateBy { get; set; }
        // 可根據需求加入其他屬性
    }

    public class UpdateWarehouseDto
    {
        public required string CustomerID { get; set; }
        public required string WarehouseID { get; set; }
        public required string WarehouseName { get; set; }
        public string? Address { get; set; } = null;
        public string? Description { get; set; } = null;
        public string? UpdateBy { get; set; }
        // 可根據需求加入其他屬性
    }

    public class DeleteWarehouseDto
    {
        public required string CustomerID { get; set; }
        public required string WarehouseID { get; set; }
        public string? DeleteBy { get; set; }
        // 可根據需求加入其他屬性
    }
}
