﻿namespace SystemService.Application.DTOs.Setting
{
    public class RoleDto
    {
        public int role_id { get; set; }
        public int company_id { get; set; }
        public string role_name { get; set; }
        public DateTime created_at { get; set; }
        public string created_by { get; set; }
        public DateTime? updated_at { get; set; }
        public string? updated_by { get; set; }
    }

    public class AddorUpdateDto
    {
        public int? role_id { get; set; }
        public int company_id { get; set; }
        public string role_name { get; set; }
    }

    public class roleDataResponseDto
    {
        public int role_id { get; set; }
        public int company_id { get; set; }
        public string company_name { get; set; }
        public string role_name { get; set; }
        public DateTime created_at { get; set; }
        public string created_by { get; set; }
        public DateTime? updated_at { get; set; }
        public string? updated_by { get; set; }
    }
}
