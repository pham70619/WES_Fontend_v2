﻿namespace SystemService.Application.DTOs.Setting
{
    public class MenuDto
    {
        public int? menu_id { get; set; }
        public int? parent_id { get; set; }
        public string? path { get; set; }
        public string? icon { get; set; }
        public int sort_order { get; set; }
        public int enabled { get; set; }
        public string? menu_type { get; set; }
        public int is_expandable { get; set; }
        public string i18n_key { get; set; }
        public List<MenuDto> children { get; set; } = new();
    }
}
