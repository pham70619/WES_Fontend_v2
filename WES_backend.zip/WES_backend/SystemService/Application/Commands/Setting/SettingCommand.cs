﻿using MediatR;
using SystemService.Application.DTOs.Setting;

namespace SystemService.Application.Commands.Setting
{
    public class SettingCommand
    {
        #region MediatR Command & Query Definitions

        // 客戶相關
        public record CreateCustomerCommand(CreateCustomerDto Dto) : IRequest<CustomerDto>;
        public record UpdateCustomerCommand(UpdateCustomerDto Dto) : IRequest<Unit>;
        public record DeleteCustomerCommand(DeleteCustomerDto Dto) : IRequest<Unit>;
        public record SearchCustomerQuery : IRequest<List<CustomerDto>>
        {
            public required string CustomerID { get; init; }
            public required string CustomerName { get; init; }
        }
        public record GetCustomerByIDQuery(string CustomerID) : IRequest<CustomerDto>;

        // 倉庫相關
        public record CreateWarehouseCommand(CreateWarehouseDto Dto) : IRequest<WarehouseDto>;
        public record UpdateWarehouseCommand(UpdateWarehouseDto Dto) : IRequest<Unit>;
        public record DeleteWarehouseCommand(DeleteWarehouseDto Dto) : IRequest<Unit>;
        public record SearchWarehouseQuery : IRequest<List<WarehouseDto>>
        {
            public required string WarehouseID { get; init; }
            public required string WarehouseName { get; init; }
        }
        public record GetWarehouseByIDQuery(string WarehouseID) : IRequest<WarehouseDto>;

        // 區域相關
        public record CreateZoneCommand(CreateZoneDto Dto) : IRequest<ZoneDto>;
        public record UpdateZoneCommand(UpdateZoneDto Dto) : IRequest<Unit>;
        public record DeleteZoneCommand(DeleteZoneDto Dto) : IRequest<Unit>;
        public record SearchZoneQuery : IRequest<List<ZoneDto>>
        {
            public required string WarehouseID { get; init; }
            public required string WarehouseName { get; init; }
            public required string ZoneID { get; init; }
        }
        public record GetZoneByIDQuery(string WarehouseID, string ZoneID) : IRequest<ZoneDto>;

        // 參數相關
        public record CreateParameterCommand(CreateParameterDto Dto) : IRequest<ParameterDto>;
        public record UpdateParameterCommand(UpdateParameterDto Dto) : IRequest<Unit>;
        public record DeleteParameterCommand(DeleteParameterDto Dto) : IRequest<Unit>;

        // 取得全部參數 Query
        public record GetAllParametersQuery() : IRequest<List<ParameterDto>>;
        public record GetParameterByIDQuery(string FuncGroup, string FuncKey) : IRequest<ParameterDto>;

        // Endpoint相關
        public record CreateEndpointCommand(CreateEndpointDto Dto) : IRequest<EndpointDto>;
        public record UpdateEndpointCommand(UpdateEndpointDto Dto) : IRequest<Unit>;
        public record DeleteEndpointCommand(DeleteEndpointDto Dto) : IRequest<Unit>;

        // 取得全部Endpoint Query
        public record GetAllEndpointsQuery() : IRequest<List<EndpointDto>>;
        public record GetEndpointByIDQuery(string CustomerID, string WarehouseID, string ZoneID, string RequestType, string Branch) : IRequest<EndpointDto>;


        #endregion
    }
}
