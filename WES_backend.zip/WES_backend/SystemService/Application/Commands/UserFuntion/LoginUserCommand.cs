﻿using MediatR;
using SharedKernel.Models;

namespace SystemService.Application.Commands.User
{
    public class LoginUserCommand : BaseCommand, IRequest<string>
    {
        public string Username { get; }
        public string Password { get; }

        public LoginUserCommand(string username, string password, string correlationId)
        : base(correlationId)
        {
            Username = username;
            Password = password;
        }
    }
}
