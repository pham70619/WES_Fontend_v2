﻿using MediatR;

namespace SystemService.Application.Commands.UserFuntion
{
    public class RefreshTokenCommand : IRequest<string>
    {
        public string RefreshToken { get; }

        public RefreshTokenCommand(string refreshToken)
        {
            RefreshToken = refreshToken;
        }
    }
}
