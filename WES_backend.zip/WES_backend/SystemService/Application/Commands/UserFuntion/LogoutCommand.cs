﻿using MediatR;

namespace SystemService.Application.Commands.UserFuntion
{
    public class LogoutCommand : IRequest<Unit>
    {
        public string RefreshToken { get; }

        public LogoutCommand(string refreshToken)
        {
            RefreshToken = refreshToken;
        }
    }
}
