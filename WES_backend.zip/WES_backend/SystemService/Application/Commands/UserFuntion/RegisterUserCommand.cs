﻿using MediatR;

namespace SystemService.Application.Commands.User
{
    public class RegisterUserCommand : IRequest<Guid>
    {
        public string Username { get; }
        public string Password { get; }
        public string Email { get; }
        public int Level { get; }

        public RegisterUserCommand(string username, string password, string email, int level)
        {
            Username = username;
            Password = password;
            Email = email;
            Level = level;
        }
    }
}
