﻿using AutoMapper;
using SharedKernel.Configurations;
using SharedKernel.Interface;
using SystemService.Domain.Interface.Health;
using SystemService.Domain.Interface;
using SharedKernel.Enum;
using SystemService.Domain.Interface.Messaging;
using Nest;
using SystemService.Domain.Event;
using SystemService.Infrastructure.Persistence.Model;
using SystemService.Domain.Interface.EventDespath;
using SharedKernel.Event;

namespace SystemService.Application.Services.EventDespath
{
    public class EventDespatchAppService : IEventDespatchAppService
    {
        private readonly IMapper _mapper;
        private readonly ISharedLogger<EventDespatchAppService> _logger;
        private readonly RabbitMQSettings _config;
        private readonly IEventRepository _eventRepository;
        private readonly IConfiguration _configuration;
        private readonly IEventPublisher _eventPublisher;


        public EventDespatchAppService
        (
            IMapper mapper,
            ISharedLogger<EventDespatchAppService> logger,
            RabbitMQSettings config,
            IEventRepository eventRepository,
            IConfiguration configuration,
            IEventPublisher eventPublisher
        )
        {
            _mapper = mapper;
            _logger = logger;
            _config = config;
            _eventRepository = eventRepository;
            _configuration = configuration;
            _eventPublisher = eventPublisher;
        }

        public async Task EventDespatchAsync()
        {
            _logger.LogDebug("EventDespatchAsync is starting at {DateTime.Now}...");

            try
            {
                // Retrieve URLs from WES_HEALTH table
                var tranEvents = await _eventRepository.GetUnprocessedEventAsync();

                if (tranEvents == null || tranEvents.Count() == 0)
                {
                    _logger.LogDebug("未偵測到任何事件");
                    return;
                }

                foreach (var tranEvent in tranEvents)
                {
                    tranEvent.STATUS = StatusEnum.Despatching.ToString();
                    tranEvent.UPDATE_AT = DateTime.Now;
                    tranEvent.START_AT = DateTime.Now;
                    tranEvent.UPDATE_BY = _configuration["Appsettings:ServiceName"];
                }

                await _eventRepository.UpdateListAsync(tranEvents);

                await _eventRepository.SaveChangesAsync();

                foreach (var tranEvent in tranEvents)
                {
                    var message = new EventMessageData { };

                    //SKU / INBOUND /  OUTBOUND/  ORDER
                    try
                    {
                        message = GetExchangeAndRoutekey(tranEvent.TARGET_NAME);
                    }
                    catch (Exception ex) 
                    {
                        _logger.LogError(ex,ex.Message,tranEvent.SESSION_ID.ToString());

                        tranEvent.STATUS = StatusEnum.SyncDead.ToString();
                        tranEvent.ERROR_MESSAGE = ex.Message;
                        tranEvent.UPDATE_AT = DateTime.Now;
                        tranEvent.UPDATE_BY = "PIC.SystemService";

                        continue;
                    }

                    if (message.Exchange == null || message.Routekey == null)
                    {
                        throw new Exception("未取得路徑資訊");
                    }

                    var presidentEventDetail = _mapper.Map<PresidentEventDetailDto>(tranEvent);
                    var presidentEventDetails = new List<PresidentEventDetailDto> { presidentEventDetail };
                    var presidentEvent = new PresidentEventDto(presidentEventDetails, presidentEventDetail.CorrelationId, message.EventType ?? EventEnum.None, _configuration["Appsettings:ServiceName"] ?? "SystemService", DateTime.Now);
                    var requestIDs = new List<string?> { tranEvent.SESSION_ID.ToString() ?? Guid.Empty.ToString() };

                    try
                    {
                        _eventPublisher.Publish
                        (
                            presidentEvent,
                            tranEvent.SESSION_ID.ToString(),
                            tranEvent.TARGET_NAME,
                            message.Exchange,
                            message.Routekey,
                            tranEvent.TARGET_NAME,
                            string.Empty,
                            _configuration["Appsettings:Customer"] ?? "NoData",
                            _configuration["Appsettings:Warehouse"] ?? "NoData",
                            _configuration["Appsettings:Zone"] ?? "NoData",
                            requestIDs
                        );
                    }
                    catch (TimeoutException ex)
                    {
                        // 處理等待確認超時的情況
                        _logger.LogError(ex, "Error publishing EventDespatchAsync event to RabbitMQ." + ex.Message);
                        _logger.LogEvent("EventDespatchAsync", false, null, _configuration["Appsettings:ServiceName"], tranEvent.SESSION_ID.ToString());
                        tranEvent.STATUS = StatusEnum.SyncFailed.ToString();
                        tranEvent.UPDATE_AT = DateTime.Now;
                        tranEvent.ERROR_MESSAGE = ex.Message;
                        //await _eventRepository.UpdateAsync(tranEvent);
                        await _eventRepository.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error processing in EventDespatchAsync when eventPublisher.Because:" + ex.Message);
                        _logger.LogEvent("EventDespatchAsync", false, null, _configuration["Appsettings:ServiceName"], tranEvent.SESSION_ID.ToString());
                        tranEvent.STATUS = StatusEnum.SyncFailed.ToString();
                        tranEvent.UPDATE_AT = DateTime.Now;
                        tranEvent.ERROR_MESSAGE = ex.Message;
                        //await _eventRepository.UpdateAsync(tranEvent);
                        await _eventRepository.SaveChangesAsync();
                    }

                    _logger.LogEvent("EventDespatchAsync", true, null, _configuration["Appsettings:ServiceName"], tranEvent.SESSION_ID.ToString());
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during EventDespatchAsync.Because: " + ex.Message);
                throw;
            }
        }

        private EventMessageData GetExchangeAndRoutekey(string requestType)
        {
            try
            {
                if (string.IsNullOrEmpty(requestType))
                    throw new ArgumentNullException(nameof(requestType));

                var message = new EventMessageData();

                if (requestType == "SKU" || requestType == EventEnum.SKUMaster.ToString())
                {
                    message.Exchange = _config.MainfileExchange;
                    message.Routekey = _config.SKUMasterRoutingKey;
                    message.EventType = EventEnum.SKUMaster_Despatch;
                }
                else if (requestType == "INBOUND" || requestType == EventEnum.InboundPalletInfo.ToString())
                {
                    message.Exchange = _config.InboundExchange;
                    message.Routekey = _config.InboundPalletInfoRoutingKey;
                    message.EventType = EventEnum.SKUMaster_Despatch;

                }
                else if (requestType == "OUTBOUND" || requestType == EventEnum.RetrieveLoad.ToString())
                {
                    message.Exchange = _config.OutboundExchange;
                    message.Routekey = _config.RetrieveLoadRoutingKey;
                    message.EventType = EventEnum.SKUMaster_Despatch;

                }
                else if (requestType == "ORDER" || requestType == EventEnum.OrderInfo.ToString())
                {
                    message.Exchange = _config.OutboundExchange;
                    message.Routekey = _config.OrderInfoRoutingKey;
                    message.EventType = EventEnum.SKUMaster_Despatch;

                }
                else
                {
                    throw new InvalidOperationException("無法辨認的請求種類:" + requestType);
                }

                return message;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "辨認種類異常.");
                throw new Exception(ex.Message);
            }
        }

        private class EventMessageData
        {
            public string? Exchange { get; set; }
            public string? Routekey { get; set; }
            public EventEnum? EventType { get; set; }
        }
    }
}
