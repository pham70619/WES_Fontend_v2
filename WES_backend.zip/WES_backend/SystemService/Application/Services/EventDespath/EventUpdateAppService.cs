﻿using AutoMapper;
using SharedKernel.Configurations;
using SharedKernel.Enum;
using SharedKernel.Event;
using SharedKernel.Interface;
using SystemService.Domain.Event;
using SystemService.Domain.Interface;
using SystemService.Domain.Interface.EventDespath;
using SystemService.Domain.Interface.Messaging;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Application.Services.EventDespath
{
    public class EventUpdateAppService : IEventUpdateAppService
    {
        private readonly IMapper _mapper;
        private readonly ISharedLogger<EventUpdateAppService> _logger;
        private readonly RabbitMQSettings _config;
        private readonly IEventRepository _eventRepository;
        private readonly IConfiguration _configuration;
        private readonly IEventPublisher _eventPublisher;


        public EventUpdateAppService
        (
            IMapper mapper,
            ISharedLogger<EventUpdateAppService> logger,
            RabbitMQSettings config,
            IEventRepository eventRepository,
            IConfiguration configuration,
            IEventPublisher eventPublisher
        )
        {
            _mapper = mapper;
            _logger = logger;
            _config = config;
            _eventRepository = eventRepository;
            _configuration = configuration;
            _eventPublisher = eventPublisher;
        }

        public async Task EventUpdateAsync(PresidentEventDto updateEvent)
        {
            _logger.LogDebug("EventUpdateAsync is starting at {DateTime.Now}...");
            bool isSucessed = false;
            Guid guid = Guid.Empty;

            try
            {
                foreach (var presidentEventDetail in updateEvent.PresidentEventDetails)
                {
                    if (!Guid.TryParse(presidentEventDetail.CorrelationId, out Guid correlationId))
                    {
                        throw new ArgumentException("CorrelationId轉換失敗，無法查找事件");
                    }
                    if (!Guid.TryParse(presidentEventDetail.ORG_CorrelationId, out Guid org_correlationId))
                    {
                        throw new ArgumentException("CorrelationId轉換失敗，無法查找事件");
                    }
                    guid = correlationId;

                    var Event = await _eventRepository.GetEventByIdAsync(correlationId);

                    if (Event == null)
                    {
                        _logger.LogInformation("未查到相關事件，辨認為新事件", correlationId.ToString());
                        Event = new TransEventEntity
                        {
                            SESSION_ID = correlationId,
                            ORG_SESSION_ID = org_correlationId,
                            TARGET_NAME = updateEvent.EventType.ToString(),
                            STATUS = presidentEventDetail.Status.ToString(),
                            CREATE_AT = DateTime.Now,
                            UPDATE_AT = DateTime.Now,
                            UPDATE_BY = updateEvent.Updateby.ToString(),
                            ERROR_MESSAGE = string.Empty,
                            REMARK1 = "系統新增事件"
                        };

                        await _eventRepository.AddAsync(Event);
                    }
                    else
                    {
                        if (Event.STATUS != StatusEnum.SyncSuccessed.ToString() || Event.STATUS != StatusEnum.SyncFailed.ToString() || Event.STATUS != StatusEnum.SyncDead.ToString())
                        {
                            _logger.LogWarning("事件狀態未完成，不接受變更", correlationId.ToString());
                            Event.ERROR_MESSAGE = "事件狀態未完成，不接受變更";
                            continue;
                        }

                        Event.STATUS = presidentEventDetail.Status.ToString();
                        Event.ERROR_MESSAGE = presidentEventDetail.ErrorMessage;
                        Event.UPDATE_BY = updateEvent.Updateby;
                        Event.UPDATE_AT = updateEvent.UpdateAt;
                        if (presidentEventDetail.Status == StatusEnum.SyncFailed || presidentEventDetail.Status == StatusEnum.SyncSuccessed)
                        {
                            Event.END_AT = DateTime.Now;
                        }

                        if (presidentEventDetail.Status == StatusEnum.SyncSuccessed || Event.STATUS != StatusEnum.SyncFailed.ToString() || Event.STATUS != StatusEnum.SyncDead.ToString())
                        {
                            // 將事件儲存後移到LOG TABLE
                            await _eventRepository.SaveChangesAsync();
                            await _eventRepository.MoveToLogTableAsync(Event);
                        }
                    }

                    await _eventRepository.SaveChangesAsync();
                }

                isSucessed = true;
            }
            catch (Exception ex)
            {
                isSucessed = false;
                _logger.LogError(ex, "Error during EventDespatchAsync.Because: " + ex.Message);
                throw;
            }
            finally
            {
                _logger.LogEvent("EventDespatchAsync", isSucessed, null, _configuration["Appsettings:ServiceName"], guid.ToString());
            }
        }
    }
}
