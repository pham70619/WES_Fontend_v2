﻿using AutoMapper;
using SharedKernel.Configurations;
using SharedKernel.Interface;
using SystemService.Domain.Interface;
using SystemService.Domain.Interface.Health;

namespace SystemService.Application.Services.Order
{
    public class HealthCheckAppService : IHealthCheckAppService
    {
        private readonly IMapper _mapper;
        private readonly ISharedLogger<HealthCheckAppService> _logger;
        private readonly RabbitMQSettings _config;
        private readonly ISystemRepository _systemRepository;

        public HealthCheckAppService
        (
            IMapper mapper,
            ISharedLogger<HealthCheckAppService> logger,
            RabbitMQSettings config,
            ISystemRepository systemRepository
        )
        {
            _mapper = mapper;
            _logger = logger;
            _config = config;
            _systemRepository = systemRepository;
        }

        public async Task HealthCheckAsync()
        {
            _logger.LogDebug("HealthCheckAsync is starting at {DateTime.Now}...");

            try
            {
                // Retrieve URLs from WES_HEALTH table
                var services = await _systemRepository.GetAllHealthAsync("RSI_SINSHIH_1", "23529784", "P1-RS1");

                if (services == null) 
                {
                    ArgumentException ex = new ArgumentException("Error to get HealthCheckData.");
                    _logger.LogError(ex, "Error to get HealthCheckData.");
                    throw ex;
                }

                foreach (var service in services)
                {
                    bool alive = false;
                    alive = await CheckServiceHealthAsync(service.Url);
                    service.Alive = alive;
                    service.LastUpdated = DateTime.Now;
                }

                await _systemRepository.AddAndUpdateAsync(services);

                await _systemRepository.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during HealthCheckAsync.");
                throw;
            }
        }

        private async Task<bool> CheckServiceHealthAsync(string url)
        {
            try
            {
                using var httpClient = new HttpClient();
                var response = await httpClient.GetAsync(url);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking health for URL {url}.");
                return false;
            }
        }
    }

}
