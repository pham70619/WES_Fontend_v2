﻿using System.Linq;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Application.Services
{
    public class RoleService : IRoleService
    {
        private readonly IRoleRepository _roleRepo;
        private readonly ICompanyRepository _comRepo;

        public RoleService(IRoleRepository roleRepo, ICompanyRepository comRepo)
        {
            _roleRepo = roleRepo;
            _comRepo = comRepo;
        }

        // get data
        public async Task<List<roleDataResponseDto>> GetRoleDataAsync()
        {
            var roles = await _roleRepo.GetRolesAsync();
            var companyIds = roles.Select(r => r.company_id).Distinct().ToList();

            var companyBasic = await _comRepo.GetComBasicAsync(companyIds);
            var companyDict = companyBasic.ToDictionary(c => c.company_id, c => c.company_name);
            var result = roles.Select(role =>new roleDataResponseDto
            {
                role_id = role.role_id,
                company_id = role.company_id,
                company_name = companyDict.TryGetValue(role.company_id, out var name) ? name : "Unknown",
                role_name = role.role_name,
                created_at = role.created_at,
                created_by = role.created_by,
                updated_at = role.updated_at,
                updated_by = role.updated_by
            }).ToList();

            return result;
        }

        // add or update
        public async Task AddorUpdateAsync(List<AddorUpdateDto> dtoList)
        {
            foreach (var item in dtoList)
            {
                //if (!item.role_id.HasValue || item.role_id == 0)
                //{
                    //var newEntity = new RoleEntity
                    //{
                    //    COMPANY_ID = item.company_id,
                    //    ROLE_NAME = item.role_name,
                    //    CREATED_AT = DateTime.Now,
                    //    CREATED_BY = "admin",
                    //};

                    await _roleRepo.AddAsync(item);
                //}
                //else
                //{
                //    var existing = await _roleRepo.GetByIdAsync(item.role_id.Value);
                //    if (existing != null) {
                //        var updateEntity = new RoleEntity
                //        {
                //            ROLE_ID = item.role_id.Value,
                //            COMPANY_ID = item.company_id,
                //            ROLE_NAME = item.role_name,
                //            UPDATED_BY = "admin",
                //        };

                //        Console.WriteLine($"~~~~~ update entity: {updateEntity}");
                //        await _roleRepo.UpdateAsync(updateEntity);
                //    }
                //    else
                //    {
                //        Console.WriteLine($"Role ID {item.role_id} not found. Skipping update.");
                //    }
                //}
                
            }
        }

        // delete data
        public async Task DeleteAsync(List<int> ids)
        {
            await _roleRepo.DeleteAsync(ids);
        }
    }
}
