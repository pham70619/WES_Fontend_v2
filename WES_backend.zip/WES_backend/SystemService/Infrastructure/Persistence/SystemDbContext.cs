﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System.Data.Common;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence
{
    public class SystemDbContext : DbContext
    {
        private readonly string _databaseType;
        public static readonly ILoggerFactory MyLoggerFactory
        = LoggerFactory.Create(builder =>
        {
            builder
                .AddFilter((category, level) =>
                    category == DbLoggerCategory.Database.Command.Name
                    && level == LogLevel.Information)
                .AddConsole();
        });

        public SystemDbContext(DbContextOptions<SystemDbContext> options, IConfiguration configuration)
            : base(options)
        {
            _databaseType = configuration.GetValue<string>("DatabaseType") ?? "PostgreSQL"; // 默認為 PostgreSQL
        }

        // 持久化模型 (替換原有的 Domain 模型)
        public DbSet<UserEntity> Users { get; set; }
        public DbSet<HealthEntity> Healths { get; set; }
        public DbSet<CustomerEntity> Customers { get; set; }
        public DbSet<WarehouseEntity> Warehouses { get; set; }
        public DbSet<ZoneEntity> Zones { get; set; }
        public DbSet<ParameterEntity> Parameters { get; set; }
        public DbSet<EndpointEntity> Endpoints { get; set; }
        public DbSet<TransEventEntity> TransEvents { get; set; }
        public DbSet<TransEventEntityLog> TransEventsLog { get; set; }
        public DbSet<MenuEntity> Wes_Menu { get; set; }
        public DbSet<CompanyEntity> Companies { get; set; }
        public DbSet<CompanyMenuEntity> CompanyMenus { get; set; }
        public DbSet<RoleEntity> Roles { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (_databaseType == "Oracle")
            {
                optionsBuilder.UseOracle("User Id=SMARTAPI;Password=smartapi;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.35.9.36)(PORT=1521)))(CONNECT_DATA=(SERVER=dedicated)(SID=GM2G)))");
            }
            else if (_databaseType == "PostgreSQL")
            {
                optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=WES_Database;Username=postgres;Password=Tuanhung380$$");
            }

            optionsBuilder
                .UseLoggerFactory(MyLoggerFactory)
                .EnableSensitiveDataLogging();

            //optionsBuilder
            //    .UseOracle("User Id=SMARTAPI;Password=smartapi;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.35.9.36)(PORT=1521)))(CONNECT_DATA=(SERVER=dedicated)(SID=GM2G)))")
            //    .UseLoggerFactory(MyLoggerFactory)  // 使用自訂的 LoggerFactory
            //    .EnableSensitiveDataLogging();       // 啟用敏感資料記錄（僅在開發環境使用）
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            try
            {
                base.OnModelCreating(modelBuilder);

                ConfigureTableAndColumnNames(modelBuilder);

                // 配置表和主鍵
                ConfigureEntities(modelBuilder);

                ConfigureDatabaseSpecificProperties(modelBuilder);

            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred in OnModelCreating method", ex);
            }

        }

        private void ConfigureEntities(ModelBuilder modelBuilder)
        {
            // 設置 UserEntity 的表
            modelBuilder.Entity<UserEntity>()
                .ToTable("WES_USER")
                .HasKey(s => s.Id); // 設置主鍵

            // 設置 HealthEntity 的表
            modelBuilder.Entity<HealthEntity>()
                .ToTable("WES_HEALTH")
                .HasKey(o => new { o.ServiceName, o.CustomerID, o.WarehouseID, o.ZoneID });

            // 設置 CustomerEntity 的表
            modelBuilder.Entity<CustomerEntity>()
                .ToTable("WES_CUSTOMER")
                .HasKey(o => new { o.CustomerID});

            // 設置 WarehouseEntity 的表
            modelBuilder.Entity<WarehouseEntity>()
                .ToTable("WES_WAREHOUSE")
                .HasKey(o => new { o.WarehouseID });

            // 建立 Warehouse 與 Customer 的關聯 (多對一)
            modelBuilder.Entity<WarehouseEntity>()
                .HasOne(w => w.Customer)
                .WithMany(c => c.Warehouses)
                .HasForeignKey(w => w.CustomerID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ZoneEntity>()
                .ToTable("WES_ZONE")
                .HasKey(o => new { o.WarehouseID, o.ZoneID });

            // 建立 Zone 與 Warehouse 的關聯 (多對一)
            modelBuilder.Entity<ZoneEntity>()
                .HasOne(z => z.Warehouse)
                .WithMany(w => w.Zones)
                .HasForeignKey(z => z.WarehouseID)
                .OnDelete(DeleteBehavior.Cascade);

            // 設置 CustomerEntity 的表
            modelBuilder.Entity<ParameterEntity>()
                .ToTable("WES_PARAMETER")
                .HasKey(o => new { o.FuncGroup, o.FuncKey });

            // 設置 CustomerEntity 的表
            modelBuilder.Entity<EndpointEntity>()
                .ToTable("WES_WCSENDPOINTS")
                .HasKey(o => new { o.RequestType, o.Branch, o.CustomerID, o.WarehouseID, o.ZoneID });

            // 設置 TransEventEntity 的表
            modelBuilder.Entity<TransEventEntity>()
                .ToTable("WMS_WES_TRANSEVENT")
                .HasKey(o => new { o.TRANS_NUM });

            // 設置 TransEventEntity_LOG 的表
            modelBuilder.Entity<TransEventEntityLog>()
                .ToTable("WMS_WES_TRANSEVENT_LOG")
                .HasNoKey();

            // 設置 wes_menu  的表
            modelBuilder.Entity<MenuEntity>()
                .ToTable("WES_MENU")
                .HasKey(o => new {o.MENU_ID });

            // 設置 wes_company  的表
            modelBuilder.Entity<CompanyEntity>()
                .ToTable("WES_COMPANY")
                .HasKey(o => new { o.COMPANY_ID });

            // 設置 wes_company_menu 的表
            modelBuilder.Entity<CompanyMenuEntity>()
                .ToTable("WES_COMPANY_MENU")
                .HasKey(e => new { e.COMPANY_ID, e.MENU_ID });

            // 設置 wes_role 的表
            modelBuilder.Entity<RoleEntity>()
                .ToTable("WES_ROLES")
                .HasKey(r => new { r.ROLE_ID });
        }

        private string GetTableName(string tableName)
        {
            return _databaseType == "PostgreSQL" ? tableName.ToLower() : tableName;
        }

        private void ConfigureTableAndColumnNames(ModelBuilder modelBuilder)
        {
            foreach (var entity in modelBuilder.Model.GetEntityTypes())
            {
                if (_databaseType == "Oracle")
                {
                    entity.SetTableName(entity.GetTableName().ToUpper());
                }
                else if (_databaseType == "PostgreSQL")
                {
                    entity.SetTableName(entity.GetTableName().ToLower());
                }

                foreach (var property in entity.GetProperties())
                {
                    if (_databaseType == "Oracle")
                    {
                        property.SetColumnName(property.GetColumnName(StoreObjectIdentifier.Table(entity.GetTableName(), null)).ToUpper());
                    }
                    else if (_databaseType == "PostgreSQL")
                    {
                        property.SetColumnName(property.GetColumnName(StoreObjectIdentifier.Table(entity.GetTableName(), null)).ToLower());
                    }
                }

                foreach (var key in entity.GetKeys())
                {
                    if (_databaseType == "Oracle")
                        key.SetName(key.GetName().ToUpper());
                    else if (_databaseType == "PostgreSQL")
                        key.SetName(key.GetName().ToLower());
                }

                foreach (var index in entity.GetIndexes())
                {
                    if (_databaseType == "Oracle")
                        index.SetDatabaseName(index.GetDatabaseName().ToUpper());
                    else if (_databaseType == "PostgreSQL")
                        index.SetDatabaseName(index.GetDatabaseName().ToLower());
                }

                foreach (var fk in entity.GetForeignKeys())
                {
                    if (_databaseType == "Oracle")
                        fk.SetConstraintName(fk.GetConstraintName().ToUpper());
                    else if (_databaseType == "PostgreSQL")
                        fk.SetConstraintName(fk.GetConstraintName().ToLower());
                }
            }
        }

        private void ConfigureDatabaseSpecificProperties(ModelBuilder modelBuilder)
        {
            foreach (var entity in modelBuilder.Model.GetEntityTypes())
            {
                foreach (var property in entity.GetProperties())
                {
                    // Guid轉換36碼VARCHAR
                    if (property.ClrType == typeof(Guid))
                    {
                        if (_databaseType == "Oracle")
                        {
                            // Oracle沒有GUID
                            property.SetColumnType("VARCHAR2(36)");
                            property.SetValueConverter(new ValueConverter<Guid, string>(
                                v => v.ToString(),
                                v => Guid.Parse(v)));
                        }
                        else if (_databaseType == "PostgreSQL")
                        {
                            // PostgreSQL UUID
                            property.SetColumnType("uuid");
                        }
                    }

                    // Guid?轉換36碼VARCHAR
                    if (property.ClrType == typeof(Guid?))
                    {
                        if (_databaseType == "Oracle")
                        {
                            property.SetColumnType("VARCHAR2(36)");
                            property.SetValueConverter(new ValueConverter<Guid?, string?>(
                                v => v.HasValue ? v.Value.ToString() : null,
                                v => string.IsNullOrEmpty(v) ? (Guid?)null : Guid.Parse(v)));
                        }
                        else if (_databaseType == "PostgreSQL")
                        {
                            property.SetColumnType("uuid");
                            // PostgreSQL本身支持UUID
                        }
                    }



                    // DateTime轉換
                    if (property.ClrType == typeof(DateTime))
                    {
                        if (_databaseType == "PostgreSQL")
                        {
                            property.SetColumnType("timestamp without time zone");
                            property.SetValueConverter(new ValueConverter<DateTime, DateTime>(
                                v => DateTime.SpecifyKind(v, DateTimeKind.Local),
                                v => DateTime.SpecifyKind(v, DateTimeKind.Local)));
                        }
                        else if (_databaseType == "Oracle")
                        {
                            property.SetColumnType("DATE");
                            property.SetValueConverter(new ValueConverter<DateTime, DateTime>(
                                v => DateTime.SpecifyKind(v, DateTimeKind.Local),
                                v => DateTime.SpecifyKind(v, DateTimeKind.Local)));
                        }
                    }

                    // DateTime轉換
                    if (property.ClrType == typeof(DateTime?))
                    {
                        if (_databaseType == "PostgreSQL")
                        {
                            property.SetColumnType("timestamp without time zone");
                            property.SetValueConverter(new ValueConverter<DateTime?, DateTime?>(
                                v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Local) : v,
                                v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Local) : v));
                        }
                        else if (_databaseType == "Oracle")
                        {
                            property.SetColumnType("DATE");
                            property.SetValueConverter(new ValueConverter<DateTime?, DateTime?>(
                                v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Local) : v,
                                v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Local) : v));
                        }
                    }

                    // Bool -> Oracle(整數) or PostgreSQL(boolean)
                    if (property.ClrType == typeof(bool))
                    {
                        if (_databaseType == "Oracle")
                        {
                            // Oracle 沒有 Boolean 型別，改用 NUMBER(1) 儲存 1/0
                            property.SetColumnType("NUMBER(1)");
                            property.SetValueConverter(new ValueConverter<bool, int>(
                                v => v ? 1 : 0,    // 寫入 DB 時，True -> 1, False -> 0
                                v => v == 1        // 讀出 DB 時，1 -> True, 0 -> False
                            ));
                        }
                        else if (_databaseType == "PostgreSQL")
                        {
                            // PostgreSQL 支援 boolean
                            property.SetColumnType("boolean");
                            // 如果要用布林就不需要 ValueConverter，直接用預設即可
                        }
                    }

                    // Bool? -> Oracle(整數) or PostgreSQL(boolean)
                    if (property.ClrType == typeof(bool?))
                    {
                        if (_databaseType == "Oracle")
                        {
                            property.SetColumnType("NUMBER(1)");
                            property.SetValueConverter(new ValueConverter<bool?, int?>(
                                v => v.HasValue ? (v.Value ? 1 : 0) : null,  // 寫入 DB
                                v => v.HasValue ? (v.Value == 1) : (bool?)null // 讀出 DB
                            ));
                        }
                        else if (_databaseType == "PostgreSQL")
                        {
                            property.SetColumnType("boolean");
                        }
                    }
                }
            }
        }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    try
        //    {
        //        base.OnModelCreating(modelBuilder);

        //        // 轉換表名和列名為小寫
        //        foreach (var entity in modelBuilder.Model.GetEntityTypes())
        //        {
        //            //entity.SetTableName(entity.GetTableName().ToLower());

        //            foreach (var property in entity.GetProperties())
        //            {
        //                //property.SetColumnName(property.GetColumnName(StoreObjectIdentifier.Table(entity.GetTableName(), null)).ToLower());
        //                if (property.ClrType == typeof(DateTime))
        //                {
        //                    // 添加一個轉換器，強制將 DateTime 設置為 UTC
        //                    property.SetValueConverter(new ValueConverter<DateTime, DateTime>(
        //                        v => DateTime.SpecifyKind(v, DateTimeKind.Local), // 存儲時轉換為 UTC
        //                        v => DateTime.SpecifyKind(v, DateTimeKind.Local)  // 讀取時轉換為 UTC
        //                    ));
        //                }
        //                else if (property.ClrType == typeof(DateTime?))
        //                {
        //                    // 添加一個轉換器，處理 Nullable<DateTime> 並將其設置為 UTC
        //                    property.SetValueConverter(new ValueConverter<DateTime?, DateTime?>(
        //                        v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Local) : v,
        //                        v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Local) : v
        //                    ));
        //                }
        //            }

        //            //foreach (var key in entity.GetKeys())
        //            //{
        //            //    key.SetName(key.GetName().ToLower());
        //            //}

        //            //foreach (var index in entity.GetIndexes())
        //            //{
        //            //    index.SetDatabaseName(index.GetDatabaseName().ToLower());
        //            //}

        //            //foreach (var fk in entity.GetForeignKeys())
        //            //{
        //            //    fk.SetConstraintName(fk.GetConstraintName().ToLower());
        //            //}
        //        }
                

        //        // 設置 ParcelDataEntity 的表
        //        modelBuilder.Entity<UserEntity>()
        //            .ToTable("Users")
        //            .HasKey(s => s.Id); // 設置主鍵

        //        modelBuilder.Entity<UserEntity>().Property(e => e.LastLoginTime)
        //                      .HasColumnType("timestamp without time zone");
        //        modelBuilder.Entity<UserEntity>().Property(e => e.LastUpdatedTime)
        //                      .HasColumnType("timestamp without time zone");
        //        modelBuilder.Entity<UserEntity>().Property(e => e.LockTime)
        //                      .HasColumnType("timestamp without time zone");
        //        modelBuilder.Entity<UserEntity>().Property(e => e.RefreshTokenExpiryTime)
        //                      .HasColumnType("timestamp without time zone");


        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error occurred in OnModelCreating method", ex);
        //    }
        //}
    }
}
