﻿using System.ComponentModel.DataAnnotations;

namespace SystemService.Infrastructure.Persistence.Model
{
    public class WarehouseEntity
    {
        public required string WarehouseID { get; set; }

        public required string CustomerID { get; set; }

        public required string WarehouseName { get; set; }

        public string? Address { get; set; }
        public string? CreateBy { get; set; }
        public DateTime? CreateAt { get; set; }
        public string? UpdateBy { get; set; }
        public DateTime? UpdateAt { get; set; }
        public string? Description { get; set; }

        // 導覽屬性：所屬客戶
        public virtual CustomerEntity? Customer { get; set; }
        // 導覽屬性：一個倉庫有多個區域
        public virtual ICollection<ZoneEntity>? Zones { get; set; }
    }
}
