﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class MenuEntity
    {
        public int MENU_ID {  get; set; }
        public DateTime CREATED_AT { get; set; }
        public string CREATED_BY { get; set; }
        public DateTime? UPDATED_AT { get; set; }
        public string? UPDATED_BY { get; set; }
        public int? PARENT_ID { get;set; }
        public string? PATH {  get; set; }
        public string? ICON {  get; set; }
        public int SORT_ORDER {  get; set; }
        public int ENABLED { get; set; }
        public string? MENU_TYPE {  get; set; }
        public int IS_EXPANDABLE { get; set; }
        public string I18N_KEY {  get; set; }
    }
}
