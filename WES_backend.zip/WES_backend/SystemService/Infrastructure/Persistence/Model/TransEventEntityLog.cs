﻿using Nest;
using System;

namespace SystemService.Infrastructure.Persistence.Model
{
    public class TransEventEntityLog
    {
        public int TRANS_NUM { get; set; }
        public required string TARGET_NAME { get; set; }
        public required Guid SESSION_ID { get; set; }
        public Guid ORG_SESSION_ID { get; set; }
        public string? STATUS { get; set; }
        public DateTime CREATE_AT { get; set; }
        public DateTime? UPDATE_AT { get; set; }
        public string? UPDATE_BY { get; set; }
        public DateTime? END_AT { get; set; }
        public string? ERROR_MESSAGE { get; set; }
        public DateTime? START_AT { get; set; }
        public string? REMARK1 { get; set; }
    }
}
