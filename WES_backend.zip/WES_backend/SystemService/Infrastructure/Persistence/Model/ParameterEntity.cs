﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class ParameterEntity
    {
        public required string FuncGroup { get; set; }
        public required string FuncKey { get; set; }

        public required string FuncSort { get; set; }
        public required string FuncType { get; set; }
        public required string FuncValue { get; set; }
        public string? Descript { get; set; }

        public string? CreateBy { get; set; }
        public DateTime CreateAt { get; set; }
        public string? UpdateBy { get; set; }
        public DateTime UpdateAt { get; set; }
    }
}
