﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class HealthEntity
    {
        public required string ServiceName { get; set; }

        public required string Url { get; set; }

        public required bool Alive { get; set; }

        public required DateTime LastUpdated { get; set; }

        public required string Environment { get; set; }

        public required string CustomerID { get; set; }

        public required string WarehouseID { get; set; }

        public required string ZoneID { get; set; }

    }
}
