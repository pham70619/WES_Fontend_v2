﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class UserEntity
    {
        public Guid Id { get; set; }
        public required string Username { get; set; }
        public required string PasswordHash { get; set; }
        public string? Email { get; set; }
        public int IsActive { get; set; }
        public DateTime LastUpdatedTime { get; set; }
        public DateTime LastLoginTime { get; set; }
        public int ErrorTimes { get; set; }
        public DateTime LockTime { get; set; }
        public int Level { get; set; }
        public string? RefreshToken { get; set; }
        public DateTime RefreshTokenExpiryTime { get; set; }

    }
}
