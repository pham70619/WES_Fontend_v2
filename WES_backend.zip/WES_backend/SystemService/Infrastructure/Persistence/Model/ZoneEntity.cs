﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class ZoneEntity
    {
        // 複合主鍵一部份
        public required string WarehouseID { get; set; }
        // 複合主鍵另一部份
        public required string ZoneID { get; set; }

        public string? CreateBy { get; set; }
        public DateTime? CreateAt { get; set; }
        public string? UpdateBy { get; set; }
        public DateTime? UpdateAt { get; set; }
        public string? Description { get; set; }

        // 導覽屬性：所屬倉庫
        public virtual WarehouseEntity? Warehouse { get; set; }
    }
}
