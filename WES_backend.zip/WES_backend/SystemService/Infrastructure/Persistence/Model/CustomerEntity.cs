﻿using System.ComponentModel.DataAnnotations;

namespace SystemService.Infrastructure.Persistence.Model
{
    public class CustomerEntity
    {
        public required string CustomerID { get; set; }

        public required string CustomerName { get; set; }

        public string? CreateBy { get; set; }
        public DateTime? CreateAt { get; set; }
        public string? UpdateBy { get; set; }
        public DateTime? UpdateAt { get; set; }
        public string? Description { get; set; }

        // 導覽屬性：一個客戶有多個倉庫
        public virtual ICollection<WarehouseEntity>? Warehouses { get; set; }
    }
}
