﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class CompanyMenuEntity
    {
        public int COMPANY_ID { get; set; }
        public string  COMPANY_NAME { get; set; }
        public int MENU_ID { get; set; }
        public string I18N_KEY { get; set; }
        public DateTime CREATED_AT { get; set; }
        public string CREATED_BY { get; set; }
    }
}
