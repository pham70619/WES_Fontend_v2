﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class CompanyEntity
    {
        public int COMPANY_ID { get; set; }
        public string COMPANY_NAME { get; set; }
        public string COMPANY_SHORT_NAME { get; set; }
        public string? GUI { get; set; }
        public string? ADDRESS { get; set; }
        public int STATUS { get; set; }
        public DateTime? CREATED_AT { get; set; }
        public string? CREATED_BY { get; set; }
        public DateTime? UPDATED_AT { get; set; }
        public string? UPDATED_BY { get;set; }
    }
}
