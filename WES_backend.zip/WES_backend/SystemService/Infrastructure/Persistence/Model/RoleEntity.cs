﻿namespace SystemService.Infrastructure.Persistence.Model
{
    public class RoleEntity
    {
        public int ROLE_ID { get; set; }
        public int COMPANY_ID { get; set; }
        public string ROLE_NAME { get; set; }
        public DateTime CREATED_AT { get; set; }
        public string CREATED_BY { get; set; }
        public DateTime? UPDATED_AT { get; set; }
        public string? UPDATED_BY { get; set; }
    }
}
