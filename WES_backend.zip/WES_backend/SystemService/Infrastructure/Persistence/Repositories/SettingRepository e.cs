﻿using Microsoft.EntityFrameworkCore;
using System;
using SystemService.Domain.Interface.Setting;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence.Repositories
{
    public class SettingRepository : ISettingRepository
    {
        private readonly SystemDbContext _dbContext;
        public SettingRepository(SystemDbContext context)
        {
            _dbContext = context;
        }

        #region Customer Methods

        public async Task<CustomerEntity?> GetCustomerByIdAsync(string customerId)
        {
            try
            {
                return await _dbContext.Customers.FindAsync(new object[] { customerId });

            }
            catch (Exception ex) 
            {
                throw;
            }
            // 使用 FindAsync 因 Customer 的 PK 為單一欄位
        }

        public async Task<IEnumerable<CustomerEntity>> SearchCustomersAsync(string customerId, string customerName)
        {
            var query = _dbContext.Customers.AsQueryable();
            if (!string.IsNullOrEmpty(customerId))
                query = query.Where(c => c.CustomerID.Contains(customerId));
            if (!string.IsNullOrEmpty(customerName))
                query = query.Where(c => c.CustomerName.Contains(customerName));
            return await query.ToListAsync();
        }

        public async Task AddCustomerAsync(CustomerEntity customer)
        {
            try
            {
                await _dbContext.Customers.AddAsync(customer);

            }
            catch (Exception ex) 
            {
                throw;
            }
        }

        public async Task UpdateCustomerAsync(CustomerEntity customer)
        {
            _dbContext.Customers.Update(customer);
            await Task.CompletedTask;
        }

        public async Task DeleteCustomerAsync(CustomerEntity customer)
        {
            _dbContext.Customers.Remove(customer);
            await Task.CompletedTask;
        }

        #endregion

        #region Warehouse Methods

        public async Task<WarehouseEntity?> GetWarehouseByIdAsync(string warehouseId)
        {
            return await _dbContext.Warehouses.FindAsync(new object[] { warehouseId });
        }

        public async Task<IEnumerable<WarehouseEntity>> SearchWarehousesAsync(string warehouseId, string warehouseName)
        {
            var query = _dbContext.Warehouses.AsQueryable();
            if (!string.IsNullOrEmpty(warehouseId))
                query = query.Where(w => w.WarehouseID.Contains(warehouseId));
            if (!string.IsNullOrEmpty(warehouseName))
                query = query.Where(w => w.WarehouseName.Contains(warehouseName));
            return await query.ToListAsync();
        }

        public async Task AddWarehouseAsync(WarehouseEntity warehouse)
        {
            await _dbContext.Warehouses.AddAsync(warehouse);
        }

        public async Task UpdateWarehouseAsync(WarehouseEntity warehouse)
        {
            _dbContext.Warehouses.Update(warehouse);
            await Task.CompletedTask;
        }

        public async Task DeleteWarehouseAsync(WarehouseEntity warehouse)
        {
            _dbContext.Warehouses.Remove(warehouse);
            await Task.CompletedTask;
        }

        #endregion

        #region Zone Methods

        public async Task<ZoneEntity?> GetZoneByIdAsync(string warehouseId, string zoneId)
        {
            // 若有設定正確的複合主鍵，亦可使用 FindAsync(warehouseId, zoneId)
            return await _dbContext.Zones.FirstOrDefaultAsync(z => z.WarehouseID == warehouseId && z.ZoneID == zoneId);
        }

        public async Task<IEnumerable<ZoneEntity>> SearchZonesAsync(string warehouseId, string zoneId, string warehouseName)
        {
            // 使用 Include 載入關聯的 Warehouse 以便能過濾 WarehouseName
            var query = _dbContext.Zones.Include(z => z.Warehouse).AsQueryable();
            if (!string.IsNullOrEmpty(warehouseId))
                query = query.Where(z => z.WarehouseID.Contains(warehouseId));
            if (!string.IsNullOrEmpty(zoneId))
                query = query.Where(z => z.ZoneID.Contains(zoneId));
            if (!string.IsNullOrEmpty(warehouseName))
                query = query.Where(z => z.Warehouse.WarehouseName.Contains(warehouseName));
            return await query.ToListAsync();
        }

        public async Task AddZoneAsync(ZoneEntity zone)
        {
            await _dbContext.Zones.AddAsync(zone);
        }

        public async Task UpdateZoneAsync(ZoneEntity zone)
        {
            _dbContext.Zones.Update(zone);
            await Task.CompletedTask;
        }

        public async Task DeleteZoneAsync(ZoneEntity zone)
        {
            _dbContext.Zones.Remove(zone);
            await Task.CompletedTask;
        }

        #endregion

        #region Parameter Methods

        public async Task<ParameterEntity?> GetParameterByIdAsync(string funcGroup, string funcKey)
        {
            try
            {
                return await _dbContext.Parameters.FindAsync(new object[] { funcGroup, funcKey });

            }
            catch
            {
                throw;
            }
            // 使用 FindAsync 因 Parameter 的 PK 為單一欄位
        }

        public async Task<IEnumerable<ParameterEntity>> GetAllParametersAsync()
        {
            try 
            {
                var query = _dbContext.Parameters.AsQueryable();
                return await query.ToListAsync();
            }
            catch 
            {
                throw;
            }

        }

        public async Task AddParameterAsync(ParameterEntity Parameter)
        {
            try
            {
                await _dbContext.Parameters.AddAsync(Parameter);

            }
            catch
            {
                throw;
            }
        }

        public async Task UpdateParameterAsync(ParameterEntity Parameter)
        {

            try
            {
                _dbContext.Parameters.Update(Parameter);
                await Task.CompletedTask;
            }
            catch
            {
                throw;
            }
        }

        public async Task DeleteParameterAsync(ParameterEntity Parameter)
        {
            try
            {
                _dbContext.Parameters.Remove(Parameter);
                await Task.CompletedTask;
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Endpoint Methods

        public async Task<EndpointEntity?> GetEndpointByIdAsync(string customerID, string warehouseID, string zoneID, string requestType, string branch)
        {
            try
            {
                return await _dbContext.Endpoints.FindAsync(new object[] { customerID, warehouseID, zoneID, requestType, branch });

            }
            catch
            {
                throw;
            }
            // 使用 FindAsync 因 Endpoint 的 PK 為單一欄位
        }

        public async Task<IEnumerable<EndpointEntity>> GetAllEndpointsAsync()
        {
            try
            {
                var query = _dbContext.Endpoints.AsQueryable();
                return await query.ToListAsync();
            }
            catch
            {
                throw;
            }

        }

        public async Task AddEndpointAsync(EndpointEntity Endpoint)
        {
            try
            {
                await _dbContext.Endpoints.AddAsync(Endpoint);

            }
            catch
            {
                throw;
            }
        }

        public async Task UpdateEndpointAsync(EndpointEntity Endpoint)
        {

            try
            {
                _dbContext.Endpoints.Update(Endpoint);
                await Task.CompletedTask;
            }
            catch
            {
                throw;
            }
        }

        public async Task DeleteEndpointAsync(EndpointEntity Endpoint)
        {
            try
            {
                _dbContext.Endpoints.Remove(Endpoint);
                await Task.CompletedTask;
            }
            catch
            {
                throw;
            }
        }

        #endregion

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            return await _dbContext.SaveChangesAsync(cancellationToken);
        }
    }
}

