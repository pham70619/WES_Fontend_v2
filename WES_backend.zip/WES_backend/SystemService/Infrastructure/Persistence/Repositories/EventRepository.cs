﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Nest;
using SharedKernel.Enum;
using SystemService.Domain.Interface;
using SystemService.Domain.Interface.Setting;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence.Repositories
{
    public class EventRepository : IEventRepository
    {
        private readonly SystemDbContext _dbContext;
        public EventRepository(SystemDbContext context)
        {
            _dbContext = context;
        }

        #region 共用功能

        public async Task SaveChangesAsync()
        {
            await _dbContext.SaveChangesAsync();
        }

        public void ClearChangeTracker()
        {
            _dbContext.ChangeTracker.Clear();
        }

        public async Task<IDbContextTransaction> BeginTransactionAsync()
        {
            return await _dbContext.Database.BeginTransactionAsync();
        }

        #endregion

        public async Task<List<TransEventEntity>?> GetUnprocessedEventAsync()
        {
            // 篩選條件，可根據需求加入更多條件
            var entities = await _dbContext.TransEvents
                .Where(te => te.STATUS == "" || te.STATUS == null || te.STATUS == StatusEnum.None.ToString())
                //.AsNoTracking()
                .OrderBy(te => te.CREATE_AT) 
                .ToListAsync();

            return entities;
        }

        public async Task<TransEventEntity?> GetEventByIdAsync(Guid correlationId)
        {
            // 篩選條件，可根據需求加入更多條件
            var entitiy = await _dbContext.TransEvents
                .Where(te => te.SESSION_ID == correlationId)
                //.AsNoTracking()
                //.OrderBy (te => te.CREATE_AT)
                .FirstOrDefaultAsync();

            return entitiy;
        }

        public async Task AddAsync(TransEventEntity transEvent)
        {
            await _dbContext.TransEvents.AddAsync(transEvent);
            //await Task.CompletedTask;
        }

        public async Task UpdateListAsync(List<TransEventEntity> transEvents)
        {
            _dbContext.TransEvents.UpdateRange(transEvents);
            await Task.CompletedTask;
        }

        public async Task<List<TransEventEntity>> GetDuplicateEventsAsync(List<TransEventEntity> events)
        {
            var eventIds = events.Select(e => e.SESSION_ID).ToList();
            var duplicateEvents = await _dbContext.Set<TransEventEntity>()
                .AsNoTracking()
                .Where(e => eventIds.Contains(e.SESSION_ID) && (e.STATUS == StatusEnum.SyncFailed.ToString() || e.STATUS == StatusEnum.SyncSuccessed.ToString() || e.STATUS == StatusEnum.SyncDead.ToString()))
                .ToListAsync();

            return duplicateEvents;
        }

        // 新增 MoveToLogTableAsync 方法
        public async Task MoveToLogTableAsync(TransEventEntity transEvent)
        {
            var logEntity = new TransEventEntityLog
            {
                SESSION_ID = transEvent.SESSION_ID,
                TARGET_NAME = transEvent.TARGET_NAME,
                STATUS = transEvent.STATUS,
                CREATE_AT = transEvent.CREATE_AT,
                UPDATE_AT = transEvent.UPDATE_AT,
                UPDATE_BY = transEvent.UPDATE_BY,
                ERROR_MESSAGE = transEvent.ERROR_MESSAGE,
                REMARK1 = transEvent.REMARK1,
                END_AT = transEvent.END_AT
            };

            await _dbContext.TransEventsLog.AddAsync(logEntity);
            _dbContext.TransEvents.Remove(transEvent);
            await _dbContext.SaveChangesAsync();
        }
    }
}
