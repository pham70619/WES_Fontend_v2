﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using SystemService.Domain.Entity;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence.Repositories
{
    public class SystemRepository : ISystemRepository
    {
        private readonly SystemDbContext _dbContext;
        private readonly IMapper _mapper;


        public SystemRepository(SystemDbContext context, IMapper mapper)
        {
            _dbContext = context;
            _mapper = mapper;
        }

        #region 共用功能

        public async Task SaveChangesAsync()
        {
            await _dbContext.SaveChangesAsync();
        }

        public void ClearChangeTracker()
        {
            _dbContext.ChangeTracker.Clear();
        }

        public async Task<IDbContextTransaction> BeginTransactionAsync()
        {
            return await _dbContext.Database.BeginTransactionAsync();
        }

        #endregion

        public async Task<User> GetByUsernameAsync(string username)
        {
            var entities = await _dbContext.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Username == username);
            return _mapper.Map<User>(entities);
            
        }

        public async Task AddAsync(User user)
        {
            var entity = _mapper.Map<UserEntity>(user);
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            _dbContext.Users.Add(entity);

            Console.WriteLine(_dbContext.Users.ToQueryString());

            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(User user)
        {
            var entity = _mapper.Map<UserEntity>(user);
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            _dbContext.Users.Update(entity);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<User> GetByRefreshTokenAsync(string refreshToken)
        {
            var entity = await _dbContext.Users.FirstOrDefaultAsync(u => u.RefreshToken == refreshToken);
            return _mapper.Map<User>(entity);
        }

        public async Task<List<HealthEntity>?> GetAllHealthAsync(string customerID, string warehouseID, string zoneID)
        {
            // 篩選條件，可根據需求加入更多條件
            var entities = await _dbContext.Healths
                .Where(h => h.CustomerID == customerID &&
                            h.WarehouseID == warehouseID &&
                            h.ZoneID == zoneID)
                .AsNoTracking()
                .ToListAsync();

            return entities;
        }

        public async Task AddAndUpdateAsync(List<HealthEntity> healths)
        {
            if (healths == null)
                throw new ArgumentNullException(nameof(healths));

            var services = healths.Select(s => s.ServiceName).ToList();

            // 查詢已存在的品號
            var existingEntities = await _dbContext.Healths
                .Where(s => services.Contains(s.ServiceName))
                .AsNoTracking()
                .ToListAsync();

            // 使用 ServiceName 分組
            var existingProductIDs = existingEntities.Select(e => e.ServiceName).ToHashSet();
            var entitiesToUpdate = healths.Where(s => existingProductIDs.Contains(s.ServiceName)).ToList();
            var entitiesToAdd = healths.Where(s => !existingProductIDs.Contains(s.ServiceName)).ToList();

            if (entitiesToUpdate.Any())
            {
                // 更新操作
                foreach (var updateEntity in entitiesToUpdate)
                {
                    var existingEntity = existingEntities.First(e => e.ServiceName == updateEntity.ServiceName);
                    _mapper.Map(updateEntity, existingEntity); // 映射更新的值到現有實體
                    _dbContext.Healths.Update(existingEntity);
                }
            }

            if (entitiesToAdd.Any())
            {
                // 新增操作
                var newEntities = _mapper.Map<List<HealthEntity>>(entitiesToAdd);
                await _dbContext.Healths.AddRangeAsync(newEntities);
            }
        }


    }
}
