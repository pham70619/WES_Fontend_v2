﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence.Repositories
{
    public class MenuRepository : IMenuRepository
    {
        private readonly SystemDbContext _context;
        private readonly IMapper _mapper;

        public MenuRepository(SystemDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<MenuDto>> GetMenuAsync()
        {
            var menu = await _context.Wes_Menu
                //.Select(m => new MenuDto
                //{
                //    menu_id = m.MENU_ID,
                //    path = m.PATH,
                //    icon = m.ICON,
                //    sort_order = m.SORT_ORDER,
                //    enabled = m.ENABLED,
                //    menu_type = m.MENU_TYPE,
                //    is_expandable = m.IS_EXPANDABLE,
                //    i18n_key  = m.I18N_KEY
                //})

                //.Where(en => en.ENABLED == 1)
                .ToListAsync();
            var menuDto = _mapper.Map<List<MenuDto>>(menu);

            var menuTree = buildMenuTree(menuDto);

            return menuTree;
        }

        private List<MenuDto> buildMenuTree(List<MenuDto> flatList)
        {
            var lookup = flatList.ToDictionary(x => x.menu_id, x => x);

            var rootItems = new List<MenuDto>();

            foreach (var item in flatList)
            {
                if (item.parent_id.HasValue && lookup.ContainsKey(item.parent_id.Value))
                {
                    var parent = lookup[item.parent_id.Value];
                    parent.children.Add(item);
                }
                else
                {
                    rootItems.Add(item);
                }
            }

            return rootItems
                .OrderBy(x => x.sort_order)
                .ToList();
        }

        public async Task<MenuEntity> SaveOrUpdateMenuAsync(MenuDto dto)
        {
            MenuEntity entity;

            if (dto.menu_id > 0)
            {
                entity = await _context.Wes_Menu.FirstOrDefaultAsync(m => m.MENU_ID == dto.menu_id);
                if (entity == null) throw new Exception("Menu not found");

                entity.PATH = dto.path;
                entity.ICON = dto.icon;
                entity.SORT_ORDER = dto.sort_order;
                entity.ENABLED = dto.enabled;
                entity.MENU_TYPE = dto.menu_type;
                entity.IS_EXPANDABLE = dto.is_expandable;
                entity.I18N_KEY = dto.i18n_key;
                entity.PARENT_ID = dto.parent_id;
                entity.UPDATED_AT = DateTime.UtcNow;
                entity.UPDATED_BY = "system"; // Hoặc lấy từ token user

                _context.Wes_Menu.Update(entity);
            }
            else
            {
                entity = new MenuEntity
                {
                    PATH = dto.path,
                    ICON = dto.icon,
                    SORT_ORDER = dto.sort_order,
                    ENABLED = dto.enabled,
                    MENU_TYPE = dto.menu_type,
                    IS_EXPANDABLE = dto.is_expandable,
                    I18N_KEY = dto.i18n_key,
                    PARENT_ID = dto.parent_id,
                    CREATED_AT = DateTime.UtcNow,
                    CREATED_BY = "system" // Hoặc lấy từ token user
                };

                _context.Wes_Menu.Add(entity);
            }

            await _context.SaveChangesAsync();
            return entity;
        }

        // save menu data
        public async Task SaveMenuTreeAsync(List<MenuDto> menuList)
        {
            foreach (var parent in menuList)
            {
                var savedParent = await SaveOrUpdateMenuAsync(parent);

                if (parent.children != null && parent.children.Any())
                {
                    foreach (var child in parent.children)
                    {
                        child.parent_id = savedParent.MENU_ID;
                        await SaveOrUpdateMenuAsync(child);
                    }
                }
            }
        }

        // delete menu data
        public async Task DeleteMenuDataAsync(List<int> menuIds)
        {
            if (menuIds == null || !menuIds.Any())
                return;

            var menusToDelete = await _context.Wes_Menu
                .Where(m => menuIds.Contains(m.MENU_ID))
                .ToListAsync();

            // check id 
            var existingIds = menusToDelete.Select(m => m.MENU_ID).ToHashSet();
            var notFoundIds = menuIds.Where(id => !existingIds.Contains(id)).ToList();

            if (notFoundIds.Any())
            {
                var missing = string.Join(", ", notFoundIds);
                throw new KeyNotFoundException($"Menu ID(s) not found: {missing}");
            }

            //delete list if all exist
            _context.Wes_Menu.RemoveRange(menusToDelete);
            await _context.SaveChangesAsync();
        }
    }
}
