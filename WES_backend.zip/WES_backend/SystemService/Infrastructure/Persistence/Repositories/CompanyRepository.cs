﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence.Repositories
{
    
    public class CompanyRepository : ICompanyRepository
    {
        private readonly SystemDbContext _context;
        private IMapper _mapper;

        public CompanyRepository(SystemDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // get all data
        public async Task<List<CompanyDto>> GetCompanyDataAsync()
        {
            var companies =  await _context.Companies
                .ToListAsync();

            var companyDto = _mapper.Map<List<CompanyDto>>(companies);
            return companyDto;
        }

        // get basic company data (id + name) by id
        public async Task<List<ComBasicDto>> GetComBasicAsync(List<int> ids)
        {
            var ComBasic = await _context.Companies
                .Where(c => ids.Contains(c.COMPANY_ID))
                .Select(c => new ComBasicDto
                {
                    company_id = c.COMPANY_ID,
                    company_name = c.COMPANY_NAME,
                }).ToListAsync();

            return ComBasic;
        }

        // update data
        public async Task UpdateDataAsync(List<updateCompanyDto> companies)
        {
            foreach (var item in companies)
            {
                if(item.company_id > 0)
                {
                    var existingCompany = await _context.Companies
                        .FirstOrDefaultAsync(c => c.COMPANY_ID == item.company_id);

                    if(existingCompany != null)
                    {
                        // Update
                        existingCompany.COMPANY_NAME = item.company_name;
                        existingCompany.COMPANY_SHORT_NAME = item.company_short_name;
                        existingCompany.GUI = item.gui;
                        existingCompany.ADDRESS = item.address;
                        existingCompany.STATUS = item.status ?? 1;
                        existingCompany.UPDATED_AT = DateTime.UtcNow;
                        existingCompany.UPDATED_BY = item.created_by ?? "system";
                    }
                }
                else
                {
                    // Insert
                    var newCompany = new CompanyEntity
                    {
                        COMPANY_NAME = item.company_name,
                        COMPANY_SHORT_NAME = item.company_short_name,
                        GUI = item.gui,
                        ADDRESS = item.address,
                        STATUS = item.status ?? 1,
                        CREATED_AT = DateTime.UtcNow,
                        CREATED_BY = item.created_by ?? "system"
                    };

                    _context.Companies.Add(newCompany);
                }
            }
            await _context.SaveChangesAsync();
        }

        // delete company data
        public async Task DelCompanyDataAsync(List<int> companyIds)
        {
            if (companyIds == null || !companyIds.Any())
                return;

            var companyToDelete = await _context.Companies
                .Where(c => companyIds.Contains(c.COMPANY_ID))
                .ToListAsync();

            // check id 
            var existingIds = companyToDelete.Select(c => c.COMPANY_ID).ToHashSet();
            var notFoundIds = companyIds.Where(id => !existingIds.Contains(id)).ToList();

            if (notFoundIds.Any())
            {
                var missing = string.Join(", ", notFoundIds);
                throw new KeyNotFoundException($"Company ID(s) not found: {missing}");
            }

            //delete list if all exist
            _context.Companies.RemoveRange(companyToDelete);
            await _context.SaveChangesAsync();
        }
    }
}
