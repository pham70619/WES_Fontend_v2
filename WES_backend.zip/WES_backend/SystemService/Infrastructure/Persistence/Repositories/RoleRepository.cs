﻿using SystemService.Domain.Interface;
using SystemService.Application.DTOs.Setting;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence.Repositories
{
    public class RoleRepository : IRoleRepository
    {
        private readonly SystemDbContext _DbContext;
        private readonly IMapper _mapper;

        public RoleRepository(SystemDbContext context, IMapper mapper)
        {
            _DbContext = context;
            _mapper = mapper;
        }

        // get roles data
        public async Task<List<RoleDto>> GetRolesAsync()
        {
            var roles = await _DbContext.Roles.ToListAsync();
            var roleDto = _mapper.Map<List<RoleDto>>(roles);
            return roleDto;
        }

        // get by id
        public async Task<RoleDto?> GetByIdAsync(int id)
        {
            var roles = await _DbContext.Roles.FindAsync(id);
            var roleDto = _mapper.Map<RoleDto>(roles);
            return roleDto;
        }
       

        // delete
        public async Task DeleteAsync(List<int> ids)
        {
            var entities = await _DbContext.Roles
                .Where(r => ids.Contains(r.ROLE_ID))
                .ToListAsync();

            if (entities.Count == 0)
            {
                Console.WriteLine("No roles found for deletion.");
            }

            _DbContext.Roles.RemoveRange(entities);
            await _DbContext.SaveChangesAsync();
        }

        // add
        public async Task AddAsync(AddorUpdateDto dto)
        {
            var newRole = new RoleEntity
            {
                COMPANY_ID = dto.company_id,
                ROLE_NAME = dto.role_name,
                CREATED_AT = DateTime.Now,
                CREATED_BY = "admin",
            };
            await _DbContext.Roles.AddAsync(newRole);
            await _DbContext.SaveChangesAsync();
        }

        // update
        public async Task UpdateAsync(RoleEntity role)
        {
            var existing = await _DbContext.Roles.FindAsync(role.ROLE_ID);
            if (existing != null)
            {
                existing.COMPANY_ID = role.COMPANY_ID;
                existing.ROLE_NAME = role.ROLE_NAME;
                existing.UPDATED_AT = DateTime.Now;
                existing.UPDATED_BY = role.UPDATED_BY;

                // Không cần Update() nếu đang được tracking
                await _DbContext.SaveChangesAsync();
            }
            else
            {
                Console.WriteLine($"Role ID {role.ROLE_ID} not found.");
            }
        }
    }
}
