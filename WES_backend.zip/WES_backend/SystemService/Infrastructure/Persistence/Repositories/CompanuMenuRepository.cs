﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SystemService.Application.DTOs.Setting;
using SystemService.Domain.Interface;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Persistence.Repositories
{
    public class CompanyMenuRepository : ICompanyMenuRepository
    {
        private readonly SystemDbContext _context;
        private readonly IMapper _mapper;

        public CompanyMenuRepository(SystemDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        //get all
        public async Task<List<CompanyMenuDto>> GetCompanyMenuDataAsync()
        {
            var companyMenus = await _context.CompanyMenus
                .ToListAsync();

            var companyDto = _mapper.Map<List<CompanyMenuDto>>(companyMenus);
            return companyDto;
        }

        // add or update
        public async Task UpdateCompanyMenuDataAsync(List<updateCompanyMenuDto> companuMenus)
        {
            foreach (var item in companuMenus)
            {
                var matched = await _context.CompanyMenus
                    .FirstOrDefaultAsync(cm => cm.COMPANY_ID == item.company_id && cm.MENU_ID == item.menu_id);

                if (matched == null)
                {
                    //var newCompanyMenu = _mapper.Map<CompanyMenuEntity>(item);
                    var newCompanyMenu = new CompanyMenuEntity
                    {
                        COMPANY_ID = item.company_id,
                        COMPANY_NAME = item.company_name,
                        MENU_ID = item.menu_id,
                        I18N_KEY = item.i18n_key,
                        CREATED_AT = DateTime.Now,
                        CREATED_BY = "admin"
                    };
                    await _context.CompanyMenus.AddAsync(newCompanyMenu);
                }
            }

            await _context.SaveChangesAsync();
        }

        // delete company menu data
        public async Task DeleteCompanyMenuDataAsync(List<deleteCompanyMenuDto> model)
        {
            if (model == null || !model.Any())
                throw new ArgumentException("Danh sách yêu cầu trống.");

            bool anyDeleted = false;

            foreach(var item in model)
            {
                var record = await _context.CompanyMenus
                    .FirstOrDefaultAsync(cm => cm.COMPANY_ID == item.company_id && cm.MENU_ID == item.menu_id);

                if (record != null)
                {
                    _context.CompanyMenus.Remove(record);
                    anyDeleted = true;
                }
            }

            if (!anyDeleted)
                throw new KeyNotFoundException("Không tìm thấy bản ghi nào để xóa.");

            await _context.SaveChangesAsync();

        }
    }
}
