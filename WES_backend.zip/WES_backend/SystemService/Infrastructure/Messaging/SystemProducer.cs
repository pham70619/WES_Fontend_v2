﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using SystemService.Domain.Interface.Messaging;
using RabbitMQ.Client;
using SharedKernel.Configurations;
using SharedKernel.Interface;
using System.Text;
using SharedKernel.Enum;

namespace SystemService.Infrastructure.Messaging
{
    public class SystemProducer : IEventPublisher
    {
        private readonly RabbitMQSettings _config;
        private readonly IRabbitMQConnection _rabbitMQConnection;
        private readonly ISharedLogger<SystemProducer> _logger;

        public SystemProducer(IRabbitMQConnection rabbitMQConnection, IOptions<RabbitMQSettings> config, ISharedLogger<SystemProducer> logger)
        {
            _config = config.Value;
            _rabbitMQConnection = rabbitMQConnection;
            _logger = logger;
        }

        public void Publish<T>(T eventMessage, string correlationId, string requestType, string exchange, string routingKey, string branch, string? remark, string customerID, string warehouseID, string zoneID, List<string?>? requestIDs) where T : class
        {
            using var channel = _rabbitMQConnection.CreateChannel();  // 創建 Channel

            channel.ConfirmSelect();

            // 生成消息的唯一 ID
            string messageID = Guid.NewGuid().ToString();

            var messageData = JsonConvert.SerializeObject(eventMessage);
            var body = Encoding.UTF8.GetBytes(messageData);

            // 設置消息屬性
            var properties = channel.CreateBasicProperties();
            properties.Headers = new Dictionary<string, object>();
            properties.Headers["RequestIDList"] = requestIDs;
            properties.Headers["RequestType"] = requestType;
            properties.Headers["ToExchange"] = exchange;
            properties.Headers["ToRoutingKeyName"] = routingKey;
            properties.Headers["FromExchange"] = _config.SystemExchange;
            properties.Headers["FromRoutingKeyName"] = _config.EventRoutingKey;
            properties.Headers["Status"] = StatusEnum.Despatching.ToString();
            properties.Headers["RequestTime"] = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff");
            properties.Headers["ReceiveTime"] = string.Empty;
            properties.Headers["Branch"] = branch;
            properties.Headers["CustomerID"] = customerID;
            properties.Headers["WarehouseID"] = warehouseID;
            properties.Headers["ZoneID"] = zoneID;
            properties.Headers["Remark"] = remark ?? string.Empty;
            properties.Persistent = true;  // 設置消息持久化
            properties.MessageId = messageID;  // 設置消息 ID
            properties.CorrelationId = correlationId;

            // 發送消息到 RabbitMQ
            channel.BasicPublish(
                exchange: exchange,
                routingKey: routingKey,
                basicProperties: properties,
                body: body);

            // 組合要記錄的 log 訊息內容
            var logMessage = $"發送消息：{messageData} 至交換機：{exchange}，路由鍵：{routingKey}，分支：{branch}，消息ID：{messageID}";

            // 同步等待確認（例如等待10秒）
            if (!channel.WaitForConfirms(TimeSpan.FromSeconds(10)))
            {
                logMessage = "發送消息異常，轉投至死信對列重試" + logMessage;
                _logger.LogWarning(logMessage);
                try
                {
                    channel.BasicPublish(
                        exchange: _config.DeadLetterExchange,
                        routingKey: _config.DeadLetterRoutingKey,
                        basicProperties: properties,
                        body: body);
                }
                catch (Exception ex)
                {
                    logMessage = "死信隊列重試失敗，請找管理員處理。" + logMessage;
                    _logger.LogError(ex, logMessage);
                    throw;
                }

                _logger.LogRabbitMq(
                    logMessage,               // 訊息內容
                    _config.DeadLetterExchange,                 // Exchange
                    _config.DeadLetterRoutingKey,               // RoutingKey
                    messageData,              // msgBody (事件內容的 JSON)
                    2,                        // deliveryMode (通常 2 為持久性)
                    (Dictionary<string, object>?)(properties.Headers),       // 標頭資訊
                    customerID,               // userId (此處以 customerID 作為識別)
                    correlationId                 // correlationId (使用消息ID作為 Correlation ID)
                );

                throw new TimeoutException("發送消息超時");
            }

            // 如果有需要記錄標頭資訊，可以直接傳遞 properties.Headers
            _logger.LogDebug(logMessage);

            // 如果你的 Logger 實作中有 LogRabbitMq 方法，則可以補全如下：
            _logger.LogRabbitMq(
                logMessage,               // 訊息內容
                exchange,                 // Exchange
                routingKey,               // RoutingKey
                messageData,              // msgBody (事件內容的 JSON)
                2,                        // deliveryMode (通常 2 為持久性)
                (Dictionary<string, object>?)(properties.Headers),       // 標頭資訊
                customerID,               // userId (此處以 customerID 作為識別)
                correlationId                 // correlationId (使用消息ID作為 Correlation ID)
            );
        }
    }
}
