﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Serilog.Context;
using SharedKernel.Configurations;
using SharedKernel.Event;
using SharedKernel.Interface;
using System.Text;
using SystemService.Domain.Interface.EventDespath;
using SystemService.Domain.Interface.Messaging;

namespace SystemService.Infrastructure.Messaging
{
    /// <summary>
    /// 針對 日誌(Log) 消息 的 Consumer，負責從 RabbitMQ讀取 Serilog JSON，再用 Serilog(Log) 寫入ES或其它Sink
    /// </summary>
    public class EventConsumer : BackgroundService
    {
        private readonly ISharedLogger<EventConsumer> _logger;
        private readonly IRabbitMQConnection _rabbitMQConnection;
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly RabbitMQSettings _config;

        // 可依需求設定重試次數
        private readonly int _maxRetryAttempts = 3;

        public EventConsumer(
            ISharedLogger<EventConsumer> logger,
            ILoggerFactory loggerFactory, // 🔹 透過 LoggerFactory 建立專用 Logger
            IRabbitMQConnection rabbitMQConnection,
            IServiceScopeFactory scopeFactory,
            IOptions<RabbitMQSettings> config)
        {
            _logger = logger;
            _rabbitMQConnection = rabbitMQConnection;
            _scopeFactory = scopeFactory;
            _config = config.Value;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            return Task.Run(() =>
            {
                using (LogContext.PushProperty("IgnoreRabbitMQ", true)) // 讓日誌標記
                {
                    // 建立 RabbitMQ channel, 維持監聽
                    try
                    {
                        using var channel = _rabbitMQConnection.CreateChannel();

                        // 避免一次抓太多訊息
                        channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

                        // 宣告 Log Queue
                        channel.QueueDeclare(
                            queue: _config.EventQueue,        // 例如 "LogQueue"
                            durable: true,
                            exclusive: false,
                            autoDelete: false,
                            arguments: new Dictionary<string, object>
                        {
                            { "x-dead-letter-exchange", _config.DeadLetterExchange },
                            { "x-dead-letter-routing-key", _config.DeadLetterRoutingKey },
                            { "x-message-ttl", 600000 }
                        });

                        // 綁定 Queue 到 Exchange
                        // routeKey = _config.RoutingKeyName, 例如 "log"
                        channel.QueueBind(
                            queue: _config.EventQueue,
                            exchange: _config.StatusUpdateExchange,
                            routingKey: string.Empty
                        );

                        var consumer = new EventingBasicConsumer(channel);

                        consumer.Received += async (model, ea) =>
                        {
                            // 每筆訊息建立一個 Scope 以取得 DI 服務
                            using var scope = _scopeFactory.CreateScope();
                            try
                            {
                                var _eventUpdateAppService = scope.ServiceProvider.GetRequiredService<IEventUpdateAppService>();

                                var body = ea.Body.ToArray();
                                var messageJson = Encoding.UTF8.GetString(body);

                            
                                // 反序列化 JSON payload 到 MainfilePayloadDto
                                //var despatchUpdateEvent = JsonConvert.DeserializeObject<DespatchUpdateEvent>(messageJson);
                                var RequestEvent = JsonConvert.DeserializeObject<PresidentEventDto>(messageJson);


                                if (RequestEvent == null || RequestEvent.PresidentEventDetails == null || RequestEvent.PresidentEventDetails.Count == 0)
                                {
                                    _logger.LogWarning("Received message payload is null or invalid JSON.");
                                    throw new ArgumentException("事件轉換失敗");
                                }

                                await _eventUpdateAppService.EventUpdateAsync(RequestEvent);

                                _logger.LogInformation("Processed DespatchUpdate Request successfully. SessionId: {despatchUpdateEvent.DespatchResult.CorrelationId} ", RequestEvent.CorrelationId);

                            




                                // 處理完成後，確認該訊息（ack）
                                channel.BasicAck(ea.DeliveryTag, false);
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, "Error processing Mainfile payload");
                                // 發生例外時，先 ACK 避免訊息重試（依需求也可改成 Nack 與重試機制）
                                channel.BasicAck(ea.DeliveryTag, false);
                            }
                            
                        };


                        channel.BasicConsume(queue: _config.EventQueue, autoAck: false, consumer: consumer);

                        _logger.LogDebug("MainfileConsumer is now listening for System messages on {QueueName}");

                        // 保持服務存活直到取消
                        while (!stoppingToken.IsCancellationRequested)
                        {
                            Thread.Sleep(1000);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogCritical(ex, "Critical exception in EventConsumer: {Msg}", ex.Message);
                    }
                }
            }, stoppingToken);
        }

        public override void Dispose()
        {
            _rabbitMQConnection.Dispose();
            base.Dispose();
        }
    }
}
