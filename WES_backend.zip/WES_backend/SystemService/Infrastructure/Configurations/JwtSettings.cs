﻿namespace SystemService.Infrastructure.Configurations
{
    public class JwtSettings
    {
        public string Secret { get; set; } // 密鑰
        public int ExpirationHours { get; set; } // 過期時間
        public string Issuer { get; set; } // 發行者
        public string Audience { get; set; } // 接收者
    }
}
