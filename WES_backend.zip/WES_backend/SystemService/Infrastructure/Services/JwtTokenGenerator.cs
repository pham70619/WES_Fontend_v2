﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using SystemService.Domain.Entity;
using SystemService.Domain.Interface.UserFuntion;
using SystemService.Infrastructure.Configurations;

namespace SystemService.Infrastructure.Services
{
    public class JwtTokenGenerator : IJwtTokenGenerator
    {
        private readonly JwtSettings _jwtSettings;

        public JwtTokenGenerator(IOptions<JwtSettings> jwtSettings)
        {
            _jwtSettings = jwtSettings.Value;
        }

        public string GenerateToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_jwtSettings.Secret);

            // 根據 Level 添加角色聲明
            string role = GetRoleFromLevel(user.Level);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Claims = new Dictionary<string, object>
                        {
                            { "unique_name", user.Username },
                            { "role", role }
                        },
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Name, user.Username),
                    new Claim(ClaimTypes.Role, role)
                    //new Claim("unique_name", user.Username),
                    //new Claim("role", role)
                    // 其他 Claims，如角色等
                }),
                Expires = DateTime.UtcNow.AddHours(_jwtSettings.ExpirationHours), // 過期時間
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature), // 簽名
                Issuer = _jwtSettings.Issuer, // 發行者
                Audience = _jwtSettings.Audience // 受眾
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private string GetRoleFromLevel(int level)
        {
            return level switch
            {
                10 => "OP", // 操作員Operator
                20 => "ME", // 維修工程師 Maintense Engineer 
                30 => "SS", // 現場主管Site Supervisor
                40 => "MM", // 維護主管 Maintense Manager
                50 => "SM", // 現場負責人Site Manager
                99 => "AD", // 系統管理員Admin
                _ => "User" // 預設角色或根據需要處理
            };
        }
    }
}
