﻿using AutoMapper;
using Microsoft.VisualStudio.Services.Users;
using SharedKernel.Event;
using SystemService.Application.DTOs.Setting;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Infrastructure.Mappers
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<SystemService.Domain.Entity.User, UserEntity>()
                .ForMember(dest => dest.IsActive, opt => opt.MapFrom(src => src.IsActive ? 1 : 0)) // bool -> NUMBER(1)
                .ReverseMap()
                .ForMember(dest => dest.IsActive, opt => opt.MapFrom(src => src.IsActive == 1)); // NUMBER(1) -> bool

            CreateMap<HealthEntity, HealthEntity>();

            CreateMap<TransEventEntity, TransEventEntity>();

            CreateMap<EventDespatchDto, TransEventEntity>()
                .ForMember(dest => dest.START_AT, opt => opt.Ignore()) 
                .ForMember(dest => dest.REMARK1, opt => opt.Ignore())
                .ForMember(dest => dest.ORG_SESSION_ID, opt => opt.Ignore())
                .ReverseMap();

            CreateMap<TransEventEntity, PresidentEventDetailDto>()
                .ForCtorParam("messageId", opt => opt.MapFrom(src => Guid.NewGuid().ToString()))
                .ForCtorParam("correlationId", opt => opt.MapFrom(src => src.SESSION_ID.ToString()))
                .ForCtorParam("isSuccess", opt => opt.MapFrom(src => true))
                .ForCtorParam("status", opt => opt.MapFrom(src => src.STATUS))
                .ForCtorParam("errorMessage", opt => opt.MapFrom(src => src.ERROR_MESSAGE))
                .ForCtorParam("requestIDs", opt => opt.MapFrom(src => new List<string?> { src.SESSION_ID.ToString() }))
                .ForCtorParam("oRG_CorrelationId", opt => opt.MapFrom(src => src.ORG_SESSION_ID));

            CreateMap<TransEventEntity, TransEventEntityLog>()
                .ReverseMap();

            CreateMap<MenuEntity, MenuDto>()
            .ForMember(dest => dest.children, opt => opt.Ignore());
            //.ForMember(dest => dest.enabled, opt => opt.MapFrom(src => src.ENABLED == 1));

           CreateMap<MenuDto, MenuEntity>()
            .ForMember(dest => dest.MENU_ID, opt => opt.Ignore()) 
            .ForMember(dest => dest.CREATED_AT, opt => opt.Ignore())
            .ForMember(dest => dest.CREATED_BY, opt => opt.Ignore())
            .ForMember(dest => dest.UPDATED_AT, opt => opt.Ignore())
            .ForMember(dest => dest.UPDATED_BY, opt => opt.Ignore());


            CreateMap<CompanyEntity, CompanyDto>();
            CreateMap<CompanyMenuEntity, CompanyMenuDto>();
            CreateMap<updateCompanyMenuDto, CompanyMenuEntity>()
            .ForMember(dest => dest.CREATED_AT, opt => opt.MapFrom(src => DateTime.Now))
            .ForMember(dest => dest.CREATED_BY, opt => opt.MapFrom(src => "admin"));

            CreateMap<RoleEntity, RoleDto>();
            CreateMap<RoleDto, RoleEntity>();
        }
    }
}
