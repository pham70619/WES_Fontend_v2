﻿using SystemService.Domain.Interface.Messaging;
using RabbitMQ.Client;
using SharedKernel.Configurations;

namespace SystemService.Infrastructure.RabbieMQ
{
    public class RabbitMQConnection : IRabbitMQConnection
    {
        private readonly IConnection _connection;

        public RabbitMQConnection(RabbitMQSettings config)
        {
            var factory = new ConnectionFactory() { HostName = config.HostName };
            _connection = factory.CreateConnection(); // 創建一個 RabbitMQ 連接
        }

        public IModel CreateChannel()
        {
            return _connection.CreateModel(); // 創建並返回一個新的 Channel
        }

        public void Dispose()
        {
            _connection.Dispose(); // 關閉連接
        }
    }
}
