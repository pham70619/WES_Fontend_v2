﻿using Quartz;
using SharedKernel.Interface;
using SystemService.Domain.Interface.EventDespath;
using SystemService.Domain.Interface.Health;

namespace SystemService.Infrastructure.Quartz.Jobs.EventDespath
{
    [DisallowConcurrentExecution]
    public class EventDespathJob : IJob
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ISharedLogger<EventDespathJob> _logger;

        public EventDespathJob(IServiceProvider serviceProvider, ISharedLogger<EventDespathJob> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            try
            {
                using (var scope = _serviceProvider.CreateScope())
                {
                    _logger.LogDebug("EventDespathJob started.");
                    var eventDespatchAppService = scope.ServiceProvider.GetRequiredService<IEventDespatchAppService>();
                    await eventDespatchAppService.EventDespatchAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing Execute EventDespathJob.Because" + ex.Message);
            }

        }
    }
}
