﻿using Quartz;
using SharedKernel.Interface;
using SystemService.Domain.Interface.Health;

namespace OutboundService.Infrastructure.Quartz.Jobs.Order
{
    [DisallowConcurrentExecution]
    public class HealthCheckJob : IJob
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ISharedLogger<HealthCheckJob> _logger;

        public HealthCheckJob(IServiceProvider serviceProvider, ISharedLogger<HealthCheckJob> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            try
            {
                using (var scope = _serviceProvider.CreateScope())
                {
                    _logger.LogDebug("HealthCheckJob started.");
                    var healthSyncAppService = scope.ServiceProvider.GetRequiredService<IHealthCheckAppService>();
                    await healthSyncAppService.HealthCheckAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing Execute OrderSyncJob.");
            }

        }
    }
}
