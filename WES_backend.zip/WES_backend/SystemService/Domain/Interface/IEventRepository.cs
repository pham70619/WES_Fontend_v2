﻿using Microsoft.EntityFrameworkCore.Storage;
using SystemService.Domain.Entity;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Domain.Interface
{
    public interface IEventRepository
    {
        #region 共用功能
        Task SaveChangesAsync();
        void ClearChangeTracker();
        Task<IDbContextTransaction> BeginTransactionAsync();
        #endregion

        Task<List<TransEventEntity>?> GetUnprocessedEventAsync();
        Task<TransEventEntity?> GetEventByIdAsync(Guid correlationId);
        Task AddAsync(TransEventEntity transEvent);
        Task UpdateListAsync(List<TransEventEntity> transEvents);
        Task<List<TransEventEntity>> GetDuplicateEventsAsync(List<TransEventEntity> events);
        Task MoveToLogTableAsync(TransEventEntity transEvent);

    }
}
