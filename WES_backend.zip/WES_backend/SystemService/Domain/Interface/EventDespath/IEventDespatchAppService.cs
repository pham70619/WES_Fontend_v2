﻿namespace SystemService.Domain.Interface.EventDespath
{
    public interface IEventDespatchAppService
    {
        Task EventDespatchAsync();
    }
}
