﻿using SharedKernel.Event;

namespace SystemService.Domain.Interface.EventDespath
{
    public interface IEventUpdateAppService
    {
        Task EventUpdateAsync( PresidentEventDto updateEvent);
    }
}
