﻿using SystemService.Application.DTOs.Setting;

namespace SystemService.Domain.Interface
{
    public interface ICompanyRepository
    {
        // get company data
        Task<List<CompanyDto>> GetCompanyDataAsync();

        // get basic company data (id + name) by id
        Task<List<ComBasicDto>> GetComBasicAsync(List<int> ids);
        // update company data
        Task UpdateDataAsync(List<updateCompanyDto> companies);

        // delete company data
        Task DelCompanyDataAsync(List<int> companyIds);
    }
}
