﻿using SystemService.Application.DTOs.Setting;

namespace SystemService.Domain.Interface
{
    public interface ICompanyMenuRepository
    {
        // get
        Task<List<CompanyMenuDto>> GetCompanyMenuDataAsync();

        // add or update
        Task UpdateCompanyMenuDataAsync(List<updateCompanyMenuDto> companuMenus);

        ////delete
        Task DeleteCompanyMenuDataAsync(List<deleteCompanyMenuDto> companuMenus);
    }
}
