﻿using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Domain.Interface.Health
{
    public interface IHealthCheckAppService
    {
        public Task HealthCheckAsync();
    }
}
