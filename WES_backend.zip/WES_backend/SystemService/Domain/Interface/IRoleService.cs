﻿using SystemService.Application.DTOs.Setting;

namespace SystemService.Domain.Interface
{
    public interface IRoleService
    {
        // get data
        Task<List<roleDataResponseDto>> GetRoleDataAsync();

        // add or update
        Task AddorUpdateAsync(List<AddorUpdateDto> dtoList);

        // delete
        Task DeleteAsync(List<int> ids);
    }
}
