﻿using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Domain.Interface.Setting
{
    public interface ISettingRepository
    {
        // 客戶相關方法
        Task<CustomerEntity?> GetCustomerByIdAsync(string customerId);
        Task<IEnumerable<CustomerEntity>> SearchCustomersAsync(string customerId, string customerName);
        Task AddCustomerAsync(CustomerEntity customer);
        Task UpdateCustomerAsync(CustomerEntity customer);
        Task DeleteCustomerAsync(CustomerEntity customer);

        // 倉庫相關方法
        Task<WarehouseEntity?> GetWarehouseByIdAsync(string warehouseId);
        Task<IEnumerable<WarehouseEntity>> SearchWarehousesAsync(string warehouseId, string warehouseName);
        Task AddWarehouseAsync(WarehouseEntity warehouse);
        Task UpdateWarehouseAsync(WarehouseEntity warehouse);
        Task DeleteWarehouseAsync(WarehouseEntity warehouse);

        // 區域相關方法
        Task<ZoneEntity?> GetZoneByIdAsync(string warehouseId, string zoneId);
        Task<IEnumerable<ZoneEntity>> SearchZonesAsync(string warehouseId, string zoneId, string warehouseName);
        Task AddZoneAsync(ZoneEntity zone);
        Task UpdateZoneAsync(ZoneEntity zone);
        Task DeleteZoneAsync(ZoneEntity zone);

        // 參數相關方法
        Task<ParameterEntity?> GetParameterByIdAsync(string funcGroup, string funcKey);
        Task<IEnumerable<ParameterEntity>> GetAllParametersAsync();
        Task AddParameterAsync(ParameterEntity parameter);
        Task UpdateParameterAsync(ParameterEntity parameter);
        Task DeleteParameterAsync(ParameterEntity parameter);

        // 參數相關方法
        Task<EndpointEntity?> GetEndpointByIdAsync(string customerID, string warehouseID, string zoneID, string requestType, string branch);
        Task<IEnumerable<EndpointEntity>> GetAllEndpointsAsync();
        Task AddEndpointAsync(EndpointEntity endpoint);
        Task UpdateEndpointAsync(EndpointEntity endpoint);
        Task DeleteEndpointAsync(EndpointEntity endpoint);

        // 統一儲存變更 (可視需求移至 Unit of Work)
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}
