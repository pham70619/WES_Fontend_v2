﻿using RabbitMQ.Client;

namespace SystemService.Domain.Interface.Messaging
{
    public interface IRabbitMQConnection : IDisposable
    {
        IModel CreateChannel();
    }
}
