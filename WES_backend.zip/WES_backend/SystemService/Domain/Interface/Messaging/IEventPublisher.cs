﻿namespace SystemService.Domain.Interface.Messaging
{
    public interface IEventPublisher
    {
        void Publish<T>(T eventMessage, string correlationId, string requestType, string exchange, string routingKey, string branch, string? remark, string customerID, string warehouseID, string zoneID, List<string?>? requestIDs) where T : class;
    }
}
