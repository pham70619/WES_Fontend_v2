﻿using Microsoft.EntityFrameworkCore.Storage;
using SystemService.Domain.Entity;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Domain.Interface
{
    public interface ISystemRepository
    {
        #region 共用功能

        Task SaveChangesAsync();

        void ClearChangeTracker();

        Task<IDbContextTransaction> BeginTransactionAsync();

        #endregion
        Task<SystemService.Domain.Entity.User> GetByUsernameAsync(string username);
        Task<SystemService.Domain.Entity.User> GetByRefreshTokenAsync(string refreshToken);
        Task AddAsync(SystemService.Domain.Entity.User user);
        Task UpdateAsync(SystemService.Domain.Entity.User user);

        Task<List<HealthEntity>?> GetAllHealthAsync(string customerID, string warehouseID, string zoneID);
        Task AddAndUpdateAsync(List<HealthEntity> healths);

    }
}
