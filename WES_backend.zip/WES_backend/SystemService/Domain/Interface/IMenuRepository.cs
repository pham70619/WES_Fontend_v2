﻿using SystemService.Application.DTOs.Setting;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Domain.Interface
{
    public interface IMenuRepository
    {
        Task<List<MenuDto>> GetMenuAsync();
        Task SaveMenuTreeAsync(List<MenuDto> menuList);
        Task DeleteMenuDataAsync(List<int> menuIds);
    }
}
