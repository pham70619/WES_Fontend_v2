﻿namespace SystemService.Domain.Interface.UserFuntion
{
    public interface IJwtTokenGenerator
    {
        string GenerateToken(SystemService.Domain.Entity.User user);
    }
}
