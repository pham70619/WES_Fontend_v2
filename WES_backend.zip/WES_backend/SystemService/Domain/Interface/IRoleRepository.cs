﻿using Microsoft.AspNetCore.Authorization.Infrastructure;
using SystemService.Application.DTOs.Setting;
using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Domain.Interface
{
    public interface IRoleRepository
    {
        Task<List<RoleDto>> GetRolesAsync();
        Task<RoleDto?> GetByIdAsync(int id);
        Task AddAsync(AddorUpdateDto dto);
        Task UpdateAsync(RoleEntity role);
        Task DeleteAsync(List<int> ids);
    }
}
