﻿using System.Security.Cryptography;

namespace SystemService.Domain.Entity
{
    public class User
    {
        public Guid Id { get; private set; }
        public string Username { get; private set; }
        public string PasswordHash { get; private set; }
        public string Email { get; private set; } = "";
        public bool IsActive { get; private set; } = true;
        public DateTime LastUpdatedTime { get; private set; } = DateTime.Now;
        public DateTime LastLoginTime { get; private set; } = DateTime.Now;
        public int ErrorTimes { get; private set; } = 0;
        public DateTime LockTime { get; private set; }
        public int Level { get; private set; }
        public string RefreshToken { get; private set; }
        public DateTime RefreshTokenExpiryTime { get; private set; }
        // 其他屬性如角色、權限等

        public User(string username, string passwordHash, string? email, int level)
        {
            Id = Guid.NewGuid();
            Username = username;
            PasswordHash = passwordHash;
            Email = email ?? "";
            IsActive = true;
            Level = level;
            RefreshToken = GenerateRefreshToken();
            RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7); // 設置刷新令牌有效期
        }

        public void Deactivate()
        {
            IsActive = false;
        }

        public void UpdateUser(string username, string passwordHash, string email, int errorTimes, DateTime lockTime, int level)
        {
            Username = username;
            PasswordHash = passwordHash;
            Email = email;
            ErrorTimes = errorTimes;
            LockTime = lockTime;
            Level = level;
        }

        public void UpdateLastLoginTime(DateTime lastLoginTime)
        {
            LastLoginTime = lastLoginTime;
        }

        public void UnlockAndClearErrorTimes()
        {
            ErrorTimes = 0;
        }

        public void UpdateErrorTimesAndSetLockTime()
        {
            ErrorTimes = ErrorTimes++;
            if (ErrorTimes >= 5)
            {
                LockTime = DateTime.Now.AddMinutes(3);
            }
        }

        public void UpdateRefreshToken()
        {
            RefreshToken = GenerateRefreshToken();
            RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7);
        }

        public void ClearRefreshToken()
        {
            RefreshToken = null;
            RefreshTokenExpiryTime = DateTime.MinValue;
        }

        private string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
    }
}
