﻿using BCrypt.Net; 

namespace SystemService.Domain.ValueObject
{
    public class Password
    {
        public string Hash { get; private set; }

        public Password(string plainPassword)
        {
            // 實現密碼哈希邏輯
            Hash = HashPassword(plainPassword);
        }

        private string HashPassword(string plainPassword)
        {
            // 使用適當的哈希算法，如 BCrypt
            return BCrypt.Net.BCrypt.HashPassword(plainPassword);
        }

        public bool Verify(string plainPassword)
        {
            return BCrypt.Net.BCrypt.Verify(plainPassword, Hash);
        }
    }
}
