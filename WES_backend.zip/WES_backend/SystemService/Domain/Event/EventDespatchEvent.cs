﻿using SystemService.Infrastructure.Persistence.Model;

namespace SystemService.Domain.Event
{
    public class EventDespatchEvent
    {
        public EventDespatchDto EventRequestDto { get; }
        public DateTime RequestAt { get; }

        public EventDespatchEvent(EventDespatchDto orderInfo, DateTime transAt)
        {
            EventRequestDto = orderInfo;
            RequestAt = transAt;
        }
    }
}
