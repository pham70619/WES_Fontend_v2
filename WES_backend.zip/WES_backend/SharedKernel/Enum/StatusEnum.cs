﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Enum
{
    public enum StatusEnum
    {
        None = 0,
        Pending = 1, // Order專用，供人員操作綁批送出
        Despatching = 2, //System發佈時更新
        Despatched = 3, //Service接收時更新
        Processing = 4, //Service轉發時更新
        Processed = 5, //Transmission接收時更新
        SyncFailed = 6, //同步資料失敗
        SyncSuccessed = 7, //同步資料成功
        SyncDead = 99 //同步資料失敗並重試三次皆無法成功
    }
}
