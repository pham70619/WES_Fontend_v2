﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Enum
{
    public enum EventEnum
    {
        None = 0,
        SKUMaster = 10,
        SKUMaster_Despatch = 11,
        SKUMaster_Transmission = 12,
        SKUMaster_Update = 13,
        SKUMaster_Error = 19,
        InboundPalletInfo = 20,
        OrderInfo = 30,
        RetrieveLoad = 40
    }
}
