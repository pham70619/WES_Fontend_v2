﻿using SharedKernel.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace SharedKernel.Messaging
{
    public class MessageFailureHandler : IMessageFailureHandler
    {
        public async Task HandleMessageFailureAsync(IModel channel, BasicDeliverEventArgs ea, int retryCount, int maxRetryAttempts, string deadLetterQueueName, string deadLetterExchange, string deadLetterRoutingKey)
        {
            // 增加重试次数
            retryCount++;

            if (retryCount >= maxRetryAttempts)
            {
                // 发布到死信队列
                var properties = channel.CreateBasicProperties();
                properties.Headers = ea.BasicProperties.Headers;
                properties.Headers["x-retry-count"] = retryCount;
                properties.Persistent = true;

                channel.BasicPublish(
                    exchange: deadLetterExchange,
                    routingKey: deadLetterRoutingKey,
                    basicProperties: properties,
                    body: ea.Body);

                channel.BasicAck(ea.DeliveryTag, false); // 确认原始消息
            }
            else
            {
                // 将消息重新入队，并更新重试次数
                var properties = channel.CreateBasicProperties();
                properties.Headers = ea.BasicProperties.Headers ?? new Dictionary<string, object>();
                properties.Headers["x-retry-count"] = retryCount;
                properties.Persistent = true;

                channel.BasicPublish(
                    exchange: "",
                    routingKey: ea.RoutingKey,
                    basicProperties: properties,
                    body: ea.Body);

                channel.BasicAck(ea.DeliveryTag, false);
            }

            await Task.CompletedTask;
        }
    }
}
