﻿using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using SharedKernel.Configurations;
using SharedKernel.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Messaging
{
    public class RabbitMQInitializer
    {
        private readonly RabbitMQSettings _config;
        private readonly IModel _channel;
        private readonly ISharedLogger<RabbitMQInitializer> _logger;

        public RabbitMQInitializer(IOptions<RabbitMQSettings> config, IModel channel, ISharedLogger<RabbitMQInitializer> logger)
        {
            _config = config.Value;
            _channel = channel;
            _logger = logger;
        }

        public void Initialize()
        {
            try
            {
                #region 業務邏輯專用

                // 聲明交換機
                _channel.ExchangeDeclare(exchange: _config.InventoryExchange, type: ExchangeType.Direct, durable: true, autoDelete: false);
                _channel.ExchangeDeclare(exchange: _config.DeadLetterExchange, type: ExchangeType.Direct, durable: true, autoDelete: false);
                _channel.ExchangeDeclare(exchange: _config.TransmissionExchange, type: ExchangeType.Direct, durable: true, autoDelete: false);
                _channel.ExchangeDeclare(exchange: _config.OutboundExchange, type: ExchangeType.Direct, durable: true, autoDelete: false);
                _channel.ExchangeDeclare(exchange: _config.InboundExchange, type: ExchangeType.Direct, durable: true, autoDelete: false);
                _channel.ExchangeDeclare(exchange: _config.MainfileExchange, type: ExchangeType.Direct, durable: true, autoDelete: false);
                _channel.ExchangeDeclare(exchange: _config.SystemExchange, type: ExchangeType.Direct, durable: true, autoDelete: false);


                // 隊列參數，與死信隊列關聯
                var queueArgs = new Dictionary<string, object>
                {
                    { "x-dead-letter-exchange", _config.DeadLetterExchange },
                    { "x-dead-letter-routing-key", _config.DeadLetterRoutingKey },
                    { "x-message-ttl", 600000 }
                };

                // 聲明Inventory隊列
                _channel.QueueDeclare(queue: _config.InventoryQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

                // 綁定Inventory和交換機
                //_channel.QueueBind(queue: _config.InventoryQueue, exchange: _config.InventoryExchange, routingKey: _config.I);

                // 聲明Transmission隊列
                _channel.QueueDeclare(queue: _config.TransmissionQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

                // 綁定Transmission和交換機
                _channel.QueueBind(queue: _config.TransmissionQueue, exchange: _config.TransmissionExchange, routingKey: _config.SKUMasterRoutingKey);
                _channel.QueueBind(queue: _config.TransmissionQueue, exchange: _config.TransmissionExchange, routingKey: _config.ArticalRoutingKey);
                _channel.QueueBind(queue: _config.TransmissionQueue, exchange: _config.TransmissionExchange, routingKey: _config.RouteTaskRoutingKey);
                _channel.QueueBind(queue: _config.TransmissionQueue, exchange: _config.TransmissionExchange, routingKey: _config.OrderInfoRoutingKey);
                _channel.QueueBind(queue: _config.TransmissionQueue, exchange: _config.TransmissionExchange, routingKey: _config.RetrieveLoadRoutingKey);
                _channel.QueueBind(queue: _config.TransmissionQueue, exchange: _config.TransmissionExchange, routingKey: _config.InboundPalletInfoRoutingKey);

                // 聲明Outbound隊列
                _channel.QueueDeclare(queue: _config.OutboundQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

                // 綁定Outbound和交換機
                _channel.QueueBind(queue: _config.OutboundQueue, exchange: _config.OutboundExchange, routingKey: _config.OrderInfoRoutingKey);
                _channel.QueueBind(queue: _config.OutboundQueue, exchange: _config.OutboundExchange, routingKey: _config.RetrieveLoadRoutingKey);

                // 聲明Inbound隊列
                _channel.QueueDeclare(queue: _config.InboundQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

                // 綁定Inbound和交換機
                _channel.QueueBind(queue: _config.InboundQueue, exchange: _config.InboundExchange, routingKey: _config.InboundPalletInfoRoutingKey);

                // 聲明Mainfile隊列
                _channel.QueueDeclare(queue: _config.MainfileQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

                // 綁定Mainfile和交換機
                _channel.QueueBind(queue: _config.MainfileQueue, exchange: _config.MainfileExchange, routingKey: _config.ArticalRoutingKey);
                _channel.QueueBind(queue: _config.MainfileQueue, exchange: _config.MainfileExchange, routingKey: _config.SKUMasterRoutingKey);
                _channel.QueueBind(queue: _config.MainfileQueue, exchange: _config.MainfileExchange, routingKey: _config.RouteTaskRoutingKey);

                // 聲明System隊列
                _channel.QueueDeclare(queue: _config.SystemQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                _channel.QueueDeclare(queue: _config.EventQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                _channel.QueueDeclare(queue: _config.LogQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

                // 綁定System和交換機
                _channel.QueueBind(queue: _config.SystemQueue, exchange: _config.SystemExchange, routingKey: _config.SystemRoutingKey);
                _channel.QueueBind(queue: _config.LogQueue, exchange: _config.SystemExchange, routingKey: _config.LogRoutingKey);
                _channel.QueueBind(queue: _config.EventQueue, exchange: _config.SystemExchange, routingKey: _config.EventRoutingKey);


                // 聲明DeadLetter隊列
                _channel.QueueDeclare(queue: _config.DeadLetterQueue, durable: true, exclusive: false, autoDelete: false, arguments: null);

                // 綁定DeadLetter和交換機
                _channel.QueueBind(queue: _config.DeadLetterQueue, exchange: _config.DeadLetterExchange, routingKey: _config.DeadLetterRoutingKey);

                #endregion

                #region 狀態更新專用

                // 聲明狀態更新交換機，使用 Fanout 模式
                _channel.ExchangeDeclare(exchange: _config.StatusUpdateExchange, type: ExchangeType.Fanout, durable: true, autoDelete: false);

                // 針對 Transmission 服務的狀態更新隊列
                _channel.QueueDeclare(queue: _config.TransmissionStatusQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                _channel.QueueBind(queue: _config.TransmissionStatusQueue, exchange: _config.StatusUpdateExchange, routingKey: string.Empty);

                // 針對 Outbound 服務的狀態更新隊列
                _channel.QueueDeclare(queue: _config.OutboundStatusQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                _channel.QueueBind(queue: _config.OutboundStatusQueue, exchange: _config.StatusUpdateExchange, routingKey: string.Empty);

                // 針對 Inbound 服務的狀態更新隊列
                _channel.QueueDeclare(queue: _config.InboundStatusQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                _channel.QueueBind(queue: _config.InboundStatusQueue, exchange: _config.StatusUpdateExchange, routingKey: string.Empty);

                // 針對 Mainfile 服務的狀態更新隊列
                _channel.QueueDeclare(queue: _config.MainfileStatusQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                _channel.QueueBind(queue: _config.MainfileStatusQueue, exchange: _config.StatusUpdateExchange, routingKey: string.Empty);

                // 針對 System 服務的狀態更新隊列
                //_channel.QueueDeclare(queue: _config.SystemQueue, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                _channel.QueueBind(queue: _config.EventQueue, exchange: _config.StatusUpdateExchange, routingKey: string.Empty);


                #endregion

                _logger.LogInformation("RabbitMQ隊列初始化完成");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "RabbitMQ隊列初始化異常"+ex.ToString());
                throw;
            }
        }
    }
}
