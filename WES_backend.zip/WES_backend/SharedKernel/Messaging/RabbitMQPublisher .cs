﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SharedKernel.Configurations;
using SharedKernel.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;

namespace SharedKernel.Messaging
{
    public class RabbitMQPublisher : IRabbitMQPublisher
    {
        private readonly IModel _channel;
        private readonly RabbitMQSettings _settings;
        private readonly ILogger<RabbitMQPublisher> _logger;

        public RabbitMQPublisher(IModel channel, IOptions<RabbitMQSettings> settings, ILogger<RabbitMQPublisher> logger)
        {
            _channel = channel;
            _settings = settings.Value;
            _logger = logger;
        }

        public Task PublishAsync(string message, string routingKey, IDictionary<string, object> headers = null)
        {
            var body = Encoding.UTF8.GetBytes(message);

            var properties = _channel.CreateBasicProperties();
            properties.Persistent = true;
            if (headers != null)
            {
                properties.Headers = headers;
            }

            _channel.BasicPublish(
                exchange: _settings.InventoryExchange,
                routingKey: routingKey,
                basicProperties: properties,
                body: body
            );

            _logger.LogInformation($"Published message to exchange '{_settings.InventoryExchange}' with routing key '{routingKey}'.");

            return Task.CompletedTask;
        }
    }
}
