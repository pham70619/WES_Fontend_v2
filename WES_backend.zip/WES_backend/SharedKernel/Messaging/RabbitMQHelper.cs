﻿using RabbitMQ.Client;
using SharedKernel.Configurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Messaging
{
    public static class RabbitMQHelper
    {
        /// <summary>
        /// 將消息重新發佈到 DeadLetterExchange，並更新 retry count 與錯誤訊息
        /// </summary>
        /// <param name="channel">RabbitMQ Channel</param>
        /// <param name="config">RabbitMQ 設定</param>
        /// <param name="originalProperties">原始的 BasicProperties</param>
        /// <param name="body">消息內容 (byte[])</param>
        /// <param name="retryCount">原始 retry count</param>
        /// <param name="remark">錯誤訊息</param>
        public static void RepublishToDeadLetter(
            IModel channel,
            RabbitMQSettings config,
            IBasicProperties originalProperties,
            byte[] body,
            int retryCount,
            string remark)
        {

                // 如果 retryCount > 0 代表已成功取得原始 retryCount，則加 1；若沒取到則預設為 3，避免無限重試 loop
                int newRetryCount = retryCount >= 0 ? retryCount + 1 : 3;
                // 依照 retryCount 建立對應的錯誤訊息鍵
                string errorMessageKey = "error_message" + newRetryCount.ToString();

                // 建立新的 BasicProperties 並複製原有 Headers（若存在）
                var newProperties = channel.CreateBasicProperties();
                newProperties = originalProperties;
                newProperties.Persistent = true;
                newProperties.Headers = originalProperties.Headers != null
                    ? new Dictionary<string, object>(originalProperties.Headers)
                    : new Dictionary<string, object>();

                // 更新 retry count 與錯誤訊息
                newProperties.Headers["x-retry-count"] = newRetryCount.ToString();
                newProperties.Headers[errorMessageKey] = remark;

                // 發佈消息到 DeadLetterExchange
                channel.BasicPublish(
                    exchange: config.DeadLetterExchange,
                    routingKey: config.DeadLetterRoutingKey,
                    basicProperties: newProperties,
                    body: body);
            

        }
    }

}
