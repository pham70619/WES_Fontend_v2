﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Interface
{
    public interface IMessageFailureHandler
    {
        Task HandleMessageFailureAsync(IModel channel, BasicDeliverEventArgs ea, int retryCount, int maxRetryAttempts, string deadLetterQueueName, string deadLetterExchange, string deadLetterRoutingKey);
    }
}
