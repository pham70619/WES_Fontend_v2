﻿using SharedKernel.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Interface
{
    // ISharedLogger 接口，定義了不同級別的日誌方法
    public interface ISharedLogger<T>
    {
        // 記錄一般信息
        void LogInformation(string message, string? correlationId = null);
        void LogInformation(LogRecord logreocrd);

        // 記錄警告信息
        void LogWarning(string message, string? correlationId = null);
        void LogWarning(LogRecord logreocrd);

        // 記錄錯誤信息，包括異常細節
        void LogError(Exception exception, string message, string? correlationId = null);
        void LogError(LogRecord logreocrd);

        // 記錄嚴重錯誤信息，包括異常細節
        void LogCritical(Exception exception, string message, string? correlationId = null);
        void LogCritical(LogRecord logreocrd);


        void LogDebug(string message);
        void LogDebug(LogRecord logreocrd);

        void LogEvent(string eventName, bool isSuccess, object? payload = null, string? userId = null, string? correlationId = null);

        void LogUserAction(string message, string username);

        void LogApi(string message,
                    string method,
                    string url,
                    string requestBody,
                    string responseBody,
                    int? statusCode = null,
                    string? userId = null,
                    string? correlationId = null);

        void LogRabbitMq(string message,
                         string exchange,
                         string routingKey,
                         string msgBody,
                         byte? deliveryMode = 2,
                         Dictionary<string, object>? headers = null,
                         string? userId = null,
                         string? correlationId = null);
    }
}