﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Interface
{
    public interface IMessageLoggingService
    {
        Task<bool> IsMessageProcessedOrInProgressAsync(string requestId);
        Task LogMessageProcessingStartAsync(string requestId);
        Task LogMessageProcessingResultAsync(string requestId, bool success, string? errorMessage = null, string? requestPayload = null);
    }
}

