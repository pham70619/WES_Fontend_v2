﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Interface
{
    public interface IRabbitMQPublisher
    {
        Task PublishAsync(string message, string routingKey, IDictionary<string, object> headers = null);
    }
}
