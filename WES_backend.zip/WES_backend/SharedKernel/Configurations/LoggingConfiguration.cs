﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Configurations
{
    //LOG系統的POSTGRESQL相關設定
    public class LoggingConfiguration
    {
        public string PostgreSQLConnectionString { get; set; }
        public string TableName { get; set; } = "Logs";
        public string ApplicationName { get; set; }
    }
}
