﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Configurations
{
    public class RabbitMQSettings
    {
        public string HostName { get; set; } = "localhost";
        public int Port { get; set; } = 5672;
        public string UserName { get; set; } = "guest";
        public string Password { get; set; } = "guest";

        //Inventory
        public string InventoryQueue { get; set; } = "InventoryQueue";
        public string InventoryExchange { get; set; } = "InventoryExchange"; // 新增交換機配置

        // Transmission
        public string TransmissionExchange { get; set; } = "TransmissionExchange";
        public string TransmissionQueue { get; set; } = "TransmissionQueue";

        // Outbound
        public string OutboundExchange { get; set; } = "OutboundExchange";
        public string OutboundQueue { get; set; } = "OutboundQueue";

        // Inbound
        public string InboundExchange { get; set; } = "InboundExchange";
        public string InboundQueue { get; set; } = "InboundQueue";

        // Mainfile
        public string MainfileExchange { get; set; } = "MainfileExchange";
        public string MainfileQueue { get; set; } = "MainfileQueue";

        // System
        public string SystemExchange { get; set; } = "SystemExchange";
        public string SystemQueue { get; set; } = "SystemQueue";
        public string LogQueue { get; set; } = "LogQueue";
        public string EventQueue { get; set; } = "EventQueue";


        //DeadLetter
        public string DeadLetterExchange { get; set; } = "DeadLetterExchange";
        public string DeadLetterQueue { get; set; } = "DeadLetterQueue";
        public string DeadLetterRoutingKey { get; set; } = "DeadLetterRoutingKey";

        public string SKUMasterRoutingKey { get; set; } = "skumaster";  // 新增路由鍵配置
        public string ArticalRoutingKey { get; set; } = "artical"; // 新增路由鍵配置
        public string RouteTaskRoutingKey { get; set; } = "routeTask"; // 新增路由鍵配置
        public string OrderInfoRoutingKey { get; set; } = "orderInfo"; // 新增路由鍵配置
        public string RetrieveLoadRoutingKey { get; set; } = "retrieveLoad"; // 新增路由鍵配置
        public string InboundPalletInfoRoutingKey { get; set; } = "inboundPalletInfo"; // 新增路由鍵配置
        public string SystemRoutingKey { get; set; } = "system"; // 新增路由鍵配置
        public string LogRoutingKey { get; set; } = "log"; // 新增路由鍵配置
        public string EventRoutingKey { get; set; } = "event"; // 新增路由鍵配置

        // 新增：狀態更新交換機與各服務狀態更新隊列
        public string StatusUpdateExchange { get; set; } = "StatusUpdateExchange";
        public string TransmissionStatusQueue { get; set; } = "TransmissionStatusQueue";
        public string OutboundStatusQueue { get; set; } = "OutboundStatusQueue";
        public string InboundStatusQueue { get; set; } = "InboundStatusQueue";
        public string MainfileStatusQueue { get; set; } = "MainfileStatusQueue";
    }
}
