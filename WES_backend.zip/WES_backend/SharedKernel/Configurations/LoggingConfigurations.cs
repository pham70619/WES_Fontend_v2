﻿using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Serilog.Debugging; // <- 這裡
using Elastic.Serilog.Sinks;
using Microsoft.Extensions.Options;
using Nest;
using Serilog.Events;



namespace SharedKernel.Configurations
{
    public static class LoggingConfigurations
    {
        /// <summary>
        /// 從 configuration 中讀取 Serilog 的設定，並可額外設定 ServiceName
        /// </summary>
        public static void ConfigureSerilog(IConfiguration configuration, string? serviceName = null)
        {
            SelfLog.Enable(msg => File.AppendAllText("SelfLogErrors.txt", msg));

            Serilog.Debugging.SelfLog.Enable(msg =>
            {
                // 你可以選擇寫到 Debug 輸出或 Console
                Console.WriteLine($"[Serilog SelfLog] {msg}");
            });

            //var elkOptions = new ElkOptions();
            //optionBuilder.Invoke(elkOptions);

            var loggerConfig = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration) // 讀取 "Serilog" 區段
                .Enrich.FromLogContext()
                .Enrich.WithMachineName()
                                .Enrich.WithEnvironmentUserName();
                
                //.WriteTo.Elasticsearch(options);

            if (!string.IsNullOrWhiteSpace(serviceName))
            {
                loggerConfig = loggerConfig.Enrich.WithProperty("ServiceName", serviceName);
            }

            Log.Logger = loggerConfig
                //.WriteTo.Elastic(new ElasticsearchSinkOptions(new Uri("http://localhost:9200"))
                //{
                //    AutoRegisterTemplate = true,
                //    MinimumLogEventLevel = LogEventLevel.Debug
                //})
                .CreateLogger();

            // 測試輸出 Serilog 設定
            Log.Information("Serilog 成功載入設定！DataStream: {DataStreamName}", configuration["Serilog:WriteTo:1:Args:dataStreamName"]);

            // 測試寫入 Elasticsearch
            Log.Information("測試日誌 - 來自應用程式 {Timestamp}", DateTime.UtcNow);

            Log.Information("Serilog configured for {ServiceName}", serviceName ?? "UnknownService");
        }
    }
}
