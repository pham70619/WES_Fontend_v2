﻿using Microsoft.EntityFrameworkCore;
using SharedKernel.Data;
using SharedKernel.Interface;
using SharedKernel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Logging
{
    public class MessageLoggingService : IMessageLoggingService
    {
        private readonly RabbitMQDbContext _dbContext;
        private readonly ISharedLogger<MessageLoggingService> _logger;

        public MessageLoggingService(RabbitMQDbContext dbContext, ISharedLogger<MessageLoggingService> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task<bool> IsMessageProcessedOrInProgressAsync(string requestId)
        {
            var processingLog = await _dbContext.ProcessingLogs.FirstOrDefaultAsync(log => log.RequestID == requestId);
            return processingLog != null && (processingLog.Status == "Processing" || processingLog.Status == "Processed");
        }

        public async Task LogMessageProcessingStartAsync(string requestId)
        {
            var processingLog = new ProcessingLog
            {
                RequestID = requestId,
                Status = "Processing",
                Timestamp = DateTime.Now
            };
            _dbContext.ProcessingLogs.Add(processingLog);
            await _dbContext.SaveChangesAsync();

            _logger.LogInformation($"Started processing message {requestId}.");
        }

        public async Task LogMessageProcessingResultAsync(string requestId, bool success, string? errorMessage = null, string? requestPayload = null)
        {
            var processingLog = await _dbContext.ProcessingLogs.FirstOrDefaultAsync(log => log.RequestID == requestId);
            if (processingLog != null)
            {
                processingLog.Status = success ? "Processed" : "Failed";
                processingLog.ErrorMessage = errorMessage;
                processingLog.RequestPayload = requestPayload;
                processingLog.Timestamp = DateTime.Now;

                await _dbContext.SaveChangesAsync();

                if (success)
                {
                    _logger.LogInformation($"Successfully processed message {requestId}.");
                }
                //else
                //{
                //    _logger.LogError($"Failed to process message {requestId}. Error: {errorMessage}");
                //}
            }
        }
    }
}
