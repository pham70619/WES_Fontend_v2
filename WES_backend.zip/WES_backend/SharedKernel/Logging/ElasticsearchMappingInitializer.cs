﻿using Nest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Logging
{
    internal class ElasticsearchMappingInitializer
    {
        private readonly IElasticClient _elasticClient;
        private readonly string _indexName;

        public ElasticsearchMappingInitializer(string elasticsearchUrl)
        {
            _indexName = $"logservice-logs-{DateTime.UtcNow:yyyy.MM.dd}";


            var settings = new ConnectionSettings(new Uri(elasticsearchUrl))
                .DefaultIndex(_indexName);

            _elasticClient = new ElasticClient(settings);
        }

        public void EnsureIndexMapping()
        {
            var existsResponse = _elasticClient.Indices.Exists(_indexName);
            if (!existsResponse.Exists)
            {
                var createResponse = _elasticClient.Indices.Create(_indexName, c => c
                    .Map<LogRecord>(m => m
                        .Properties(ps => ps
                            .Keyword(s => s.Name(p => p.CorrelationId))
                            .Keyword(s => s.Name(p => p.ServiceName))
                            .Keyword(s => s.Name(p => p.LogType))
                            .Keyword(s => s.Name(p => p.LogLevel))
                        )
                    )
                );

                if (!createResponse.IsValid)
                {
                    Console.WriteLine($"Failed to create index mapping: {createResponse.DebugInformation}");
                }
            }
        }
    }
}
