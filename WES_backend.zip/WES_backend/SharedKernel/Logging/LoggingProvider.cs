﻿using Microsoft.Extensions.Logging;
using NpgsqlTypes;
using Serilog.Sinks.PostgreSQL;
using Serilog;
using SharedKernel.Configurations;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace SharedKernel.Logging
{
    // LoggingProvider 類，用於配置 Serilog 日誌系統
    public static class LoggingProvider
    {
        // 日誌工廠，用於創建日誌記錄器
        public static ILoggerFactory LoggerFactory { get; private set; }

        // 配置日誌功能
        public static void ConfigureLogging(LoggingConfiguration config, IConfiguration configuration)
        {
            // 從配置中獲取 PostgreSQL 的連接字串
            //var connectionString = configuration.GetConnectionString("SystemLogConnection");

            // 定義日誌寫入到 PostgreSQL 中的列選項
            var columnOptions = new Dictionary<string, ColumnWriterBase>
            {
                { "Message", new RenderedMessageColumnWriter(NpgsqlDbType.Text) },
                { "Level", new LevelColumnWriter(true, NpgsqlDbType.Varchar) },
                { "TimeStamp", new TimestampColumnWriter(NpgsqlDbType.Timestamp) },
                { "Exception", new ExceptionColumnWriter(NpgsqlDbType.Text) },
                { "Properties", new PropertiesColumnWriter(NpgsqlDbType.Jsonb) },
                { "Application", new SinglePropertyColumnWriter("Application", PropertyWriteMethod.Raw, NpgsqlDbType.Varchar) },
                { "Service", new SinglePropertyColumnWriter("SourceContext", PropertyWriteMethod.Raw, NpgsqlDbType.Varchar) },
                { "Method", new SinglePropertyColumnWriter("Method", PropertyWriteMethod.Raw, NpgsqlDbType.Varchar) },
                { "RequestId", new SinglePropertyColumnWriter("RequestId", PropertyWriteMethod.Raw, NpgsqlDbType.Varchar) },
                { "RequestData", new SinglePropertyColumnWriter("RequestData", PropertyWriteMethod.Raw, NpgsqlDbType.Jsonb) },
                { "AdditionalData", new SinglePropertyColumnWriter("AdditionalData", PropertyWriteMethod.Raw, NpgsqlDbType.Jsonb) }
            };

            // 配置 Serilog 日誌
            Log.Logger = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .Enrich.WithProperty("Application", config.ApplicationName)
                .MinimumLevel.Debug()
                .WriteTo.Console()
                .WriteTo.File("logs/log-.txt", rollingInterval: RollingInterval.Day)
                //.WriteTo.PostgreSQL(
                //    connectionString: config.PostgreSQLConnectionString,
                //    tableName: config.TableName,
                //    needAutoCreateTable: false,
                //    columnOptions: columnOptions,
                //    schemaName: "public")
                .CreateLogger();

            // 設置日誌工廠
            LoggerFactory = new LoggerFactory().AddSerilog();

            // 啟用 Serilog 自我診斷日誌
            Serilog.Debugging.SelfLog.Enable(msg =>
            {
                Console.Error.WriteLine(msg);
                File.AppendAllText("logs\\serilog-selflog.txt", msg);
            });
        }
    }
}