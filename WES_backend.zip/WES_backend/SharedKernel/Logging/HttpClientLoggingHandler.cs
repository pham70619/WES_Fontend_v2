﻿using Microsoft.Extensions.Logging;
using SharedKernel.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Logging
{
    public class HttpClientLoggingHandler : DelegatingHandler
    {
        private readonly ISharedLogger<RequestResponseLoggingMiddleware> _logger;

        public HttpClientLoggingHandler(ISharedLogger<RequestResponseLoggingMiddleware> logger)
        {
            _logger = logger;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // 取得 Correlation ID，若無則產生新的
            var correlationId = request.Headers.Contains("X-Correlation-ID")
                ? request.Headers.GetValues("X-Correlation-ID").FirstOrDefault()
                : Guid.NewGuid().ToString();

            var userId = request.Headers.Contains("X-User-ID")
                ? request.Headers.GetValues("X-User-ID").FirstOrDefault()
                : "System";

            // 讀取 Request Body（僅適用於可讀取的 Body，例如 POST/PUT）
            string requestBody = request.Content != null ? await request.Content.ReadAsStringAsync() : "(empty)";

            // 發送請求
            var response = await base.SendAsync(request, cancellationToken);

            // 讀取 Response Body
            string responseBody = response.Content != null ? await response.Content.ReadAsStringAsync() : "(empty)";

            // 2️⃣ 記錄 API Response
            _logger.LogApi(
                message: "API call completed",
                method: request.Method.ToString(),
                url: request.RequestUri.ToString(),
                requestBody: requestBody,
                responseBody: responseBody,
                statusCode: (int)response.StatusCode,
                userId: userId,
                correlationId: correlationId
            );

            return response;
        }
    }
}
