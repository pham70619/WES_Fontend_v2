﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Logging
{
    /// <summary>
    /// 表示此筆日誌的事件類型，如 API 呼叫、RabbitMQ 訊息、業務事件等
    /// </summary>
    public enum LogType
    {
        /// <summary>API 請求/回應的呼叫紀錄</summary>
        ApiCall,

        /// <summary>RabbitMQ 收到或發送的訊息</summary>
        RabbitMqMessage,

        /// <summary>系統或業務上的事件紀錄，如訂單建立、排程啟動等</summary>
        BusinessEvent,

        /// <summary>其他型態的自定義紀錄</summary>
        Other
    }
}
