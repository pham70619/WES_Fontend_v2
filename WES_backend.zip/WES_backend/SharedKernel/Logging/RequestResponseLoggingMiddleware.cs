﻿using Microsoft.AspNetCore.Http;
using SharedKernel.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Logging
{
    public class RequestResponseLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ISharedLogger<RequestResponseLoggingMiddleware> _logger;

        public RequestResponseLoggingMiddleware(RequestDelegate next,
            ISharedLogger<RequestResponseLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            // 1. 檢查/取得 CorrelationId (若無則產生)
            const string CorrelationHeaderKey = "X-CorrelationId";
            var correlationId = context.Request.Headers[CorrelationHeaderKey].Count > 0
                ? context.Request.Headers[CorrelationHeaderKey].ToString()
                : Guid.NewGuid().ToString();

            // 將此 CorrelationId 回寫到 Response Header，方便前端或其他呼叫端存取
            context.Response.Headers[CorrelationHeaderKey] = correlationId;

            // 把 correlationId 放進 HttpContext.Items
            context.Items["CorrelationId"] = correlationId;

            // 2. 讀取 Request Body（若有）
            context.Request.EnableBuffering();
            string requestBody;
            using (var reader = new StreamReader(context.Request.Body, leaveOpen: true))
            {
                requestBody = await reader.ReadToEndAsync();
                context.Request.Body.Position = 0; // 重置游標給後續流程使用
            }

            // 3. 攔截 Response 的 Body
            var originalBodyStream = context.Response.Body;
            using var responseBody = new MemoryStream();
            context.Response.Body = responseBody;

            // 4. 執行下一個中介層或控制器
            await _next(context);

            // 5. 讀取 Response Body
            context.Response.Body.Seek(0, SeekOrigin.Begin);
            var respBodyText = await new StreamReader(context.Response.Body).ReadToEndAsync();
            context.Response.Body.Seek(0, SeekOrigin.Begin);

            // 6. 收集 API 呼叫資訊
            var method = context.Request.Method;
            var url = $"{context.Request.Scheme}://{context.Request.Host}{context.Request.Path}{context.Request.QueryString}";
            int statusCode = context.Response.StatusCode;
            var userId = context.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "N/A";

            // 7. 在 Log 中記錄 API 呼叫 (包含 CorrelationId)
            _logger.LogApi(
                message: "API call from middleware",
                method: method,
                url: url,
                requestBody: requestBody,
                responseBody: respBodyText,
                statusCode: statusCode,
                userId: userId,
                correlationId: correlationId
            );

            // 8. 將攔截的 Response Stream 再寫回原本 stream
            await responseBody.CopyToAsync(originalBodyStream);
        }
    }

}
