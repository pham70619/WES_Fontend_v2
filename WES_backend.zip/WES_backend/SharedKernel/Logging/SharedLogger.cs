﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SharedKernel.Configurations;
using SharedKernel.Interface;
using SharedKernel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Logging
{
    // SharedLogger 類，實現了 ISharedLogger 接口，用於提供日誌記錄功能
    public class SharedLogger<T> : ISharedLogger<T>
    {
        private readonly ILogger<T> _logger;
        private readonly string _teamsWebhookUrl;
        private readonly string _serviceName;
        //private readonly string elasticsearchUrl = "http://localhost:9200";

        // 構造函數，初始化 ILogger 實例
        public SharedLogger(ILogger<T> logger,
                            IOptions<LoggingConfiguration> options,
                            string teamsWebhookUrl = "https://picmis.webhook.office.com/webhookb2/0faa3cb9-476f-4a1f-bdeb-d6bffc180a77@dda92dc6-2169-4d9a-acae-54019f5327f2/IncomingWebhook/67b848d3c9c64f479753be68d11230b9/bb001461-b002-4aed-867d-df76d9ff36b4/V2s0q4WJbzh7ZXpfuSUTpLCtDa07aUgavnDRITfo7xGrk1"
                            //string elasticsearchUrl = "http://localhost:9200"
            )
        {
            //_logger = LoggingProvider.LoggerFactory.CreateLogger<T>();
            _logger = logger;
            _teamsWebhookUrl = teamsWebhookUrl;
            _serviceName = options.Value.ApplicationName;

            //var mappingInitializer = new ElasticsearchMappingInitializer(elasticsearchUrl);
            //mappingInitializer.EnsureIndexMapping();
        }

        #region ISharedLogger<T> 介面方法 (原本各級別Log)

        public void LogDebug(string message)
        {
            var record = CreateLogRecord(LogLevel.Debug, LogType.Other, message);
            _logger.LogDebug("{@LogRecord}", record);
            //SendTeamsNotificationAsync("Debug", message).Wait();
        }

        public void LogDebug(LogRecord logreocrd)
        {
            logreocrd.LogLevel = MapLogLevel(LogLevel.Debug);
            //var record = CreateLogRecord(LogLevel.Debug, LogType.Other, message);
            _logger.LogDebug("{@LogRecord}", logreocrd);
            //SendTeamsNotificationAsync("Debug", message).Wait();
        }

        // 記錄一般信息
        public void LogInformation(string message, string? correlationId = null)
        {
            var record = CreateLogRecord(LogLevel.Information, LogType.Other, message);

            if (correlationId == null)
            {
                record.CorrelationId = Guid.Empty.ToString();
            }
            else 
            {
                record.CorrelationId = correlationId;
            }

            _logger.LogInformation("{@LogRecord}", record);

        }

        public void LogInformation(LogRecord logreocrd)
        {
            logreocrd.LogLevel = MapLogLevel(LogLevel.Information);

            _logger.LogInformation("{@LogRecord}", logreocrd);

        }



        // 記錄警告信息
        public void LogWarning(string message, string? correlationId = null)
        {
            var record = CreateLogRecord(LogLevel.Warning, LogType.Other, message, correlationId);

            if (correlationId == null)
            {
                record.CorrelationId = Guid.Empty.ToString();
            }
            else
            {
                record.CorrelationId = correlationId;
            }

            _logger.LogWarning("{@LogRecord}", record);
        }

        public void LogWarning(LogRecord logreocrd)
        {
            logreocrd.LogLevel = MapLogLevel(LogLevel.Warning);

            _logger.LogInformation("{@LogRecord}", logreocrd);

        }

        // 記錄錯誤信息，包括異常細節
        public void LogError(Exception exception, string message, string? correlationId = null)
        {
            var record = CreateLogRecord(LogLevel.Error, LogType.Other, message, correlationId);

            if (correlationId == null)
            {
                record.CorrelationId = Guid.Empty.ToString();
            }
            else
            {
                record.CorrelationId = correlationId;
            }

            record.AdditionalProperties["Exception"] = GetExceptionSummary(exception);
            _logger.LogError(exception, "{@LogRecord}", record);
        }

        public void LogError(LogRecord logreocrd)
        {
            logreocrd.LogLevel = MapLogLevel(LogLevel.Error);

            _logger.LogInformation("{@LogRecord}", logreocrd);

        }

        // 記錄嚴重錯誤信息，包括異常細節
        public void LogCritical(Exception exception, string message, string? correlationId = null)
        {
            var record = CreateLogRecord(LogLevel.Critical, LogType.Other, message, correlationId);

            if (correlationId == null)
            {
                record.CorrelationId = Guid.Empty.ToString();
            }
            else
            {
                record.CorrelationId = correlationId;
            }

            record.AdditionalProperties["Exception"] = GetExceptionSummary(exception);
            _logger.LogCritical(exception, "{@LogRecord}", record);
        }

        public void LogCritical(LogRecord logreocrd)
        {
            logreocrd.LogLevel = MapLogLevel(LogLevel.Critical);

            _logger.LogInformation("{@LogRecord}", logreocrd);

        }

        private string GetExceptionSummary(Exception exception, int maxLength = 1024)
        {
            if (exception == null)
            {
                return "Exception is null";
            }

            var summary = new StringBuilder();
            summary.AppendLine($"Exception: {exception.GetType().Name}");
            summary.AppendLine($"Message: {exception.Message}");
            summary.AppendLine($"StackTrace: {exception.StackTrace}");

            // 如果有內部異常，也加入摘要
            if (exception.InnerException != null)
            {
                summary.AppendLine($"InnerException: {exception.InnerException.GetType().Name}");
                summary.AppendLine($"InnerMessage: {exception.InnerException.Message}");
                summary.AppendLine($"InnerStackTrace: {exception.InnerException.StackTrace}");
            }

            // 限制長度，避免訊息過長
            var result = summary.ToString();
            return result.Length > maxLength ? result.Substring(0, maxLength) + "..." : result;

        }


        /// <summary>
        /// 記錄 業務事件 的訊息
        /// </summary>
        /// <param name="eventName">此次事件名稱，以<Domain.Action.Result格式建立></Domain.Action.Result></param>
        /// <param name="isSuccess">成功與否</param>
        /// <param name="payload">事件詳細資訊</param>
        /// <param name="userId">若此訊息跟某用戶ID有關可帶</param>
        /// <param name="correlationId">若此訊息跟某用戶ID有關可帶</param>
        public void LogEvent(string eventName, bool isSuccess, object? payload = null, string? userId = null, string? correlationId = null)
        {
            var message = $"Event {eventName}, Success={isSuccess}";
            var record = CreateLogRecord(LogLevel.Information, LogType.BusinessEvent, message, userId, correlationId);
            var businessEvent = new BusinessEventData
            {
                EventName = eventName,
                Payload = payload,
                Result = isSuccess ? "Success" : "Fail"
            };
            record.BusinessEvent = businessEvent;
            _logger.LogInformation("{@LogRecord}", record);
        }

        public void LogUserAction(string message, string username)
        {
            _logger.LogTrace($"User Action: {message} by {username}");
            //SendTeamsNotificationAsync("User Action", message).Wait();
        }


        /// <summary>
        /// 記錄 API 請求與回應的資料 (結合中介層或呼叫端提供的 Request/Response)
        /// </summary>
        public void LogApi(string message,
                           string method,
                           string url,
                           string requestBody,
                           string responseBody,
                           int? statusCode = null,
                           string? userId = null,
                           string? correlationId = null)
        {
            var record = CreateLogRecord(LogLevel.Information, LogType.ApiCall, message, userId, correlationId);

            // 組裝 ApiRequestData
            var requestData = new ApiRequestData
            {
                Method = method,
                Url = url,
                Body = requestBody
            };

            // 這裡若您要記錄 Headers，可透過其他參數或context注入
            // requestData.Headers = ...

            var responseData = new ApiResponseData
            {
                StatusCode = statusCode,
                Body = responseBody
            };
            // responseData.Headers = ...

            record.ApiRequest = requestData;
            record.ApiResponse = responseData;

            _logger.LogInformation("{@LogRecord}", record);
        }

        /// <summary>
        /// 記錄 RabbitMQ 發送或接收的訊息
        /// </summary>
        /// <param name="message">此次Log的描述</param>
        /// <param name="exchange">RabbitMQ Exchange</param>
        /// <param name="routingKey">RabbitMQ RoutingKey</param>
        /// <param name="msgBody">原始訊息Body</param>
        /// <param name="deliveryMode">1=Non-persistent, 2=Persistent</param>
        /// <param name="headers">可透過 Dictionary 傳入自訂header</param>
        /// <param name="userId">若此訊息跟某用戶ID有關可帶</param>
        public void LogRabbitMq(string message,
                                string exchange,
                                string routingKey,
                                string msgBody,
                                byte? deliveryMode = 2,
                                Dictionary<string, object>? headers = null,
                                string? userId = null,
                                string? correlationId = null)
        {
            var record = CreateLogRecord(LogLevel.Information, LogType.RabbitMqMessage, message, userId, correlationId);

            // 組裝 RabbitMqData
            var rabbitData = new RabbitMqData
            {
                Exchange = exchange,
                RoutingKey = routingKey,
                MessageBody = msgBody,
                DeliveryMode = deliveryMode,
                Headers = headers
            };
            record.RabbitMq = rabbitData;

            _logger.LogInformation("{@LogRecord}", record);
        }

        #endregion

        #region 內部共用方法

        private async Task SendTeamsNotificationAsync(string level, string message)
        {
            if (string.IsNullOrEmpty(_teamsWebhookUrl)) return;

            using var httpClient = new HttpClient();
            var payload = new
            {
                text = $"**{level}**: {message}"
            };

            var jsonPayload = System.Text.Json.JsonSerializer.Serialize(payload);
            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            try
            {
                var response = await httpClient.PostAsync(_teamsWebhookUrl, content);
                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogWarning($"Failed to send Teams notification. Status Code: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send Teams notification.");
            }
        }

        /// <summary>
        /// 建立一個完整的 LogRecord，填入必填屬性( required )。
        /// 這裡由於 .NET Enum LogLevel 與您自訂的 string LogLevel 需對照，
        /// 所以我們做一個方法把 Microsoft.Extensions.Logging.LogLevel 轉成 string。
        /// </summary>
        private LogRecord CreateLogRecord(Microsoft.Extensions.Logging.LogLevel level,
                                            LogType logType,
                                            string message,
                                            string? userId = null,
                                            string? correlationId = null)
        {
            return new LogRecord
            {
                // required
                LogLevel = MapLogLevel(level),           // string
                ServiceName = _serviceName,              // string
                LogType = logType,                       // enum
                CorrelationId = correlationId??Guid.Empty.ToString(),          // string
                Message = message,                       // string

                // optional
                UserId = userId
            };
        }

        /// <summary>
        /// 將 Microsoft.Extensions.Logging.LogLevel 轉成字串，供 LogRecord.LogLevel 使用。
        /// 您也可直接在 LogRecord.LogLevel 定義為 enum, 再做對應。
        /// </summary>
        private static string MapLogLevel(Microsoft.Extensions.Logging.LogLevel level)
        {
            return level switch
            {
                Microsoft.Extensions.Logging.LogLevel.Trace => "Trace",
                Microsoft.Extensions.Logging.LogLevel.Debug => "Debug",
                Microsoft.Extensions.Logging.LogLevel.Information => "Information",
                Microsoft.Extensions.Logging.LogLevel.Warning => "Warning",
                Microsoft.Extensions.Logging.LogLevel.Error => "Error",
                Microsoft.Extensions.Logging.LogLevel.Critical => "Critical",
                _ => "None"
            };
        }

        #endregion
    }
}