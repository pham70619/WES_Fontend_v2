﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Logging
{
    /// <summary>
    /// 通用日誌結構，可同時容納 API 呼叫、RabbitMQ 訊息或一般業務事件。
    /// </summary>
    public class LogRecord
    {
        /// <summary>唯一識別碼(可由產生日誌端生成)，用於DB索引或後續重放</summary>
        public Guid LogId { get; set; } = Guid.NewGuid();

        /// <summary>日誌產生時間 (通常為 UTC 時間)</summary>
        public DateTime Timestamp { get; set; } = DateTime.Now;

        /// <summary>日誌等級，如 Information, Warning, Error, Debug…</summary>
        public required string LogLevel { get; set; }

        /// <summary>此筆日誌所屬之服務名稱，如 OrderService, PaymentService…</summary>
        public required string ServiceName { get; set; }

        /// <summary>區分日誌類型，如 API_CALL, RABBITMQ_MESSAGE, BUSINESS_EVENT 等</summary>
        public required LogType LogType { get; set; }

        /// <summary>可跨服務/程序追蹤的 Correlation Id</summary>
        public required string CorrelationId { get; set; }

        /// <summary>使用者ID (若由使用者觸發)，否則可為系統或空字串</summary>
        public string? UserId { get; set; }

        /// <summary>摘要訊息/描述，供人類快速閱讀</summary>
        public required string Message { get; set; }

        // ---------------------- API CALL 子物件 ----------------------
        public ApiRequestData? ApiRequest { get; set; }
        public ApiResponseData? ApiResponse { get; set; }

        // ---------------------- RABBITMQ 子物件 ----------------------
        public RabbitMqData? RabbitMq { get; set; }

        // ---------------------- 業務事件 子物件 ----------------------
        public BusinessEventData? BusinessEvent { get; set; }

        /// <summary>可放其它延伸屬性 (非預設欄位) 的動態資料</summary>
        public Dictionary<string, object> AdditionalProperties { get; set; }
            = new Dictionary<string, object>();
    }

    // 下列三個類是此 LogRecord 用到的子物件

    /// <summary>API Request 相關資料</summary>
    public class ApiRequestData
    {
        public string? Method { get; set; }
        public string? Url { get; set; }
        /// <summary>Request Body 原始字串 (JSON or other)</summary>
        public string? Body { get; set; }
        /// <summary>標頭資料 (如 Key=HeaderName, Value=HeaderValue)</summary>
        public Dictionary<string, string>? Headers { get; set; }
    }

    /// <summary>API Response 相關資料</summary>
    public class ApiResponseData
    {
        public int? StatusCode { get; set; }
        public string? Body { get; set; }
        public Dictionary<string, string>? Headers { get; set; }
    }

    /// <summary>RabbitMQ 訊息資料</summary>
    public class RabbitMqData
    {
        public string? Exchange { get; set; }
        public string? RoutingKey { get; set; }
        /// <summary>可包含 x-retry-count 等自訂標頭</summary>
        public Dictionary<string, object>? Headers { get; set; }
        /// <summary>1 = 非持久, 2 = 持久</summary>
        public byte? DeliveryMode { get; set; }
        /// <summary>原始訊息內容 (JSON or other)</summary>
        public string? MessageBody { get; set; }
    }

    /// <summary>一般業務事件資料</summary>
    public class BusinessEventData
    {
        public string? EventName { get; set; }
        /// <summary>事件主要 Payload，可放任意物件(序列化後)</summary>
        public object? Payload { get; set; }
        /// <summary>事件執行結果，如 "Success", "Fail"</summary>
        public string? Result { get; set; }
    }
}
