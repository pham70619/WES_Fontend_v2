﻿using Newtonsoft.Json;
using SharedKernel.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Event
{
    public class EventRequestDto
    {
        public EventRequestDto(string messageId, string requestID, bool processingSucceeded, StatusEnum status, string remark)
        {
            MessageId = messageId;
            RequestID = requestID;
            IsSuccess = processingSucceeded;
            Status = status;
            ErrorMessage = remark;
        }

        public required string MessageId { get; set; }

        [JsonProperty("SESSION_ID")]
        public required string RequestID { get; set; }

        public bool IsSuccess { get; set; }
        public StatusEnum? Status { get; set; }
        public string? ErrorMessage { get; set; }

    }
}
