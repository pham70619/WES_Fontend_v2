﻿using SharedKernel.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Event
{
    public class PresidentEventDto
    {
        public List<PresidentEventDetailDto> PresidentEventDetails { get; set; }
        public string CorrelationId { get; set; }
        public EventEnum EventType { get; set; }
        public string Updateby { get; set; }
        public DateTime UpdateAt { get; set; }

        public PresidentEventDto(List<PresidentEventDetailDto> contents, string correlationId, EventEnum eventType, string updateBy, DateTime updateAt)
        {
            PresidentEventDetails = contents;
            CorrelationId = correlationId;
            EventType = eventType;
            Updateby = updateBy;
            UpdateAt = updateAt;
        }
    }
}
