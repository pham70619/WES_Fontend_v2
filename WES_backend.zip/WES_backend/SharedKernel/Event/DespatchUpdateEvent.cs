﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Event
{
    public class DespatchUpdateEvent
    {
        public DespatchResultDto DespatchResult { get; set; }
        public string Updateby { get; set; }
        public DateTime UpdateAt { get; set; }


        public DespatchUpdateEvent(DespatchResultDto content, string updateBy, DateTime updateAt)
        {
            DespatchResult = content;
            Updateby = updateBy;
            UpdateAt = updateAt;
        }
    }
}
