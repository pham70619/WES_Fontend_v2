﻿using SharedKernel.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Event
{
    public class DespatchResultDto
    {
        public string? DespatchType { get; set; } = "NoData";
        public string? CorrelationId { get; set; }
        public string? Status { get; set; } = StatusEnum.None.ToString();
        public string? Message { get; set; } = null;
        public DespatchResultDto(string despatchType, string correlationId, string status, string message) 
        {
            DespatchType = despatchType;
            CorrelationId = correlationId;
            Status = status;
            Message = message;
        }
    }
}
