﻿using Newtonsoft.Json;
using SharedKernel.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Event
{
    public class PresidentEventDetailDto
    {
        public PresidentEventDetailDto(string messageId, string correlationId, bool isSuccess, StatusEnum status, string errorMessage, List<string?> requestIDs, string? oRG_CorrelationId = null)
        {
            MessageId = messageId;
            CorrelationId = correlationId;
            IsSuccess = isSuccess;
            Status = status;
            ErrorMessage = errorMessage;
            RequestIDs = requestIDs;
            ORG_CorrelationId = oRG_CorrelationId ?? Guid.Empty.ToString();
        }

        public PresidentEventDetailDto(string messageId, string correlationId, bool isSuccess, StatusEnum status, string errorMessage, List<string?> requestIDs)
                        : this(messageId, correlationId, isSuccess, status, errorMessage, requestIDs, null)
        { }
        //{
        //    MessageId = messageId;
        //    CorrelationId = correlationId;
        //    IsSuccess = isSuccess;
        //    Status = status;
        //    ErrorMessage = errorMessage;
        //    RequestIDs = requestIDs;
        //    ORG_CorrelationId = Guid.Empty.ToString();

        //}

        public required string MessageId { get; set; }
        public required string CorrelationId { get; set; }
        public bool IsSuccess { get; set; }
        public StatusEnum? Status { get; set; }
        public string? ErrorMessage { get; set; }
        public List<string?> RequestIDs { get; set; }
        public string? ORG_CorrelationId { get; set; }
    }
}
