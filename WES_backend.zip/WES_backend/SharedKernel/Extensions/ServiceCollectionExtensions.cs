﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using SharedKernel.Configurations;
using SharedKernel.Data;
using SharedKernel.Interface;
using SharedKernel.Logging;
using SharedKernel.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Extensions
{
    // ServiceCollectionExtensions 類，提供擴展方法以便將共用日誌功能添加到 DI 容器中
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// 提供給微服務在 Startup 或 Program 中呼叫，達成統一的日誌註冊
        /// </summary>
        /// <param name="services">IServiceCollection</param>
        /// <param name="configuration">App configuration (讀取 appsettings.json)</param>
        /// <param name="serviceName">可為當前微服務命名，寫入日誌屬性</param>
        /// <returns></returns>
        public static IServiceCollection AddSharedLogging(this IServiceCollection services, IConfiguration configuration, string serviceName)
        {
            //// 從配置中讀取 LoggingConfigurations 配置節點
            var loggingConfig = configuration.GetSection("LoggingConfigurations").Get<LoggingConfiguration>();

            // 1. 執行我們的共用Serilog初始化
            LoggingConfigurations.ConfigureSerilog(configuration, serviceName);

            // 2. 清除預設 LoggerProvider (可視需要)
            services.AddLogging(builder => builder.ClearProviders());

            // 3. (選擇性) 若有自訂 Middleware 也可在這裡注入
            //services.UseMiddleware<RequestResponseLoggingMiddleware>();

            services.AddSingleton(typeof(ISharedLogger<>), typeof(SharedLogger<>));


            return services;
        }

        public static IServiceCollection AddSharedServices(this IServiceCollection services)
        {
            services.AddScoped<IMessageLoggingService, MessageLoggingService>();
            services.AddScoped<IMessageFailureHandler, MessageFailureHandler>();
            return services;
        }

        public static IServiceCollection AddSharedDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("RabbitMQ");
            services.AddDbContext<RabbitMQDbContext>(options =>
                options.UseNpgsql(connectionString));

            return services;
        }

        public static IServiceCollection AddSharedHttpClients(this IServiceCollection services)
        {
            services.AddTransient<HttpClientLoggingHandler>(); // 註冊 Logging Handler

            services.AddHttpClient("LoggingClient")
                .AddHttpMessageHandler<HttpClientLoggingHandler>(); // 註冊 HttpClient 並加入 LoggingHandler

            return services;
        }

        // 绑定 RabbitMQ 配置
        public static IServiceCollection ConfigureRabbitMQ(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<RabbitMQSettings>(configuration.GetSection("RabbitMQSettings"));

            services.AddSingleton(sp => sp.GetRequiredService<IOptions<RabbitMQSettings>>().Value);

            return services;
        }

        // 注册 RabbitMQ 连接工厂、连接和频道
        public static IServiceCollection AddRabbitMQ(this IServiceCollection services)
        {
            // 注册连接工厂
            services.AddSingleton<IConnectionFactory>(sp =>
            {
                var settings = sp.GetRequiredService<IOptions<RabbitMQSettings>>().Value;
                return new ConnectionFactory()
                {
                    HostName = settings.HostName,
                    Port = settings.Port,
                    UserName = settings.UserName,
                    Password = settings.Password,
                    DispatchConsumersAsync = true // 支持异步消费者
                };
            });

            // 注册连接为 Singleton
            services.AddSingleton<IConnection>(sp =>
            {
                var factory = sp.GetRequiredService<IConnectionFactory>();
                return factory.CreateConnection();
            });

            // 注册频道为 Singleton，不进行声明
            services.AddSingleton<IModel>(sp =>
            {
                var connection = sp.GetRequiredService<IConnection>();
                return connection.CreateModel();
            });

            return services;
        }

        // 注册 RabbitMQ 发布者
        public static IServiceCollection AddRabbitMQServices(this IServiceCollection services)
        {
            services.AddSingleton<IRabbitMQPublisher, RabbitMQPublisher>();
            return services;
        }

        // 注册 RabbitMQ 初始化器
        public static IServiceCollection AddRabbitMQInitializer(this IServiceCollection services)
        {
            services.AddSingleton<RabbitMQInitializer>();
            return services;
        }

    }
}