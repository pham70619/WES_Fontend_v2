﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;

public abstract class PagedQueryCommand<T> : IRequest<T>
{
    public int Batch { get; set; }
    public int Skip { get; set; }

    protected PagedQueryCommand(int batch, int skip)
    {
        Batch = batch;
        Skip = skip;
    }
}
