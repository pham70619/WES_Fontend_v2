﻿using SharedKernel.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SharedKernel.Data
{
    public class RabbitMQDbContext : DbContext
    {
        public RabbitMQDbContext(DbContextOptions<RabbitMQDbContext> options)
            : base(options)
        {
        }

        public DbSet<ProcessingLog> ProcessingLogs { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            foreach (var entity in modelBuilder.Model.GetEntityTypes())
            {
                // 將表名轉換為小寫
                entity.SetTableName(entity.GetTableName().ToLower());

                // 遍歷所有的屬性，將列名轉換為小寫
                foreach (var property in entity.GetProperties())
                {
                    property.SetColumnName(property.GetColumnName(StoreObjectIdentifier.Table(entity.GetTableName(), null)).ToLower());
                }

                // 遍歷所有的鍵，將列名轉換為小寫
                foreach (var key in entity.GetKeys())
                {
                    key.SetName(key.GetName().ToLower());
                }

                // 遍歷所有的索引，將列名轉換為小寫
                foreach (var index in entity.GetIndexes())
                {
                    index.SetDatabaseName(index.GetDatabaseName().ToLower());
                }

                // 遍歷所有的外鍵，將列名轉換為小寫
                foreach (var fk in entity.GetForeignKeys())
                {
                    fk.SetConstraintName(fk.GetConstraintName().ToLower());
                }
            }

            // 配置 ProcessingLog 表
            modelBuilder.Entity<ProcessingLog>().HasKey(p => p.RequestID);
            modelBuilder.Entity<ProcessingLog>().Property(p => p.RequestID).IsRequired().HasMaxLength(40);
            modelBuilder.Entity<ProcessingLog>().Property(p => p.Status).IsRequired().HasMaxLength(20);
            modelBuilder.Entity<ProcessingLog>().Property(e => e.Timestamp)
                              .HasColumnType("timestamp without time zone");
        }
    }
}
