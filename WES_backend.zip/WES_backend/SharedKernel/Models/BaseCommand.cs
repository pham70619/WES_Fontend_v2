﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Models
{
    public abstract class BaseCommand
    {
        protected BaseCommand(string correlationId)
        {
            CorrelationId = correlationId;
        }

        public string CorrelationId { get; set; } = Guid.NewGuid().ToString();
    }
}
