﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Models
{
    public class ProcessingLog
    {
        //public int LogId { get; set; }       // 自增主鍵
        public required string RequestID { get; set; } // 唯一的消息ID
        public required string Status { get; set; }    // 處理狀態 (Processing, Processed, Failed)
        public DateTime Timestamp { get; set; } = DateTime.Now;  // 處理時間
        public string? ErrorMessage { get; set; }  // 可選的錯誤消息
        public string? RequestPayload { get; set; }  // 可選的錯誤消息
    }
}
